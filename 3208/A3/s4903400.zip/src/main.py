#   INFS7203 (F1 booster: class_weight + CV threshold)
#   python src\main.py --train data\train.csv --test data\test_data.csv
#   python src\main.py --ycol "Target (Col44)" --out s4903400.infs7203 --seed 42

import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

# Preprocessing
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
# Model
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
# Evaluation
from sklearn.model_selection import StratifiedKFold, GridSearchCV, cross_val_predict
from sklearn.metrics import f1_score, accuracy_score

# Identify the label column
def detect_label_column(train_df: pd.DataFrame, test_df: pd.DataFrame, hint: str = "") -> str:
    train = train_df.copy(); test = test_df.copy()
    train.columns = [c.strip() for c in train.columns]
    test.columns  = [c.strip() for c in test.columns]
    if hint and hint in train.columns: return hint
    for c in ["Target","target","label","Label","class","Class","y","Response","Outcome"]:
        if c in train.columns: return c
    extra = [c for c in train.columns if c not in test.columns]
    if len(extra) == 1: return extra[0]
    # Try the unique binary column
    binary = [c for c in train.columns if set(pd.Series(train[c]).dropna().unique()).issubset({0,1})]
    if len(binary) == 1: return binary[0]
    return train.columns[-1]

def main():
    # Parameter
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", default="data/train.csv")
    ap.add_argument("--test",  default="data/test_data.csv")
    ap.add_argument("--out",   default="s4903400.infs7203")
    ap.add_argument("--ycol",  default="", help="若标签列不常见，可手动指定")
    ap.add_argument("--seed",  type=int, default=42)
    args = ap.parse_args()

    # Convert the path to absolute (based on the project root)
    ROOT = Path(__file__).resolve().parents[1]
    def to_abs(p: str) -> str:
        pth = Path(p);  return str((ROOT / p).resolve()) if not pth.is_absolute() else str(pth)
    args.train, args.test, args.out = map(to_abs, [args.train, args.test, args.out])
    print("Using paths:", args.train, args.test, args.out)

    # Read
    train = pd.read_csv(args.train)
    test  = pd.read_csv(args.test)

    # Identify the label column + extract X, y (ensuring y is 0/1 integer)
    y_col = detect_label_column(train, test, args.ycol)
    print(f"Detected label column: {y_col}")
    if y_col not in train.columns:
        raise ValueError(f"无法识别标签列，请用 --ycol 指定。训练集列：{list(train.columns)}")
    X = train.drop(columns=[y_col])
    y_raw = train[y_col]
    try:
        y = y_raw.astype(int)
    except Exception:
        uniq = list(pd.Series(y_raw).dropna().unique())
        if len(uniq) != 2:
            raise ValueError(f"标签列不是二值：{y_col} 唯一值={uniq}")
        y = y_raw.map({uniq[0]:0, uniq[1]:1}).astype(int)

    # Column type classification
    cat_cols = [c for c in X.columns if X[c].dtype == "object"]
    num_cols = [c for c in X.columns if c not in cat_cols]

    # Preprocessing: Numerical (median + standardization), Categorical (mode + one-hot encoding)
    pre = ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")),
                          ("scaler", StandardScaler())]), num_cols),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                          ("ohe", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), cat_cols)
    ])

    # Candidate Models (Select the Best Based on F1 Score)
    pipe = Pipeline([("prep", pre), ("model", KNeighborsClassifier())])
    param_grid = [
        # kNN
        {"model": [KNeighborsClassifier()],
         "model__n_neighbors": [3, 5, 9, 15, 21],
         "model__weights": ["uniform", "distance"]},
        # RandomForest：class_weight="balanced"
        {"model": [RandomForestClassifier(random_state=args.seed, n_jobs=-1, class_weight=None)],
         "model__n_estimators": [400, 600],
         "model__max_depth": [None, 12, 18],
         "model__min_samples_leaf": [1, 2]},
        {"model": [RandomForestClassifier(random_state=args.seed, n_jobs=-1, class_weight="balanced")],
         "model__n_estimators": [400, 600],
         "model__max_depth": [None, 12, 18],
         "model__min_samples_leaf": [1, 2]},
    ]

    cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=args.seed)
    grid = GridSearchCV(pipe, param_grid, scoring="f1", cv=cv, n_jobs=-1, refit=True, verbose=0)
    grid.fit(X, y)
    best = grid.best_estimator_

    #   Selecting Thresholds on CV: Use cross_val_predict to obtain the probability of the positive class for each sample, and then scan the thresholds.
    proba = cross_val_predict(best, X, y, cv=cv, method="predict_proba", n_jobs=-1)[:, 1]
    cand_thresholds = [0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60]
    metrics = []
    for t in cand_thresholds:
        y_hat = (proba >= t).astype(int)
        metrics.append((t, f1_score(y, y_hat), accuracy_score(y, y_hat)))
    # Take the threshold with the highest F1 score
    best_t, best_f1, best_acc = max(metrics, key=lambda x: x[1])

    # Retrain the best model on the entire training set; use the "optimal threshold" to generate predictions for the test set.
    best.fit(X, y)
    test_proba = best.predict_proba(test)[:, 1]
    test_pred  = (test_proba >= best_t).astype(int)

    #  Write the result file.
    out_path = Path(args.out); out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        for p in test_pred:
            f.write(f"{int(p)},\n")
        f.write(f"{best_acc:.3f},{best_f1:.3f},\n")

    # Print summary
    info = {
        "label_column": y_col,
        "best_model_type": type(best.named_steps["model"]).__name__,
        "best_params": grid.best_params_,
        "cv_best_threshold": best_t,
        "cv_accuracy_mean": round(best_acc, 5),
        "cv_f1_mean": round(best_f1, 5)
    }
    print(json.dumps(info, ensure_ascii=False, indent=2, default=str))

if __name__ == "__main__":
    main()
