## Environment

- Python 3.11
- Deps: numpy==1.26.4, pandas==2.2.2, scikit-learn==1.4.2
- Install: pip install -r requirements.txt

## Method 

- **Preprocessing (Week 2):**
  Numeric → median imputation + standardization; Categorical → most-frequent imputation + one-hot. Implemented via ColumnTransformer + Pipeline.
- **Evaluation & Tuning (Week 2/4):**
  **Stratified 10-fold CV** with GridSearchCV, scoring by **F1**, to select the best model and hyperparameters.
- **Model candidates (Week 3/4):**
  - kNN: n_neighbors ∈ {3,5,9,15,21}, weights ∈ {uniform,distance}
  - RandomForest: n_estimators ∈ {400,600}, max_depth ∈ {None,12,18}, min_samples_leaf ∈ {1,2}, class_weight ∈ {None,"balanced"}
- **Final training & output (Week 2/4):**
  Retrain the best setting on the full training set → predict test → produce the submission file.
  Output format: first **2713** lines are test predictions (0/1) **each ending with a comma**; last line is CV_Acc,CV_F1, (three decimals, ends with a comma).

## Best setting

- Model: RandomForest(class_weight="balanced", n_estimators=600, max_depth=18, min_samples_leaf=2)
- 10-fold means: Acc ≈ 0.807, F1 ≈ 0.662
- Label column: auto-detected as **Target (Col44)** (you may also pass --ycol explicitly)

## Reproduction steps

1. `pip install -r requirements.txt`
2. Run the one-liner above
3. You’ll get **s4903400.infs7203** in project root
   - Line count must be **2714** (2713 test + 1)
   - Last line like `0.807,0.662,`

## Submission checklist