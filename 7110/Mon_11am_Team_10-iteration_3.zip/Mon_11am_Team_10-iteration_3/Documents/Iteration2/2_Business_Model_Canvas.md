# Iteration 2 – Business Model Canvas 

## 1. Customer Segments

- **UQ Students**

  Seek reliable, centralised, and structured information to efficiently discover extracurricular activities. Their pains include scattered sources (Instagram, UQ websites, posters), unclear details, and missed opportunities.

  **Evidence Trace:**

  **[H1](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/lteration%202_Hypothesis1_Learning_Card.md):** We observed that 85.7% of students (24 out of 28)reported difficulty discovering activities because information is scattered across too many sources, which exceeds the 70% validation criterion (**Supported**).

  **[H4](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis4_Learning_Card.md):** We found that 68% of students (15 out of 22) said unclear or missing details prevented them from joining activities, surpassing the 60% criterion (**Supported**).

- **Student Clubs and Event Organizers**

  Student clubs and organizers need a credible and efficient way to promote events to interested students and maintain engagement beyond temporary social media posts.

  **Evidence Trace:**

  **[H1](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/lteration%202_Hypothesis1_Learning_Card.md):** We observed that 85.7% of students (24 out of 28)reported difficulty discovering activities because information is scattered across too many sources, which exceeds the 70% validation criterion (**Supported**).

  **[H8](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/d21f35131f765acc25d2997660e1de89784aac65/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis8_Learning_Card.md):** We found that **68% of students (17 out of 25)** expressed trust in peer-verified or officially validated information sources, meeting the 60% criterion  (**Supported**).

  ​

## **2. Value Propositions**

| **Value Proposition**                                        | **Evidence Trace (Hypothesis & Result)**                     | **Decision** |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------ |
| **Centralized Activity Hub** – Aggregate all UQ, UQU, and club events into one verified and structured platform to solve information fragmentation and awareness problems. | **[H1](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/lteration%202_Hypothesis1_Learning_Card.md) – 85.7% (24 of 28)** students mentioned “too many sources” or “hard to find info,” confirming that fragmented channels hinder discovery - Supported. | **Accepted** |
| **Detailed Event Page** – Provide complete and structured information (time, location, cost, organizer, requirements, registration link) to enhance clarity and decision-making confidence. | **[H4](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis4_Learning_Card.md) – 68% (15 of 22)** said unclear details stopped them from joining activities; <br>**[H7](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis7_Learning_Card.md) – 81.5% (22 of 27)** prioritized time, location, and requirements when deciding - Supported. | **Accepted** |
| **Bookmark Feature** – Allow students to save and revisit activities for convenience and better planning. | **[H5](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis5_Learning_Card.md) – 58% (14 of 24)** would use bookmarking to remember and track events, meeting the 50% threshold - Supported. | **Accepted** |
| **Add to Calendar Function** – Let users sync selected events to their calendar and receive reminders for improved attendance. | **[H6](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis6_Learning_Card.md) – 43.8% (7 of 16)** expressed interest in calendar sync, below the 50% threshold; mainly used for confirmed events - Partly Supported. | **Refine**   |
| **Peer Reviews and Popularity Indicators** – Display peer comments and participation counts to build trust and reduce uncertainty. | **[H8](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis8_Learning_Card.md) – 68% (17 of 25)** trust peer reviews more than posters or emails, validating the trust-building value of feedback(Due to data quality and compliance issues, this feature will not be considered for the current phase.) - Rejected. | **Rejected** |
| **Social & Personal Growth Opportunities** – Emphasize activities that support social connection, skill development, and personal growth. | **[H9](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis9_Learning_Card.md) – 70% (14 of 20)** mentioned social or self-growth as top motivations for joining extracurricular activities - Supported. | **Accepted** |

For further details, please refer to the [Value Proposition Canvas](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Iteration2_Value%20Proposition%20Canvas.md).

## 3. Channels

- **Web Platform** – The primary and most essential channel where students access the verified event list, search and filter activities, bookmark events, and submit feedback. This channel directly delivers the platform’s value proposition by improving discovery, clarity, and engagement.

  **Evidence Trace:**

  **[H1](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/bad3d15249527ab3cf4cb28ec3d713a519595946/Documents/Iteration2/Learning_Test_card/lteration%202_Hypothesis1_Learning_Card.md) :** We observed that 85.7% of students (24 out of 28) reported difficulty discovering activities because information is scattered across too many sources. This finding exceeds the 70% validation criterion, confirming the need for a centralized and reliable online channel (**Supported**). 


- **On-campus activities/events **– A complementary physical channel where students can discover the platform through UQ-organized fairs, orientation booths, or student club promotions. This channel reinforces awareness and trust by connecting the digital platform with real-world student engagement.

  **Evidence Trace:**

  **[H9](https://github.com/COMP1100-7110-2025-s2/Mon_11am_Team_10/blob/d21f35131f765acc25d2997660e1de89784aac65/Documents/Iteration2/Learning_Test_card/Iteration%202_Hypothesis9_Learning_Card.md) :** We observed that 70% of students (14 out of 20) identified social interaction and belonging as a key motivation for joining activities. This validates the inclusion of on-campus events as a physical engagement channel that supports both visibility and community connection (**Supported**).

## 4. Customer Relationships

1. **Personalised Discovery** – Manual tag recommendations (sports, volunteering, culture).
2. **Engagement Loop** – Bookmark and reminder features encourage return visits.
3. **Transparency and Verification** – All events verified through UQ sources, reducing uncertainty.

## **5. Revenue Streams**

****

- **Phase 1 (MVP):** Free for students and organizers to validate engagement and product-market fit.
- **Phase 2 (Future):** Possible funding from UQ, student unions, or sponsorships; optional premium tools (e.g. organizer analytics).

## 6. Feasibility and Scope Control

- **Included:**
  - Activity list and details
  - Search and filter
  - Bookmark and reminder
  - User feedback function
- **Excluded:**
  - Automated web crawling
  - Popularity ranking
  - External organizer evaluation

## 7.  Key Resources

- Web hosting and database (PostgreSQL / PostGIS)
- Verified event data from UQ sources

## **8. Key Activities**

****

- Maintain and update the web platform
- Verify and curate event data
- Conduct user testing and data analysis

## 9. Summary

Iteration 2 transforms the BMC into an evidence-based, feasible, and traceable model.
Each value proposition now links directly to data-backed hypotheses (H1–H9).
The MVP scope focuses on validated, feasible features only.
Clear differentiation from UQ/UQU platforms and verified quantitative evidence demonstrate product–market fit.