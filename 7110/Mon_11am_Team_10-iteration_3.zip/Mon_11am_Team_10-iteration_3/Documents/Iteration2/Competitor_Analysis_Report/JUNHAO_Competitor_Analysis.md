## **Individual Competitor Analysis – Instagram**

Instagram remains the most widely used platform among UQ students for discovering extracurricular activities. While it provides strong visibility and community engagement, our findings show that it lacks clarity, verification, and structured guidance—three factors essential for informed participation. In short, Instagram connects, but it does not guide.

Interviews revealed that 85.7% of students said event information at UQ is scattered and difficult to track (H1). Instagram amplifies this issue: event posts are spread across multiple club accounts, inconsistent in format, and quickly buried by new content. Students often rely on luck or memory to find activities, with no reliable search, filtering, or verification tools. This highlights a gap between social visibility and informational clarity, which our platform directly addresses.

### **Comparative Summary**

| **Feature**            | **Instagram**                      | **Our Platform**                                       |
| ---------------------- | ---------------------------------- | ------------------------------------------------------ |
| **Information Source** | User-generated; unverified         | UQ-verified listings                                   |
| **Structure**          | Visual posts; inconsistent details | Standardised event details (time, place, registration) |
| **Discoverability**    | Algorithm-driven feeds             | Searchable, filterable categories                      |
| **Engagement**         | Passive viewing and likes          | Bookmark, reminder, and feedback features              |
| **Reliability**        | Based on social influence          | Verified and peer-reviewed events                      |

### **Gap Narrative**

Compared with Instagram and UQ/UQU websites, our platform introduces three clear differentiators:

1. **UQ-Verified Data** – Events are manually checked and verified through official UQ sources, removing misinformation and ensuring trust.
2. **Structured Information** – Each event contains consistent details (time, location, requirements, registration), enabling faster and clearer decision-making.
3. **User Engagement Loop** – Bookmark, reminder, and feedback functions transform awareness into measurable participation.

Instagram offers visibility without structure, while UQ websites offer accuracy without discoverability. Our platform bridges this divide—combining credibility, clarity, and usability to convert social visibility into real engagement.

### **PMF (Product–Market Fit) Summary**

| **User Pain Point**          | **Validated Solution**                           | **Quantitative Result**                                      |
| ---------------------------- | ------------------------------------------------ | ------------------------------------------------------------ |
| Scattered event information  | Centralised verified event list                  | **85.7%** students reported improved discovery (**H1**)      |
| Unclear or missing details   | Structured event page (time, cost, registration) | **68%** identified clearer decisions (**H4**); <br>**81.5%** valued detailed information (**H7**) |
| Forgetting or missing events | Bookmark & calendar reminder                     | **58%** would use bookmark; **43.8%** use reminders (**H5**, **H6**) |
| Low trust in event sources   | Verified listings with feedback                  | **68% (17/25)** trusted verified and peer-reviewed listings (**H8**) (**validated but excluded from MVP due to compliance risk**) |
| Low motivation               | Personalised, goal-based events                  | **70% (14/20)** said growth or connection drives participation (**H9**) |

### **Conclusion**

The analysis shows that Instagram dominates in reach but not reliability. It spreads awareness but fails to convert it into participation due to fragmented, short-lived, and unverified information.
Our platform directly fills this gap—transforming visibility into verified participation through reliable data, structured content, and engagement tools.
These validated results (**H1–H9**) confirm strong product–market fit and demonstrate that our system more effectively supports UQ students’ real needs than existing alternatives.