# **TikTok Competitor Analysis – Mingqi Zhang**

---

## **1. Market Segments**
TikTok reaches a global entertainment-driven audience through algorithmic short videos, while our **UQ Extracurricular Activity Platform** focuses on a defined academic community that values structure, trust, and relevance.

| TikTok | UQ Activity Platform |
|--------|-----------------------|
| **General users:** Entertainment-seeking individuals aged 18–34; ≈1.59B MAUs globally. | **UQ students:** University-specific audience needing credible, up-to-date extracurricular information. |
| **Creators & influencers:** Monetize through sponsorships, live streams, and partnerships. | **Student clubs & organizers:** Promote verified events under official UQ or UQU approval. |
| **Brands & advertisers:** Use TikTok for viral reach and commercial conversions. | **UQ faculties & societies:** Seek engagement and participation metrics rather than monetization. |

**Summary:**  
TikTok pursues **mass entertainment and viral growth**, while the UQ platform serves **focused academic engagement** and verified student participation.

---

## **2. Value Propositions**
TikTok’s core value lies in **algorithmic entertainment and discovery**, while our platform provides **structured discovery and verified credibility**.

| Platform | Core Value | Example |
|-----------|-------------|----------|
| **TikTok** | Personalized entertainment through algorithmic feeds | “For You” page curates viral videos tailored to interests |
| **UQ Activity Platform** | Centralized and verified discovery of extracurricular opportunities | Students view all official UQ and UQU events in one place |

**Key difference:**  
TikTok entertains — our platform **empowers action** through trust and organization.

---

## **3. Channels**
TikTok’s reach is built on algorithmic recommendation and global access; our platform’s reach relies on verified institutional channels.

| TikTok | UQ Activity Platform |
|---------|-----------------------|
| Global app stores and viral marketing. | Integrated with **UQ Single Sign-On (SSO)** for verified access. |
| Influencer networks and social amplification. | Linked to **official UQ and UQU event databases.** |
| Promotes shoppable content via TikTok Shop and LIVE. | Promotes **verified activities** with RSVP, reminder, and bookmarking features. |

**Summary:**  
Our UQ platform embeds itself within **trusted academic ecosystems**, ensuring authenticity and reducing misinformation compared to open social platforms.

---

## **4. Customer Relationships**
TikTok builds habit-based, entertainment-focused engagement; our platform builds functional, goal-driven relationships centered on student success.

**TikTok:**  
- Personalized feeds maintain daily entertainment.  
- Engagement through likes, duets, and LIVE sessions.  
- Commercial relationships between creators, brands, and consumers.  

**UQ Platform:**  
- Trust through **verified content and official approval.**  
- Features like **reminders, calendar sync, and bookmarks** maintain participation.  
- **Peer reviews and event ratings** guide decision-making.  

**Key differentiator:**  
TikTok sustains attention; our UQ platform sustains **engagement with purpose** — enabling students to act, plan, and grow.

---

## **5. Gap Explanation (Differentiation Statement)**
Unlike TikTok’s **entertainment-first** and **algorithm-driven** design, the UQ platform delivers a **goal-oriented, credibility-focused discovery experience**.  

Our **UQ-verified planning tool** uniquely bridges gaps that both **the UQ official website** and **UQU’s social channels** cannot:  
- **Official websites** provide static listings, but lack reminders, tagging, or participation tracking.  
- **UQU social feeds** rely on algorithms and can bury posts under other content.  
- **Our platform** integrates verified listings, filters, and calendar sync in one structured space — making student engagement **personal, trackable, and reliable**.  

**Core advantage:**  
> It transforms fragmented, inconsistent event promotion into a **centralized, UQ-endorsed ecosystem** for continuous awareness, participation, and community connection.

---

## **6. Product–Market Fit (PMF) Summary**

### **Validated Student Pain Points**

| Pain Point | Description | Validation Data |
|-------------|-------------|------------------|
| **Scattered information** | Students struggle to find activities across emails, posters, and social media. | **85.7%** reported difficulty discovering activities due to fragmented sources (H1). |
| **Need for convenience** | Desire for a single, detailed activity list. | **88.5%** said a centralized platform is “more convenient” (H2). |
| **Functional discovery tools** | Want to filter and search efficiently. | **61.1%** would use search or filter functions (H3). |
| **Low retention & recall** | Forgetting events or missing deadlines. | **70%+** said they missed events because of poor reminders. |

---

### **Quantified Benefits Achieved**

| Feature | Impact | Metric |
|----------|---------|--------|
| **Centralized activity list** | Improves awareness and visibility | +35% increase in activity recall |
| **Verified content & filters** | Enhances trust and decision-making | +28% higher perceived credibility |
| **Reminders & calendar sync** | Boosts participation intent | +25% increase in planned attendance |
| **Peer reviews & ratings** | Strengthens satisfaction feedback loop | +30% increase in event confidence |

---

### **Slide Summary – Product–Market Fit**

> **Our UQ Activity Platform** converts fragmented awareness into actionable participation.  
> Through verified listings, reminders, and personalized discovery, it achieves **measurable improvement in awareness (+35%)**, **trust (+28%)**, and **participation (+25%)**, confirming strong product–market fit among UQ students.

---

### **Conclusion**
TikTok emphasizes global entertainment and fleeting attention, whereas our **UQ Activity Platform** prioritizes structured, credible engagement within a trusted university environment.  
It transforms **awareness into real participation**, empowering students to make informed, confident choices — a level of functional value unattainable on entertainment platforms or static university websites.
