# UQU Event Website Competitor Analysis - Jeric Zhang (Ji Zhang)

The UQU Event Website is a centralized platform for student events at the University of Queensland. It helps users find and join extracurricular activities, especially those organized by clubs and student groups.

## 1. Market Segments

1. UQ Students (Core Segment): UQ students are the main users, looking for extracurricular activities to gain new experiences, join clubs, meet friends, and enjoy campus life.
2. UQ Stuff: A small group of users also includes staff, who may attend some events.
3. General Public: Some special activities are also open to the general public, such as market day and cultural festival.
4. Activity Organizers (Indirect Segment): Although they are not direct users, they need this platform to promote their activities and attract participants.
In summary, the UQU Events Website mainly targets UQ students but also serves a wider group of users, including UQ staff, the general public and activity organizers.

---

## 2. Value Propositions

The UQU Events Website provides an authoritative, reliable platform for users to find activities. It shows clear and accurate information about time, location, cost, and more details. Unlike social media, where activity information is scattered and needs to be searched, the UQU Event Website collects everything in one place. It also offers calendar reminders and direct ticket booking, making it easy for users to plan and register.
In contrast to the official UQ Event Website, which mainly highlights formal university activities, the UQU Events Website focuses more on student-led activities and club events, making it a lively platform for campus life.

Competitor Gap Narrative:
While the UQU website promote student events, their coverage is limited mainly to UQU-related activities. This narrow focus leads students to miss many good activities organized by other UQ clubs, schools, or other organizers. In addition, event details on this platform are often brief, with no personalised planning tools.
Our product addresses this gap by consolidating all extracurricular activities across UQ into a single, reliable platform. It provides detailed event pages, bookmarking, and calendar reminders, helping students easily discover, save, and plan events that match their interests. These features make our platform significantly more useful than UQU website.

---

## 3. Channels

The main channel of UQU Events Website is the website itself, but UQU also uses social media (Instagram, Tiktok, Facebook), email subscription and posters across the campus to reach users and promote activities. On the website, UQU also provides direct links to these social media platforms. These different channels make sure the information reaches both online and offline users.

---

## 4. Customer Relationships

The UQU Events Website builds customer relationships mainly through automated services. These include activity list, activity details, calendar reminder and ticket booking. The website is designed to reduce complex information structure and make participation easier. User-friendly interactions enable users to get key information and complete most functional operations by their own.

---

## 5. PMF

| **User Pain Point** | **Validated Solution** | **Quantitative Result (Evidence)** |
|----------------------|------------------------|------------------------------------|
| Activity information is scattered across multiple sources (UQU site, social media, emails), making discovery difficult. | **Centralised Activity Hub** – consolidate all UQ, UQU, and club events into one verified platform. | **H1 – 85.7% (24/28)** reported “too many sources” or “hard to find info,” confirming the need for a single, centralised platform. |
| Students find event details unclear or incomplete, reducing participation confidence. | **Detailed Event Page** – Provide structured details (time, location, cost, organizer, registration link). | **H4 – 68% (15/22)** said unclear details stopped them from joining; **H7 – 81.5% (22/27)** prioritized time and location when deciding. |
| Students struggle to keep track of interesting events or forget about them later. | **Bookmark Feature** – Allow bookmarking activities for easy recall and planning. | **H5 – 58% (14/24)** would use bookmarking to remember and track activities. |
| Students want reminders to avoid missing events but prefer control over scheduling. | **Add to Calendar Function** – Enable calendar or other reminders for confirmed events. | **H6 – 43.8% (7/16)** showed interest; partially supported, indicating room for refinement. |
| Students seek social connection and personal development opportunities through extracurriculars. | **Social & Personal Growth Focus** – Highlight events that foster social interaction and skill development. | **H9 – 70% (14/20)** mentioned social or self-growth as main motivations for participation. |


---

## 6. Summary

Overall, the UQU Events Website creates value by offering users (mainly UQ students) a clear, reliable, and convenient platform to discover and join extracurricular activities. In addition, it makes event planning easier, reduces the risk of missing important activities, and encourages students to participate more actively in campus life.
However, it mainly covers UQU-related activities. In contrast, our UQ-specific, verified planner consolidates all student activities across the university with detailed information, bookmarking, and calendar reminders, which user testing shows effectively addresses key pain points like fragmented information and unclear details.