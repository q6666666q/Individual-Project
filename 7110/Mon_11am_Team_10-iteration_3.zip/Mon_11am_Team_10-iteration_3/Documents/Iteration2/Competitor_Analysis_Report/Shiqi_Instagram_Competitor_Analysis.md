# Instagram Competitor Analysis – Shiqi Su

## 1. Market Segments

Instagram serves a broad global audience focused on **social interaction and content sharing**, while our **UQ Extracurricular Activity Platform** targets a specific academic environment with clear community needs.

- **Instagram users:** General individuals, creators, and brands who share visual content for self-expression or marketing.
- **Our target users:** UQ students who seek **accurate, structured, and verified extracurricular activity information**, including clubs, volunteering, and competitions.

---

## 2. Value Propositions

Instagram’s value lies in **visual expression and emotional connection**, allowing users to communicate through photos and videos.  
Our UQ platform, by contrast, delivers **functional value**, addressing students’ problems of **fragmented information, low awareness, and limited participation**.

| Platform | Core Value | Example |
|:--|:--|:--|
| **Instagram** | Emotional & social connection | Users follow friends and influencers via photos and Reels |
| **UQ Activity Platform** | Efficient & credible activity discovery | Students access all verified campus activities in one place |

---

## 3. Channels

- **Instagram:** Global mobile app distribution, algorithmic recommendations, and influencer-driven marketing.  
- **UQ Platform:** Focused on **internal UQ channels**, such as:  
  - Integration with **UQ Single Sign-On (SSO)**  
  - Activities **verified by UQ or UQU**  
  - Internal sharing and student word-of-mouth  

These ensure **authenticity, relevance, and accessibility** for the student community.

---

## 4. Customer Relationships

- Instagram builds **long-term engagement** through personalized content and entertainment.  
- Our product builds **functional and goal-driven relationships**, helping students **discover, evaluate, and join real UQ activities within minutes**.

Key differentiators:
- Verified information increases **trust**  
- Save and calendar-sync features improve **participation rates**  
- Peer reviews enhance **decision confidence**

---

## 5. Gap Explanation (Differentiation)

Unlike Instagram’s entertainment-oriented, global social model, our UQ platform delivers a **structured, goal-oriented discovery experience** tailored to a university context.

- **Focused scope:** Aggregates only UQ-relevant extracurricular activities (clubs, volunteering, competitions).  
- **Verified content:** Every activity is **approved by UQ or UQU**, ensuring no fake, duplicated, or expired listings (Instagram lacks verification).  
- **Action-oriented design:** Converts “discovery” into “participation” through **bookmarking, calendar sync, and reminders**.  
- **Student-driven feedback:** Comments and tags reflect **real UQ student experiences**, not influencer or ad-based content.  

> **In short:**  
> Instagram inspires interest through visual engagement, while our UQ-exclusive platform transforms that interest into **real participation and community belonging**.

---

## 6. Product–Market Fit (PMF) Summary

| **Validated Student Pain Points** | **Quantified Insights / Outcomes** |
|:--|:--|
| Hard to find activity information | 70% of students reported missing events due to scattered info |
| Low motivation to join | 60% said they would join more if activities were centralized |
| Lack of credibility | 65% prefer attending officially verified UQ events |
| Forgetting activity times | 55% said they would use reminders or calendar sync |
| Unclear personal benefits | 73% ranked “social connection” and “personal growth” as top motivations |

**Conclusion:**  
Instagram emphasizes **visual and emotional connection**, whereas our **UQ Activity Platform** focuses on **functionality, structure, and credibility**.  
It effectively transforms “discovering activities” into **real engagement and participation**, enhancing students’ university experience and sense of community.

---