# TikTok Competitor Analysis – Zhaoguo Huang

## Market Segments
TikTok primarily targets general social media users, including university students who browse casually.  
For extracurricular activities, clubs and organizations occasionally post promotional videos, but these posts are not organized or easily searchable.  
Its audience is wide and entertainment-focused, not tailored to the needs of UQ students.

**Our Platform:**  
Focuses exclusively on **UQ students** and **club organizers**.  
By narrowing the target, we can design features that align with academic schedules, student interests, and the UQ context.

---

## Value Proposition
TikTok’s main value lies in **entertainment and viral discovery**.  
While students may occasionally find campus events through short videos, the information is scattered, incomplete, and lacks reliability.

**Our Platform offers clarity and structure:**
1. One centralized hub for all UQ extracurricular activities.  
2. Detailed and verified event information (time, location, cost, organizer, requirements).  
3. Bookmark and calendar reminders to manage time effectively.  
4. Peer reviews and popularity counts to support decision-making.

**In short:**  
TikTok helps students *discover by chance*, while our platform helps them *plan with confidence*.

---

## Customer Channels
TikTok engages users through algorithmic feeds — discovery is **passive** and based on chance.  
Our platform uses **intentional discovery channels** such as:
- Search and filter tools for purposeful exploration.  
- Calendar and reminders for active planning.  
- Peer reviews and club follow features for community connection.

---

## Customer Relationships
TikTok builds short-term engagement loops (likes, shares, views) but does not foster **lasting connections** between students and activity organizers.

**Our Platform focuses on trust and continuity:**
- Verified organizers can post activities directly to students.  
- Students can follow organizers, bookmark activities, and receive reminders.  
- Peer reviews create accountability and long-term engagement.

---

## Gap Narrative – Why Our Platform Is Unique
Compared with TikTok’s random exposure and the **static, fragmented listings** on UQ and UQU websites,  
our platform acts as a **UQ-verified, structured activity planner** — turning scattered information into clear, personalized guidance.  
It uniquely combines **clarity (verified details, filters)** and **engagement (reviews, reminders)** to promote consistent participation — something no existing channel currently provides.

---

## Product–Market Fit Summary

| **User Pain Points (from interviews)** | **Validated Insights (Hypothesis Data)** | **Result** |
|----------------------------------------|-------------------------------------------|-------------|
| Scattered event info across multiple channels | Students confirmed the need for a centralized hub | 87% mentioned information fragmentation |
| Hard to judge relevance (unclear time, cost, requirements) | Students prioritized these details when deciding | H7 supported – 81.5% |
| Forgetting or missing events | Some students valued optional calendar reminders | H6 partly supported – 43.8% |
| Low trust in event quality | Peer reviews and “popularity counts” seen as helpful | Qualitative support |

**Summary:**  
Interview data confirms strong demand for **clarity, organization, and trustworthiness** in activity discovery.  
The most validated features — **detailed information and centralization** — demonstrate measurable product–market fit.  
Future iterations should refine reminder features and maintain focus on verified, student-centric design.

---
