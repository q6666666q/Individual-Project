 # Falsifiable Hypotheses


## Awareness

| ID | Hypothesis (Quantified Statement) | Related Question | Success Threshold |
|:--:|:--|:--|:--|
| **H1** | ≥70% of participants state that **difficulty finding or missing activities** is due to scattered information sources. | **Value Proposition Q1** | ≥70% |
| **H2** | ≥70% of participants believe that a **centralized platform with detailed information** is “more convenient.” | **Value Proposition Q2 MVP Q1** | ≥70% |
| **H3** | ≥60% of participants express **willingness to use search or filter functions** when exploring activities. | **MVP Q4** | ≥60% |

---

## Participation

| ID | Hypothesis (Quantified Statement) | Related Question | Success Threshold |
|:--:|:--|:--|:--|
| **H4** | ≥60% of participants list **“unclear or missing information”** as a main reason for not joining activities. | **Value Proposition Q4, Q5** | ≥60% |
| **H5** | ≥50% of participants say they would use the **Save/Bookmark** feature to track interesting activities. | **MVP Q3** | ≥50% |
| **H6** | ≥50% of participants say they would use the **Add to Calendar** feature to plan participation. | **MVP Q3** | ≥50% |
| **H7** | ≥70% of participants agree that **time, location, and detailed descriptions** help them make participation decisions. | **MVP Q2** | ≥70% |

---

## Satisfaction & Expected Gains

| ID | Hypothesis (Quantified Statement) | Related Question | Success Threshold |
|:--:|:--|:--|:--|
| **H8** | ≥60% of participants believe that **peer reviews or ratings** increase their trust or willingness to join. | **MVP Q5, Q6** | ≥60% |
| **H9** | ≥60% of participants rank **“social connection / personal growth”** as a top expected gain from joining activities. | **Value Proposition Q3** | ≥60% |

