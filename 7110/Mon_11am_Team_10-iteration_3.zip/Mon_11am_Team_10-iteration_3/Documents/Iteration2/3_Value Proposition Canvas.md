# Value Proposition Canvas - Iteration 2

---

### 1. Customer Profile  

**Jobs**  
- Discover and join extracurricular activities that match personal interests.  
- Balance study workload with meaningful leisure time.  
- Meet new people and build social connections on campus.  
- Gain new skills and experiences for career and personal growth.  

**Pains** 
- Information is scattered across multiple sources (emails, posters, social media, word of mouth).
  - *Evidence:* H1–H3 – 24/28 students (85.7%) said activity information is fragmented and hard to find.  
- Descriptions of activities are vague — hard to judge if it’s worth attending.
  - *Evidence:* H7 – 22/27 (81.5%) students said time, location, and clear requirements are essential for deciding.
- Time conflicts with lectures or assignments make planning difficult.  
- Some students feel anxious about joining unfamiliar or established groups.
- Poor event organization (e.g., unclear details, long queues) discourages participation.  

**Gains** 
- Want a single, reliable platform to find all verified UQ activities.
  - *Evidence:* H1 – 85.7% (24/28) mentioned “too many sources” (Supported)  
- Want clear and structured activity details (time, location, requirements, cost).  
  - *Evidence:* H7 – 81.5% (22/27) said these details matter most (Supported)  
- Want reminders or calendar sync to avoid forgetting events. 
  - *Evidence:* H6 – 43.8% (7/16) would use it, mainly for confirmed activities (Refine)  
- Want reviews and popularity info to help decide confidently.  
  - *Evidence:* H8 – 68% (17/25) trust peer feedback more than posters (Supported)  
- Want bookmarks and personalized suggestions for convenience.  
  - *Evidence:* H5 – 58% (14/24) would use bookmark (Supported)  
- Value activities that support social connection and self-development.  
  - *Evidence:* H9 – 70% (14/20) mentioned “growth opportunities” (Supported)  

---

### 2. Value Map

**Products & Services**
- Centralized activity hub with search and filtering.  
- Detailed event pages (time, location, cost, organizer, target audience).  
- Bookmark and “Add to Calendar” features.  
- Reminder notifications (push / calendar sync).  
- Peer reviews and popularity indicators.  
- Personalized recommendations (by interest or study area).  

---

**Pain Relievers**  
- **Solves scattered info problem** → aggregates UQ, UQU, and club events in one verified space.  
  - *Evidence:* H1 – 85.7% (24/28) mentioned “too many sources.” (Supported)  
- **Clarifies activity details** → provides transparent info for confident decisions.  
  - *Evidence:* H7 – 81.5% (22/27) prioritised details like time/location/requirements. (Supported)  
- **Helps with planning** → optional reminders and calendar sync for time management.  
  - *Evidence:* H6 – 43.8% (7/16) interested, mainly when attending. (Refine)  
- **Builds trust** → peer reviews and popularity stats reduce uncertainty.  
  - *Evidence:* H8 – 68% (17/25) said reviews increase reliability. (Supported)   

---

**Gain Creators**  
- **Simplifies discovery** → easy search and filtering save time.  
- **Improves decision confidence** → structured details and verified info.  
- **Boosts engagement** → shows trending/popular events to encourage attendance.  
- **Supports growth** → helps students find activities that build skills and connections.  
- **Reinforces community belonging** → promotes participation across diverse student groups.  

---

### 3. Hypotheses

| **ID** | **Hypothesis** | **Key Metric / Result** | **Decision** |
|:------:|----------------|--------------------------|---------------|
| **H1** | Centralised Activity List | 85.7% (24/28) mentioned “too many sources” | Supported |
| **H2** | Centralised Platform Increases Convenience | 88.5% (23/26) agreed a single platform with detailed info is more convenient | Supported |
| **H3** | Users Will Use Search & Filter Functions | 61.1% (11/18) expressed willingness to use search/filter when browsing activities | Supported |
| **H4** | Detailed Event Page Reduces Uncertainty | 68% (15/22) said unclear details stop them from joining | Supported |
| **H5** | Bookmark Feature Increases Follow-up | 58% (14/24) would use bookmark | Supported |
| **H6** | Add to Calendar Helps Attendance | 43.8% (7/16) interested; useful only after confirmation | Refine |
| **H7** | Detailed Info Aids Decision | 81.5% (22/27) prioritised time/location/requirements | Supported |
| **H8** | Peer Reviews Build Trust | 68% (17/25) trust peer reviews more than posters | Supported |
| **H9** | Social & Personal Growth Motivates Use | 70% (14/20) mention skill or personal growth | Supported |

---

### 4. Insights Summary  

- **Information fragmentation is the main barrier.**  
  Across multiple interviews, over 80% of participants reported missing activities because event information was scattered across too many channels (H1–H3). This validates the need for a unified, verified event hub as a core pain reliever.  

- **Clarity drives participation.**  
  Students consistently emphasized that clear, well-structured activity details (H4, H7) are the key factor influencing their decision to join. These hypotheses form the strongest evidence-based pillars of our value proposition.  

- **Convenience features add value but need refinement.**  
  Functions like bookmarks and calendar reminders (H5, H6) are appreciated by students who plan their schedules proactively, but the calendar feature is not essential for all users.  

- **Social and personal growth are key motivators.**  
  Students see extracurricular activities not only as recreation, but also as opportunities for building connections, developing skills, and enhancing personal growth (H9).  

---
