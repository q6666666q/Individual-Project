## Learning Card - Hypothesis 1
We believed that ≥70% of participants would state that difficulty finding or missing activities is caused by scattered information sources across multiple channels.
We observed that 24 out of 28 participants (85.7%) mentioned that event information was fragmented — coming from emails, social media, friends, or posters — and several admitted missing activities because they did not know where to check.
From this we learned that information fragmentation is the primary barrier to awareness. Students clearly need a centralized and reliable information hub for extracurricular activities.
Therefore, we accept this hypothesis, confirming that our platform’s goal of centralizing activity data directly addresses the most common awareness pain point.

## Learning Card - Hypothesis 2
We believed that ≥70% of participants would agree that a centralized platform with detailed information is “more convenient” than current sources.
We observed that 23 out of 26 participants (88.5%) agreed that having a single, detailed event list would make participation easier. They emphasized convenience, time efficiency, and the ability to compare events quickly without switching between apps.
From this we learned that a centralized structure greatly improves perceived convenience and reduces the cognitive effort of finding reliable activity information.
Therefore, we accept this hypothesis, confirming the strong user demand for a unified activity platform.

## Learning Card - Hypothesis 3
We believed that ≥60% of participants would express willingness to use search or filter functions when exploring activities.
We observed that 11 out of 18 participants (61.1%) said they would use these features, most preferring time or popularity sorting options. Participants noted that filters could help them find events faster and avoid information overload.
From this, we understand that search and filtering directly support user engagement and enhance decision-making efficiency.
Therefore, we accept this hypothesis, and will conduct a follow-up test comparing different filter types to optimize engagement.

## Learning Card – Hypothesis 4

We believed that unclear or missing information prevents students from joining extracurricular activities.
Through interviews, we observed that 15 out of 22 students (≈68%) mentioned issues such as unclear event time, location, or registration steps as reasons for not attending.
We learned that the clarity and completeness of event information strongly influence students’ willingness to participate.
Therefore, this hypothesis is supported by our findings.

## Learning Card - Hypothesis 5

We believed that at least half of the students would use a Save/Bookmark feature to manage extracurricular activities.
From the interviews, we observed that 14 out of 24 students (≈58%) said they would use this feature to keep track of events they might join later.
We learned that the bookmarking function helps students organise and remember activities, particularly when they are busy or exploring multiple options.
Therefore, this hypothesis is supported by our findings.

## Learning Card – Hypothesis 6

We believed that around half of the students would use the Add to Calendar feature to manage their schedules and avoid missing activities.
We observed that 7 out of 16 students (43.8%) said they would probably use this feature to stay organized, but quite a few mentioned they didn’t really see a need for it in most situations.
From that we learned that the feature is useful mainly for students who are already planning to attend an event. Many students said they prefer to just remember or check later, especially for casual or less important activities.
Therefore, we will partly support this hypothesis. In the next stage, we’ll try to make the feature more flexible—maybe adding optional reminders or smart suggestions that appear only when a student confirms participation, instead of applying it to every event.

## Learning Card – Hypothesis 7

We believed that 70% of students would value clear details such as time, location, and requirements when deciding whether to attend an activity.
We observed that 22 out of 27 students (81.5%) highlighted time, location, and cost as the most important information influencing their decision.
From that we learned that students rely on transparent and structured details to make confident participation choices. Missing or unclear information reduces trust and interest in activities.
Therefore, we will support this hypothesis and ensure all activity cards in the MVP clearly display time, location, and cost as standardized fields.

## Learning Card - Hypothesis 8

We believed that 60% students would trust peer reviews or ratings.
We observed that 17 out of 25 students (68%) said peer reviews and ratings are important to them and help them decide. The remaining students think the reviews could be biased, or they believe feedback from classmates around them is more trustworthy.
We learned that many students trust their peers’ views, and this feedback is a important factor in getting them more willing to participate in activities.
Therefore, we support this hypothesis.

## Learning Card - Hypothesis 9

We believed that 60% of students would list “social connection or personal growth” as their main benefits.
We observed that 14 out of 20 students (70%) mentioned these as their top motivations.
We learned that social belonging and self-improvement are strong emotional drivers for participation.
Therefore, we support this hypothesis.

