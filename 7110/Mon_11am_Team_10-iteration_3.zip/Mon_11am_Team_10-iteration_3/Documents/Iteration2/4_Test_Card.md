## Test Card - Hypothesis 1
We believe that UQ students often find it difficult to discover or remember extracurricular activities because information is scattered across multiple channels such as emails, social media, and posters, leading to missed opportunities.
To verify that, we will interview 28 UQ students and ask them about how they usually hear about activities and whether they have ever missed one because of information fragmentation.
And measure how many participants explicitly mention “too many sources,” “hard to find,” or “missed activities.”
We are right if 70% or more (at least 20 participants) report that scattered information is the main reason for difficulty or missing events.
Therefore, we will ask:
“How do you usually hear about activities at UQ?”
“Have you ever missed one because you didn’t know about it?”

## Test Card - Hypothesis 2
We believe that ≥70% of participants will agree that a centralized platform with detailed information is “more convenient.”
To verify that, we will interview 26 UQ students about their views on featuring activity lists and detailed pages.
And measure how many participants say that a centralized platform is more convenient than their current ways of discovering activities.
We are right if 70% or more (at least 19 participants) agree that the centralized platform is more convenient and easier to use.
Therefore, we will ask:
“Do you think a centralized list of activities with details like time and cost would be more convenient than your current sources (social media, email, posters)?”

## Test Card - Hypothesis 3
We believe that UQ students will express willingness to use search or filter functions (by time, category, or popularity) when exploring activities, because these features help them find relevant events quickly and reduce information overload.
To verify that, we will interview 18 students and ask them about their preferences and expectations regarding search bars and filtering options.
And measure how many participants say they would use these functions regularly when browsing activities.
We are right if 60% or more (at least 11 participants) express willingness to use search or filter tools.
Therefore, we will ask:
“Would you use a search or filter function when looking for activities? If yes, what kind of filters would you prefer?”

## Test Card - Hypothesis 4
We believe that at least 60% of students identify unclear or missing information as one of the main reasons for not joining extracurricular activities.  
To verify that, we will interview 28 UQ students and ask them what usually stops them from joining more activities.  
We will measure how many explicitly mention “unclear details,” “missing information,” or “confusing instructions.”  
We are right if ≥60% (≥13 students) mention unclear or missing information as a key barrier.  
Therefore, we will ask:  
- “On average, how many activities do you usually join each semester? What usually stops you from joining more?”  
- “Have there been situations where you wanted to go but decided not to? Why?”

## Test Card - Hypothesis 5
We believe that at least 50% of students would use a Save/Bookmark feature to keep track of extracurricular activities they find interesting.
To verify this, we will interview 28 UQ students and present the concept of a Save/Bookmark function.
We will measure how many participants say they would use or find this feature helpful for managing event information.
We are right if 50% or more (≥12 students) indicate that they would use the Save/Bookmark feature.
Therefore, we will ask:  
- “If there was a feature to save or bookmark activities for later, would you use it? Why or why not?”

## Test Card - Hypothesis 6
We believe that at least 50% of students would use an Add to Calendar feature to help manage their schedules and avoid missing activities.
To verify that, we will conduct short interviews with 16 students, describing the Add to Calendar function and asking whether they would use it to keep track of upcoming events.
And measure how many students express clear interest in using the feature (verbally confirming that they would use it).
We are right if 50% or more (≥8 out of 16 students) say they would use the feature to help manage their time or avoid missing activities.
Therefore, we will ask: “What kind of reminder would be most helpful for you (push notification, email, calendar sync) to avoid forgetting activities?”

## Test Card - Hypothesis 7
We believe that at least 70% of students agree that clear information such as time, location, and requirements helps them decide whether to attend an activity.
To verify that, we will interview 27 students and ask them what kinds of information they look for on an activity page before deciding to join.
And measure how many students mention time, location, or cost as key factors influencing their participation decision.
We are right if 70% or more (≥19 out of 27 students) identify these details as important or essential when choosing to attend.
Therefore, we will ask: “What kind of information would you want to see on an activity page before deciding to join?”

## Test Card - Hypothesis 8
We believe that at least 60% of students say peer reviews or ratings would increase their trust or willingness to join activities.
To verify that, we plan to conduct a questionnaire to 30 students, with 25 of them being asked questions about their trust in this feedback.
And measure how many agree that reviews and ratings are “important”.
We are right if ≥60% (≥15 students) agree.
Therefore, we will ask:
“Would you trust short reviews or ratings from other students when deciding whether to attend an activity? And why?”

## Test Card - Hypothesis 9

We believe that at least 60% of students rank “social connection or personal growth” as a top motivation for joining activities.
To verify that, we will ask participants to rank what they expect to gain.
We are right if ≥60% (≥12 students) mention these in their response.
Therefore, we will ask:
“What do you hope to gain from participating in extracurricular activities?”