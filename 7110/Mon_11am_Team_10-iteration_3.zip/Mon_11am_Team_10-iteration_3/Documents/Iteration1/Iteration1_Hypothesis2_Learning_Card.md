# Learning Card 2

**HYPOTHESIS**
We believe that: 1. The current participation rate of students in extracurricular activities is low; 2. After using the platform for a period of time(For example, 1 month), at least 60% of active users will achieve three behaviors — visit more than 5 different activity pages, bookmark at least 2 activities, and click through to the official activity website at least once.

**Data/Information Source**
Summary of UQ Student Extracurricular Activities Survey (focusing on the questions and answers for low participation and current behavioral characteristics).

**Key Findings**
1. The survey shows that students' overall participation rate is really low, with core reasons including "lack of advance planning", "time conflicts with courses", "high entry barriers for freshmen", and "participating passively rather than actively seeking activities".
2. Only a small number of students participate in extracurricular programs through clubs or volunteer activities, while most students do not participate due to obstacles. If we want to solve this problem, at first we must address the "existing participation obstacles" to improve the compliance rate of their behaviors.

**Verification Result**
1. The Hypothesis that "the current student participation rate is low" is valid (directly supported by survey data)
2. To achieve the target of the platform participation hypothesis, it is necessary to address the obstacles encountered by users one by one.