# Learning Card

## Hypothesis 1: Awareness

**HYPOTHESIS**  
We believe that after using the platform for one semester, at least 70% of users will be able to correctly list more than 5 extracurricular activities at UQ.  

**OBSERVATION**  
From 8 interviews:  
- Some students could list several activities such as Photography Club, Basketball Club, Debate Society, and UQ Volunteers.  
- However, other students said they had no idea about any activities.  
- Information sources mentioned: UQU International Instagram, posters, student portal, and friends.  

**LEARNING & INSIGHTS**  
Awareness among students is uneven. Some are well-informed, while others (especially new or international students) know very little or none. This suggests that extracurricular information is scattered and not easy to access.  

**DECISION & ACTION**  
We reject the hypothesis. Less than 70% of students can list more than 5 activities. Our platform should focus on centralizing and simplifying access to extracurricular information, especially targeted at new students.  