# Test Card (Hypothesis 3 – Satisfaction) #

## HYPOTHESIS ##
We believe that after one semester, at least 70% of users will give a score of 7 or above (out of 10) in the satisfaction survey for the platform.

## TEST ##
To verify this, we will conduct a survey at the end of the semester, asking students to rate their satisfaction with the platform and the activities they attended.

## METRIC ##
Average satisfaction score (out of 10) and percentage of students giving a score ≥ 7.

## CRITERIA ##
We are right if at least 70% of students give a score ≥ 7.

## INTERVIEW QUESTIONS ##

Overall, how satisfied are you with the activities you attended?

What did you like most about the platform and the activities?

What would you like to see improved?
