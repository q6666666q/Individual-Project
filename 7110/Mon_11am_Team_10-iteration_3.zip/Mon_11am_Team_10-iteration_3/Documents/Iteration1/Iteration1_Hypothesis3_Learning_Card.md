# Learning Card #

## Hypothesis 3: Satisfaction ##

## HYPOTHESIS ##
We believe that after one semester, at least 70% of users will give a score of 7 or above (out of 10) in the satisfaction survey for the platform.

## OBSERVATION ##
From five interviews, three students rated their satisfaction at 7 or higher, mentioning they enjoyed the variety of activities and the chance to meet new people. However, two students gave lower scores (5–6), noting that scheduling conflicts and lack of reminders reduced their overall satisfaction. Some also mentioned they were unsure how to choose activities that matched their personal interests.

## LEARNING & INSIGHTS ##
Overall satisfaction is positive but not evenly distributed. Students value diversity and social opportunities, but logistical issues (e.g., unclear schedules, lack of reminders) lower ratings for some. First-year and international students particularly struggle with navigating the options.

## DECISION & ACTION ##
We partially accept the hypothesis. While a majority are satisfied, the target of 70% scoring ≥7 was not fully achieved. The platform should improve event scheduling visibility, send timely reminders, and provide personalized recommendations to boost overall satisfaction.
