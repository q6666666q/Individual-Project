# Test Card

## Hypothesis 1: Awareness

**HYPOTHESIS**  
We believe that after using the platform for one semester, at least 70% of users will be able to correctly list more than 5 extracurricular activities at UQ.  

**TEST**  
To verify this, we will interview and survey UQ students, asking them to list extracurricular activities they know without checking online.  

**METRIC**  
Count how many activities each student can list.  

**CRITERIA**  
We are right if at least 70% of students can list more than 5 activities.  

**INTERVIEW QUESTIONS**  
1. Have you heard about extracurricular activities at UQ?  
2. Could you give some examples?  

