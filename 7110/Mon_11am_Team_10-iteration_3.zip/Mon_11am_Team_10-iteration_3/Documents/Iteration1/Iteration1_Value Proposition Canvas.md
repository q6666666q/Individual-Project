# Value Proposition Canvas

# UQ Extracurricular Activity Platform


## Customer Jobs
- Discover and join extracurricular activities that match personal interests (clubs, volunteering, sports, cultural events).  
- Balance study schedules with activity participation.  
- Expand social networks and meet new people.  
- Gain skills and experiences that support personal growth and career opportunities.  

## Pains
- Scattered and inconsistent information across multiple channels (emails, social media, posters, word of mouth).  
- Vague activity descriptions that make it hard to judge relevance.  
- Time conflicts with classes and lack of advance planning.  
- Feelings of exclusion in established groups or high-level clubs.  
- Poorly organized events (e.g., long queues, unclear arrangements) reducing motivation to attend.  

## Gains
- Save time through a centralized activity platform.  
- Receive personalized recommendations that match interests or study areas.  
- Use reminders and bookmarking functions to avoid missing opportunities.  
- Build stronger social connections through activities.  
- Achieve meaningful outcomes such as skill development, cultural experience, and CV-building opportunities.  

## Products and Services
- Centralized and transparent platform for extracurricular activities.  
- Personalized recommendations based on interests, study area, and participation history.  
- Bookmarking, reminders, and an activity calendar.  
- Social interaction features (group chats, likes, activity check-ins).  
- Clear activity details: time, location, target audience, preparation, and cost.  

## Pain Relievers
- Consolidates scattered information into one platform.  
- Provides clear event descriptions to reduce uncertainty.  
- Sends reminders and offers a calendar to minimize scheduling conflicts.  
- Suggests beginner-friendly activities to lower entry barriers.  
- Includes a feedback system to improve activity quality.  

## Gain Creators
- Highlights relevant opportunities for each student.  
- Helps manage schedules more effectively with bookmarks and reminders.  
- Encourages participation by showing what friends or classmates are joining.  
- Promotes growth-oriented activities that enhance skills and employability.  
