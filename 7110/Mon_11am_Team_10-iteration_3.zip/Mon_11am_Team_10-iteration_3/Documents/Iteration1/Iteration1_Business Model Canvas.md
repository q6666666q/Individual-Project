## Business Model Canvas

**Customer Segments**
- First-year UQ students (UG/PG) — need to quickly discover suitable activities and make friends  
- International students — less familiar with UQ systems, need clearer guidance  
- Students aiming for personal/career development — want activities that provide skills and CV value  

**Value Propositions**
- [Click here read value propositions](<Value Proposition Canvas.md>)

**Channels**
- Web platform / Mobile app  
- Integration with UQ systems (SSO, event sign-up)  
- Campus promotion (student emails, newsletters, posters, social media)  
- Peer-to-peer sharing (QR codes, links, word of mouth)  

**Customer Relationships**
- Self-service browsing and booking  
- Guided onboarding for new/international students  
- Feedback loop: satisfaction surveys, ratings, and recommendations  
- Community-based interactions (sharing, popular events, light comments)

**Revenue Streams**
- University support (funding as part of improving student experience)
- Student Services and Amenities Fee (SSAF) allocation
- Potential sponsorships or advertisements from student clubs or external partners (must balance with user experience)

**Key Partners**
- UQ Student Services (Clubs & Societies, Student Life)
- UQ IT Department (system integration and technical support)
- Student clubs and societies (content providers)
- External partners (volunteer organizations, cultural event organizers)

**Key Activities**
- Platform development & maintenance (front-end, back-end, DB, UI/UX)  
- Data collection and verification of events (ensuring transparency)  
- Hypothesis testing & continuous user research (Awareness, Participation, Satisfaction metrics)  
- Promotion and onboarding of clubs/events  

**Key Rescources**
- Technical infrastructure (servers, databases, analytics)  
- Event/timetable data from UQ  
- Human resources (developers, designers, product managers, researchers)  
- Research assets (interviews, transcripts, test cards, learning cards) 

**Cost Structure**
- Development & operations (cloud, APIs, monitoring)  
- Personnel costs (developers, designers, testers)  
- Promotion/engagement campaigns (on-campus and online)  
- Long-term maintenance and content curation