# Test Cards

## Hypothesis 2: Participation

**HYPOTHESIS**
We believe that: 1. The current participation rate of students in extracurricular activities is low; 2. After using the platform for a period of time(For example, 1 month), at least 60% of active users will achieve three behaviors — visit more than 5 different activity pages, bookmark at least 2 activities, and click through to the official activity website at least once.

**TEST**
Select 20 UQ students who are using the platform for the first time, track their platform behavioral data for a period of time (for example, 30 days), and supplement the analysis of behavioral motivations with short interviews and questionnaires.

**METRIC**
Calculate the proportion of users who have achieved the three behaviors – "visiting more than 5 activity pages + bookmarking at least 2 activities + clicking through to the UQ system at least once" – by the end of the semester; meanwhile, record the missing behavioral data of users who fail to meet these requirements.

**CRITERIA**
If the proportion of users who have achieved the three behaviors is ≥ 60%, the hypothesis is valid; if the proportion is less than 60%, the hypothesis is invalid.

**INTERVIEW QUESTIONS**
1. In the past semesters, did you join any activities? If yes, could you tell me some details?
2. Could you tell me why you didn’t join any activities? 
3. When you search for activities to participate in, what information do you pay attention to?