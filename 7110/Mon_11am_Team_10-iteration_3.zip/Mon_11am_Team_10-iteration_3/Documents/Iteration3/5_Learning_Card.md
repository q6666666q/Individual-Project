## Learning Card - Hypothesis 1 (From Kiki)

We believed that ≥80% of participants could find an activity they were interested in within 1 minute, without guidance.

We observed that All 10 participants (100%) reported that it was easy to find an activity. Most used the search bar or filter blocks immediately after entering the home page, the avrage time is 55 seconds.

From this we learned that the current layout and navigation flow are largely intuitive and user-friendly. However, a few interface icons (e.g., favirote icons) could benefit from clearer visual cues or short tooltips to reduce initial hesitation.

Therefore, we accept this hypothesis. The overall usability meets the MVP goal.



## Learning Card - Hypothesis 2 (From Jeric)

We believed that ≥70% of participants (≥7/10) would give positive feedback on the product’s interface.

We observed that 10 out of 10 participants (100%) gave positive feedback on the interface. Most described the interface as clear, user-friendly, and appropriate. A few noted that the information density in some areas(for example, the mobile top bar) is slightly high.

From this we learned the interface meets visual expectations and surpasses the 70% positive feedback target, while the information density in some areas needs adjustments.

Therefore, we accept this hypothesis. The interface meets MVP goals and exceeds the positive feedback target. 



## Learning Card - Hypothesis 3 (From mingqi)

We believed that ≥70% of participants could use search or filter to find a specific activity within 2 minutes.

We observed that around 50% of participants mentioned using search and 40% used filters.
All participants said it was “easy to find activities,” but there was no exact timing recorded.
Several requested sorting by date or popularity and more flexible keyword matching.

From this we learned that the current search and filter design is intuitive and well-located, but lacks advanced support for real-world discovery (e.g., typo tolerance and sorting options).
Participants expect smarter results and clearer filter feedback.

Therefore, we will treat this hypothesis as partially validated.
Next, we plan to implement sorting and fuzzy matching improvements and run a timed ≤120s goal task to collect quantitative success data in the next iteration.


## Learning Card - Hypothesis 4 (From Mingqi)

We believed that ≥80% of participants could locate an event’s time, location, and registration button within 20 seconds.

We observed that all participants (100%) said that this information was easy to find, and the layout was clear and well-structured.

However, about 10% of participants mentioned that the “Register Now” button required extra scrolling on mobile devices.
Timing data was not yet collected.

From this we learned that the event detail layout meets expectations for clarity and readability on desktop, but the mobile layout can be improved for faster access to key buttons.

The placement of the Register button slightly reduces efficiency on smaller screens.

Therefore, we will treat this hypothesis as largely validated (qualitative).
Next, we will conduct a ≤20s timed test to gather quantitative evidence and A/B test a sticky bottom Register button for mobile improvement.


## Learning Card - Hypothesis 5 (From Zhaoguo)

We believed that at least 65% of participants would say they want to use the app again to find UQ activities.

We observed that
7 out of 10 participants (70%) said they would use the app again.

Most of them mentioned reasons such as clear information, easy search / filters, or convenient bookmarks. Those who said “No” or “Not sure” usually wanted more features, clearer design, or better performance.

From that we learned that the current MVP experience is generally positive and already creates reuse intention for many students, but a noticeable group still needs stronger reasons to come back (e.g., more personalized recommendations or tighter integration with their schedule).

Therefore, we will treat this hypothesis as mostly accepted.

In the next iteration, we will prioritise improvements that participants mentioned most often, and run a follow-up test to see if reuse intention increases after these refinements.



## Learning Card - Hypothesis 6 (From Zhaoguo)

We believed that
at least 60% of participants would be willing to use the “Add to Calendar” feature if it automatically created reminders for them.

We observed that more than 60% participants said they would use Add to Calendar.

Students who liked the feature said it helps them remember events and fits into their existing calendar habits. Those who were reluctant felt they already manage time in other ways (e.g., screenshots, personal to-do apps) or only attend a few events, so reminders felt unnecessary.

From that we learned that calendar sync is valuable mainly for students who actively plan their week or attend many activities. For casual users, the feature is optional rather than essential. Clearer wording and smoother integration with their default calendar could also increase adoption.

Therefore, we will treat this hypothesis as Partly accepted depending on the actual percentage.

Next, we plan to position Add to Calendar as an optional helper for committed attendees, improve the button label / feedback so users understand what will happen, and re-test whether adoption improves after these adjustments.



## Learning Card - Hypothesis 7 (From Junhao)

We believed that ≥80% of participants could save and unsave an event within 30 seconds each, and clearly identify the saved vs. unsaved state.

We observed that 8 out of 10 participants (80%) successfully completed the “save → unsave” tasks. Most participants could tell the state; a few asked for more obvious feedback or an easier entry to the Saved list.

From this we learned that bookmark interaction and state visibility are generally clear for common scenarios, with consistent understanding across pages.

Therefore, we accept this hypothesis. The bookmark feature meets the MVP goal.



## Learning Card - Hypothesis 8 (From Junhao)

We believed that ≥70% of participants could complete signup and login without assistance and understand the instructions and error messages.

We observed that 10 out of 10 participants (100%) completed signup and login. Copy and error messages were described as clear and standard; the overall flow was smooth.

From this we learned that the account flow is usable and understandable for first-time users and matches expectations.

Therefore, we accept this hypothesis. The account flow meets the MVP goal.
