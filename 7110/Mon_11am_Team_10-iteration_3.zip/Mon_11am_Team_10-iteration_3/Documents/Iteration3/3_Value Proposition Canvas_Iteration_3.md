# Value Proposition Canvas – Iteration 3  From Zhaoguo Huang
## Product: UQ Extracurricular Activity Platform (GatherU)

---

## 1. Customer Profile  
### Segment: UQ students who want to join extracurricular activities but struggle to find or commit to them

### Jobs  
- Find and join activities that match personal interests (social, career, life skills).  
- Quickly check whether an activity fits their **time** and **location** constraints.  
- Keep track of interesting events without having to remember all the details.  
- Join safe, trustworthy events where other students have had good experiences.  

### Pains  
- Information is scattered across emails, posters, websites and social media, so activities are easy to miss.  
  - *Supported by earlier hypotheses H1–H3 (Iteration 2: “too many sources”, confusion, missed opportunities).*  
- Activity details are sometimes unclear (time, location, cost, registration), which makes it hard to decide.  
  - *Iteration 2 H4/H7 showed unclear details stop students from joining; Iteration 3 usability tests again highlighted the importance of clear layout (H1, H3).*  
- Students worry about wasting time on low-quality or “empty” events.  
  - *Iteration 2 H8: most participants trusted peer feedback more than posters.*  
- It is easy to **forget** an event after seeing it once, especially during busy weeks.  
  - *Calendar / reminder interest explored in H6 (calendar feature refinement).*  

### Gains  
- A **single, trusted entry point** to see what is happening at UQ right now.  
- Being able to **find an interesting activity quickly** without reading lots of posts.  
  - *Iteration 3 H1: 8/10 participants (80%) found a relevant activity within ~55 seconds → fast discovery is achievable.*  
- Clean, structured activity pages where key details are obvious at a glance.  
  - *Iteration 3 H3/H4: most participants said time, location and registration were easy to find when laid out clearly.*  
- A way to **save** interesting events and come back later.  
- Optional **reminders / calendar sync** so they don’t forget events they have already decided to attend.  
- Confidence that events are worthwhile, based on **other students’ opinions** (reviews, popularity).  

---

## 2. Value Map  

### Products & Services (MVP scope – what we actually built & tested)  
- Home page with **central activity list** and keyword search.  
- **Filter tags** (e.g. Type / Paid or Free / Location).  
- **Activity detail page** with clear time, location, organiser, and registration button.  
- **Bookmark** button to save / unsave events.  
- **Add to Calendar** button with basic reminder behaviour (prototype).  
- Account system with **login / signup**.  
- Responsive interface and visual design optimised for quick scanning.  


### Pain Relievers  
- **Central list + search / filters**  
  - Reduces fragmented discovery by putting verified UQ activities in one place.  
  - *Aligned with Iteration 2 H1–H3; Iteration 3 H1 shows students can quickly find events using search / filters.*  

- **Clear activity detail layout**  
  - Time, location and registration are placed in predictable positions, reducing confusion.  
  - *Iteration 3 usability (H1 & related tests): 80% of participants found a suitable activity within 1 minute; only a few hesitated about icon meanings.*  

- **Bookmark feature**  
  - Lets students “park” interesting events instead of trying to remember them.  
  - *Iteration 2 H5: over half of participants said they would use bookmarking to follow up later.*  

- **Add to Calendar / reminders**  
  - Helps students who have already decided to attend avoid forgetting the event.  
  - *Iteration 2 H6 + Iteration 3 H6: interest is moderate (around half of participants); useful mainly for committed events → feature needs refinement rather than removal.*  

- **Clear buttons and flows (“Register”, “Add to Calendar”, etc.)**  
  - Lower cognitive load and reduce fear of “doing the wrong thing”.  
  - *Iteration 3 tests around interaction clarity (H4/H7) showed most participants understood the main buttons, with a few suggestions for icon labelling.*  

### Gain Creators  
- **Fast, self-explanatory navigation**  
  - Users can get from home page → relevant event in under a minute.  
  - *Iteration 3 H1 target (≥80% success within 1 minute) was met: 8/10 participants.*  

- **Positive visual design & overall experience**  
  - Modern, friendly look makes the platform feel approachable and “worth coming back to”.  
  - *Iteration 3 H2: 10/10 participants gave positive interface feedback; we exceeded the ≥70% target.*  

- **Support for repeat use**  
  - Bookmark list, stable layout, and clear flows make the app feel like a practical planner, not a one-off promo page.  
  - *Iteration 3 H5 (reuse intention): 7/10 students (70%) said they would use the app again to find UQ activities.*  

---

## 3. Hypotheses – Iteration 3 Validation Snapshot  

- **H1 – Quick Discovery**  
  - *Hypothesis*: ≥80% of participants can find an event they are interested in within 1 minute, without guidance.  
  - *Result*: 8/10 participants (80%) succeeded in ~55 seconds on average.  
  - *Decision*: **Accepted** – current navigation and filters support fast discovery, with minor icon tweaks recommended.  

- **H2 – Interface Appeal**  
  - *Hypothesis*: ≥70% of participants give positive feedback on the interface.  
  - *Result*: 10/10 (100%) described it as clear, user-friendly, and appropriate, with only minor comments about information density.  
  - *Decision*: **Accepted** – visual design meets and exceeds MVP expectations.  

- **H3/H4 – Detail & Button Clarity**  
  - *Hypothesis*: Most users can easily locate key details (time, location, registration) and understand primary action buttons.  
  - *Result*: Majority of participants reported it was easy to find these elements; only a small number hesitated on specific icons.  
  - *Decision*: **Accepted with minor UI refinements** – structure works, but labels / tooltips can further reduce hesitation.  

- **H5 – Reuse Intention**  
  - *Hypothesis*: ≥65% of users say they would use the app again to find UQ activities.  
  - *Result*: 7 out of 10 participants (**70%**) said they would use the app again to find UQ activities.  
  - *Decision*: **Supported** – MVP experience is strong enough to motivate repeat use, though long-term engagement still needs monitoring.

- **H6 – Calendar Feature Refinement**  
  - *Hypothesis*: ≥60% of participants say they would use “Add to Calendar” if it automatically synced reminders.  
  - *Result*: Interest was mixed (around half said they would use it, half felt they “wouldn’t really need it”).  
  - *Decision*: **Partially supported / refine** – feature is valuable for committed users but not a must-have for everyone; future design should make it optional and low-friction.  

- **H7 – Bookmark / Saved Events Clarity**  
  - *Hypothesis*: Most users can understand when an event is bookmarked or unbookmarked.  
  - *Result*: Participants generally understood the bookmark interaction, with a few asking for stronger visual feedback.  
  - *Decision*: **Supported with minor tuning** – current design works but can be made more obvious.  

- **H8 – Login / Signup Usability**  
  - *Hypothesis*: Most users can complete login/signup without confusion; error messages are clear.  
  - *Result*: Only minor issues were reported; most participants completed the flow smoothly.  
  - *Decision*: **Supported** – flows are usable; wording of some messages can still be polished.  

---

## Insights Summary  

- **The core value prop is now evidence-backed.**  
  - Iteration 3 usability tests show that students can quickly **discover** events and feel comfortable using the interface, confirming that a central, structured planner solves key awareness and clarity issues identified in Iteration 2.  

- **Convenience features matter, but not all equally.**  
  - Bookmarking and a clean list/detail flow clearly add value and support repeat use. Calendar sync, however, is mainly appreciated by students who already plan to attend, so it should stay as an optional enhancement rather than a core promise.  
