From Kiki & Junhao Liang
	1.	First Impression
When you first opened the app, what was your first impression?
What part caught your attention the most, or made you feel confused?
	2.	Finding Information
Was it easy for you to find an activity you were interested in?
Which feature helped you the most — the search bar, the filters, or the recommendations? Why?
	3.	Activity Details
When you opened an activity page, was it easy to find the time, location, and registration button?
Did you need to scroll a lot or look carefully to find them?
	4.	Interaction & Clarity
Were buttons like “Register Now” and “Add to Calendar” clear to you?
Did you understand what would happen when you clicked them?
	5.	Bookmark Feature
What do you think about the bookmark function?
Was it clear when you had saved or unsaved an event?
	6.	Login & Signup
How was your experience with the login or signup page?
Were the instructions and error messages clear and easy to understand?
	7.	Visual Design
What do you think about the color, layout, and overall design of the app?
How does the app make you feel — modern, friendly, serious, or something else?
	8.	Overall Feedback
Overall, would you use this app again to find UQ activities?
If you could improve one thing about it, what would that be and why?