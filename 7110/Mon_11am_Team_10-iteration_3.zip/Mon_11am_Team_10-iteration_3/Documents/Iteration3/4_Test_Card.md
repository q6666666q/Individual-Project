## Test Card - Hypothesis 1 (From Kiki)

We believe that ≥80% of participants can find an activity they are interested in within 1 minute, without any prior instruction.

To verify that, we will conduct short usability sessions with 10 UQ students using the MVP prototype (desktop or mobile).
Each participant will be asked to open the home page and find an event they would like to join.

And measure how long it takes for them to locate one relevant activity (in seconds), and whether they complete the task successfully within 60 seconds.

We are right if ≥80% of participants (at least 8 out of 10) successfully find an event they are interested in within 1 minute.

Therefore, we will ask:
- When you first opened the app, what was your first impression? (Q1)
- Was it easy for you to find an activity you were interested in? Which feature helped you the most? (Q2)

Evidence type: Observation (task completion rate + time) and short verbal feedback.



## Test Card - Hypothesis 2 (From Jeric)

We believe that ≥70% of participants give positive feedback about the interface.

To verify that, we will run usability sessions with 10 UQ students using the MVP prototype (desktop & mobile).
Each Participants will first browse all product functions, then provide interface feedback (focused on color scheme, layout and other visual elements)

And measure whether their feedback on the interface is positive or negative.

We are right if ≥70% (≥7/10) give positive interface feedback.

Therefore, we will ask:
- When you first opened the app, what was your first impression? What part caught your attention the most, or made you feel confused? (Q1)
- What do you think about the color, layout, and overall design of the app? How does the app make you feel? (Q7)

Evidence type: Observation and short verbal feedback.



## Test Card - Hypothesis 3 (From Mingqi)

We believe that ≥70% of participants can use the search or filter function to find a specific activity within 2 minutes, without any prior instruction.

To verify that, we will conduct short usability sessions with 10 UQ students using the MVP prototype (desktop or mobile).
Each participant will be asked to find an event they personally like using either the search bar or filter feature.

And measure whether they complete the task successfully within 120 seconds, which tool they use, and whether they experience any confusion or hesitation.

We are right if ≥70% of participants (at least 7 out of 10) successfully find an event they like using search or filter within 2 minutes.

Therefore, we will ask:

“Was it easy for you to find an activity you were interested in? Which feature helped you the most — search, filters, or recommendations?” (Q2)

Evidence type: Observation (task completion rate + time) and short verbal feedback.


## Test Card - Hypothesis 4 (From Mingqi)

We believe that ≥80% of participants can locate an event’s time, location, and registration button within 20 seconds, without any prior instruction.

To verify that, we will conduct short usability sessions with 10 UQ students using the MVP prototype (desktop or mobile).
Each participant will be asked to open one activity detail page and find these three key items.

And measure how long it takes for them to locate the information (in seconds), whether they scroll excessively or hesitate, and how they rate the clarity of the layout.

We are right if ≥80% of participants (at least 8 out of 10) successfully find all three items within 20 seconds and rate the information as “easy to find” (≥8/10).

Therefore, we will ask:

“Were details like event time, location, and the Register Now button easy to find?” (Q3)

“What do you think about how information is displayed on the activity page?”

Evidence type: Observation (task completion time + rating) and short verbal feedback.


## Test Card - Hypothesis 5 (From Zhaoguo)

We believe that ≥65% of participants will say they would use the app again to find UQ activities.

To verify that, we will run short usability sessions with UQ students using the MVP prototype. After they have finished basic tasks (browsing the home page, opening an activity, trying bookmark / calendar), we will ask about their intention to reuse the app.

And measure how many participants answer “Yes” when asked if they would use this app again to find UQ activities.

We are right if ≥65% of participants answer “Yes”.

Therefore, we will ask:
- “Overall, would you use this app again to find UQ activities? Why or why not?” (Q8)

Evidence type: Observation (Yes/No count) and short verbal feedback.



## Test Card - Hypothesis 6 (From Zhaoguo)

We believe that ≥60% of participants will say they would use the “Add to Calendar” feature if it automatically synced reminders.

To verify that, we will let participants open an activity detail page, tap the “Add to Calendar” button, and see what happens (e.g., calendar popup). After they experience the flow once, we will ask about their willingness to use this feature in their real life.

And measure how many participants say they would actually use Add to Calendar for activities they plan to attend.

We are right if ≥60% of participants say “Yes”.

Therefore, we will ask:
- “Were buttons like Register Now and Add to Calendar clear to you? Did you understand what would happen when you clicked them?” (Q4)

Evidence type: Observation (button usage + Yes/No count) and short verbal feedback.



## Test Card - Hypothesis 7 (From Junhao)

We believe that ≥80% of participants can save and unsave an activity within 30 seconds each, and clearly identify the saved vs. unsaved state, without any prior instruction.

To verify that, we will conduct short usability sessions with 10 UQ students using the MVP prototype (desktop or mobile).
Each participant will open an activity detail page, save the activity, then unsave it, and finally return to the list to check whether the bookmark state instantly syncs.

And measure task completion for save/unsave, time (seconds) for each task, sync accuracy between detail and list, and a 1–5 visibility rating.

We are right if ≥80% of participants (≥8/10) finish both save and unsave within 30 seconds, sync accuracy ≥90%, and mean visibility rating ≥4/5.

Therefore, we will ask:

- What do you think about the bookmark function? (Q5)
- Was it clear when you had saved or unsaved an event?   (Q5)

Evidence type: Observation (task completion rate + time + sync check) and short verbal feedback.



## Test Card - Hypothesis 8 (From Junhao)

We believe that ≥70% of participants can complete signup and login without assistance and understand all instructions and error messages.

To verify that, we will run usability sessions with 10 UQ students using the MVP prototype (desktop & mobile).
Each participant will first sign up, then log in with the new account, and restate the meaning of one error message in their own words.

And measure completion rates for signup/login, field-level error counts (empty/format/strength), whether assistance was needed (Y/N), and 1–5 ratings for clarity, understandability, and overall satisfaction.

We are right if ≥70% complete signup and login without assistance, ≥80% accurately restate an error message, and the mean rating ≥4/5.

Therefore, we will ask:

- How was your experience with the login or signup page? (Q6)
- Were the instructions and error messages clear and easy to understand?  (Q6)

Evidence type: Observation (completion + errors + need for help) and short verbal feedback.
