# Iteration 3 – Business Model Canvas From Junhao Liang & Mingqi Zhang

## Customer Segments

- UQ students (primary): Seek reliable, centralised, and structured information to efficiently discover extracurricular activities. Pains include fragmented sources, unclear details, missing out, and forgetting.
- Student clubs and event organisers (secondary): need a credible, high-reach, reusable single channel for their activities.

## Value Propositions

| Value Proposition                                            | Status                             | Data support (Iteration)                                     | VPC Source (Iteration) |
| ------------------------------------------------------------ | ---------------------------------- | ------------------------------------------------------------ | ---------------------- |
| **Centralised activity hub (single entry and search)**       | Accepted                           | Iter.2: H1=85.7% report discovery difficulty due to scattered sources; H2=88.5% say a centralised platform is more convenient; Iter.3: combines multiple Hypothesis, 100% said finding activities was easy | Iter.2, Iter.3         |
| **Structured event detail page (time, location, cost, registration, organiser, external link)** | Accepted                           | Iter.2: H4≈68% cite unclear/missing details as blockers; H7=81.5% stress key-info importance; Iter.3: 100% say key info is easy to find (~10% note extra scroll on small screens) | Iter.2, Iter.3         |
| **Bookmarks (My Saved) with cross-page state visibility**    | Accepted                           | Iter.2: H5=58% intend to use bookmarks; Iter.3: H7 task completion ~80% (8/10), 20% request clearer feedback or a more obvious Saved entry | Iter.2, Iter.3         |
| **Add-to-calendar with reminders (focus on confirmed events; app choice and clear feedback)** | Refine                             | Iter.2: H6=43.8% overall interest; more useful post-confirmation; Iter.3: ~40% request calendar-app choice/clearer feedback | Iter.2, Iter.3         |
| **Social and personal-growth framing (motivation-led recommendations and copy)** | Accepted                           | Iter.2: H9=70% cite social/personal growth as primary motivations, supporting motivation-led copy/filters | Iter.2                 |
| **Peer reviews / popularity signals (social proof)**         | Deferred (out of scope this phase) | Iter.2: H8=68% lean toward peer trust, but compliance/data-quality and implementation costs suggest deferring at this stage | Iter.2                 |

## Channels

- Web platform (primary): unified browse, search/filter/sort, bookmarks, and calendar write-in for confirmed events.
- On-campus touchpoints: O-Week, club days, booths—drive first-time trials and direct traffic to the platform.
- University comms and social amplification: newsletters, emails, QR codes, and group shares that point back to the platform to avoid re-fragmentation.

## Customer Relationships

- Self-service discovery with light personalisation cues: clear list/detail structure, tags (type/charge/campus), plus sorting and fuzzy search.
- Engagement loop: bookmarks drive revisit; signup/login was validated in Iteration 3 for cross-device continuity and retention; calendar use scoped to confirmed-attendance scenarios.
- Transparency and trust: provenance labels and official/club verification provide baseline credibility before introducing reviews/popularity.
- Lightweight support and feedback: clear microcopy and error messages; instant feedback (toast/state sync) for key actions to reduce hesitation and misclicks.

## Revenue Streams

**Phase 1 (MVP)** : Free platform; validate adoption and retention among students & organisers.

**Phase 2 (Post-Validation)** : Explore sponsorship from UQ divisions or student unions; potential analytics dashboard for organisers as premium add-on.

## Key Resources

- Web hosting (frontend: HTML/CSS/JS; backend placeholder for data expansion)

- Verified UQ / UQU event dataset

- Internal QA & usability feedback from Iteration 3 (H1–H8)
 

## Key Activities

- Continuous usability testing (H1–H8)

- Feature iteration (sorting, fuzzy search, calendar refinement)

- Verification pipeline maintenance for new activities

- Data-driven refinement of UX via analytics logs
  

## Summary

Iteration 3 confirms strong product–market alignment and MVP validation across **usability, clarity, and engagement.**
Most core hypotheses (H1, H2, H4, H5, H7, H8) are fully validated; H3 and H6 show measurable refinement paths.
Compared with Iteration 2, this version shifts from **problem confirmation → value proof → usability validation,** demonstrating clear evidence of improved **discoverability, clarity, and trust.**
Next iteration will focus on quantifying timing metrics, refining mobile UX, and strengthening calendar automation for higher engagement retention.
