[JUNHAO_11_September_1.mp3](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EWDVvo8olOVBtRofIHP_UKkBPmnKe-Zay7I3nSENTDvxMA?e=AJLLnt)



00:00:00 
 Hello, thank you for taking the time to talk with me today before we start.

00:00:09 
 I would like to let you know that I would like to record this interview so I can transcribe it later for my coursework.

00:00:18 
 The recording only be used for this crossover. You can free to refuse to stop answering at any time or ask me to delete

00:00:29 
 this recording. Do I have your concern to recording these interviews?

00:00:36 
 Yes. Okay. When you first opened the app, what's your first impression?

00:00:48 
 I think it's modern and tidy.

00:00:53 
 The next web and open search page labels let me feel a bit crafted.

00:01:02 
 So it looks tight.

00:01:12 
 Okay, what course you attend the most or made you feel confused?

00:01:21 
 I think the upcoming and past switch is clear, but I wasn't sure if past shows finish the events only or also those closing soon.

00:01:29 
 Okay. Was it easiest to find activities you were interested in?

00:01:36 
 Mostly via Flitters. I used campus first and type. Then narrowed things fast.

00:01:51 
 Okay, which feature helped you most? Why?

00:01:58 
 Later over search. Search looks for art and career, but

00:02:07 
 mindful didn't match mindfulness for me. It's a bit more fusing matching. It will help. On an activity page, what is easiest to find time locations and registration buttons? Okay, I think the time, location, or at the top are really good.

00:02:30 
 I scrolled it a bit to see organized information.

00:02:34 
 Did you need to scroll a lot?

00:02:40 
 Not too much, I think. I did wish to add and calendar update Google and Apple options because I was sure about time to handle it.

00:02:56 
 Was registered

00:03:00 
 registers now and add to calendar clearly?

00:03:05 
 Uh, label clear, add to calendar shows a post, but it disappears quickly.

00:03:15 
 Yeah, that's all.

00:03:18 
 Okay.

00:03:20 
 Did you understand what would happen when you click them?

00:03:27 
 Calendar, roughly yes. Register, certain about the final step.

00:03:35 
 Ok. And then, next one. What did you think about the bookmark function?

00:03:48 
 The star is visible, but I wasn't sure where to reveal all safety items.

00:03:55 
 Maybe my bookmarks page, I'd like the star state to sign it on this card immediately.

00:04:09 
 Was it clear when you have state or unsafe activity?

00:04:18 
 Icon change help, but short toes will remove doubt.

00:04:25 
 change help, but a short post will remove doubt.

00:04:35 
 How was your experience with login or lost our page?

00:04:48 
 Okay, simple. I will add a password, touch, and fix the test to forgot password. Submitting empty fields should show in line arrows.

00:04:53 
 Okay, okay. And the next part is the design.

00:04:58 
 What do you think about the color, and overall design? Friendly colors and readable text on small screens.

00:05:11 
 The header feels crowded.

00:05:13 
 A sticky filter search bar would be great when scrolling.

00:05:19 
 Hard shadows would be a touch lighter on mobile. How does the application make you feel? Particle and student-friendly.

00:05:33 
 I can narrow choice quickly. Would you use this application again to find the UQ activity?

00:05:44 
 by the UQ activity?

00:05:49 
 Yes, the campus or type data are useful.

00:06:00 
 Okay, and the last question is if you could improve one thing, what would that be and why?

00:06:00 
 Complete the in-app re-adjuster. Now followed. Can open external links or in-app confirm and add a result count.

00:06:15 
 Keywords highlighting on search. That will boost confidence and speed.

00:06:22 
 Okay, thank you for your answer.

00:06:25 
 Okay.