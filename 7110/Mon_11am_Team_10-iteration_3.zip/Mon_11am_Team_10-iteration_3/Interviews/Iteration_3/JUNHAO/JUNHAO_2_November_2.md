[JUNHAO_11_September_2.mp3](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EZrcl4IwvBFFsnI5p9cChW8BhfRGAo02qBLw3_LND_YcNg?e=ZDRFEu)



00:00:00 
 Hello, thank you for taking the time to talk with me today. Before we start, I would like to let you know that I would like to

00:00:07 
 recording this interview so that I can transcribe later for my coursework. The recording will only be useful for this coursework.

00:00:17 
 You can be free to refuse to stop answering at any time or ask me to delete this recording. Do I have your concern to record these interviews?

00:00:29 
 It's okay.

00:00:31 
 Okay.

00:00:32 
 When you first opened the application, what was your first impression?

00:00:47 
 Well, it is clean and friendly. This big call and the clear text made it easy to scan.

00:00:57 
 Nothing bad.

00:00:59 
 Okay. What course you attended the most or made you feel confused?

00:01:09 
 Well, the search entry at the top and the upcoming area caught my eye. I wasn't confused.

00:01:18 
 But I wondered what RegistrNow will do because there's no clear next page yet.

00:01:27 
 Okay, and the next box helps a lot.

00:01:50 
 Which features help you most? Why?

00:01:59 
 I think it's search and quick keywords. I could type part of the title and still get matches.

00:02:09 
 On an activity page, what's it? Is this to find time, location and registration buttons? Yes, time and locations are near the top and the

00:02:28 
 register now is obvious. Okay, did you need to scroll a lot?

00:02:38 
 Not really. Sections like description or organizer are clearly labeled.

00:02:46 
 Okay, let's go to the next part.

00:02:50 
 What is registered now and as to current care?

00:03:00 
 Add to calendar is clear and shows feedbacks.

00:03:06 
 Register now is clear in label, but I expected a confirmation or an external link.

00:03:14 
 Did you understand what would happen when you click then? Well, as for calendars, yes. And for register, I'm uncertain about the final step.

00:03:29 
 Okay. And what do you think about the bookmark function? Well, the star icon is easy to notice.

00:03:48 
 the star icon is easy to notice. The empty state makes sense. And was it clear when you have state or unstable activity?

00:03:57 
 Mostly yes. Though small toes will make it even clearer.

00:04:02 
 And since the states on the list will help.

00:04:07 
 And the next part is logging and the logout. How was your experience with the login or logout page? Well, it's simple and straightforward. Email and

00:04:28 
 password, we sign up and forget password.

00:04:35 
 What do you think about the colors, layout and the overall design in this application?

00:04:48 
 It's friendly and modern, good spacing, constant cards, easy to read.

00:04:54 
 On very small screens, some top bar text might wrap up overflow.

00:05:02 
 How does the application how does the other stuff the application made you

00:05:08 
 feel it's organized and approachable I feel I can't find things quickly

00:05:17 
 and would you would you use this application again to find UQ activities?

00:05:26 
 Yes, because it's fast, it grows, and the filters work well.

00:05:32 
 Okay, and last question.

00:05:35 
 If you could improve one thing, what would that be and why?

00:05:48 
 Make RegistrNow complete as follows.

00:05:51 
 Open a registration link or show confirmation.

00:05:56 
 And as a result counts and keyword hyphenol.

00:06:00 
 highlighting on the search page.

00:06:02 
 And okay, thank you for answer.

00:06:04 
 Thank you.