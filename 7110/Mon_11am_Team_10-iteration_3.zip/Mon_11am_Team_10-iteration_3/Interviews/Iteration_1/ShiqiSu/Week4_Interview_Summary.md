week4_Interview_Report
Description:
	People face some obstacles when searching for and joining activities.
Issues: 
	User report difficulties in finding activities information, as it is submited across multiple platforms such as Instagram, or event website. If they want to discover activities of interest, they need to spend significant effort or time searching.

How to increase participation?
	Aggregate useful information on a single page, making it easier for people to quickly find activities of interesting. 
	Key details to display could include:
		Location
		Activity date and time
		Content/description
		Whether it is free
		Whether free food or drinks are provided
		Benefits of participation
		Enrollment conditions (e.g., members only, staff, students, or open to public)

How to make users feel satisfied?
	Durning an activity, participants should have opportunities to:
		Make new friends
		Gain knowledge and skills
		Experience benefits that could support their future career