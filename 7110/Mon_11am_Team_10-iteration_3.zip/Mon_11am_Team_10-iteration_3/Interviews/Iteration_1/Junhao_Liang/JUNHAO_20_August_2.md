https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JUNHAO%20interview/JUNHAO_20_August_2.mp3?csf=1&web=1&e=tx7REf

00:00:00 
 Hi, I'm recording now. This is only for class purchase and you can refuse to answer any questions or stop at any time. Is that okay?

00:00:14 
 Yeah, that's fine.

00:00:17 
 Have you heard about any instructor's regular activities at UQ. Could you give some sample?

00:00:25 
 Yeah, I'm heard of quite a few things like the photography club, debate society, basketball

00:00:36 
 club and also the UQ volunteers group.

00:00:41 
 Where did you usually get information about this activity?

00:00:48 
 Mostly online, I often check UQU International's page because they post a lot about events and activities for students.

00:01:00 
 Sometimes I also hear from friends. Okay. In the past semester, did you try any activity? If yes, could you tell me some details?

00:01:19 
 Yeah, I joined the basketball club last semester.

00:01:25 
 I went to Chinese parties a week and sometimes we had friendly matches on weekends.

00:01:33 
 I found it during accreditation week when they had a store at the front court.

00:01:50 
 What kind of information was important to you when you decided to attend that activity? For me, the schedule was the most important because I didn't want to clash with my lectures. Also, the cost matters. I wanted to make sure the membership fee was affordable.

00:02:12 
 Audo, how satisfied are you with the activities you attended? Why?

00:02:22 
 Why? I'd say very satisfied. Maybe 8 out of 10. I meet new friends, got regular exercise and it helped me finance my studies.

00:02:35 
 The only reason is not attend. It's because sometimes the practice times were late at night, which was a bit tiring.

00:02:47 
 Okay, thank you for your answer.