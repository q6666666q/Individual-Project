https://uq.sharepoint.com/:u:/t/Section_7560_62502/ESKzFhgFdO9NjZhiEtb3LrsBL3C-jiaAAdxgNlq2Wzh0wA?e=86RzvE


00:00:00 
 Hi, I started recording now. This is for class coaches. You can refuse any question or stop at any time. Is that okay?

00:00:15 
 Oh, okay. yes or no.

00:00:33 
 Have you participated in any instructor VQRs activities at UQ in the past semester?

00:00:36 
 No.

00:00:39 
 Okay.

00:00:43 
 And the next question is open-end question.

00:00:45 
 Please answer freely.

00:00:56 
 Could you tell me why I didn't join in? Yeah.

00:00:57 
 I think because my schedule was super packed with classes

00:01:02 
 and some part-time job.

00:01:06 
 Plus, I didn't know much about the activities available,

00:01:10 
 like how to sign up or what they cost.

00:01:14 
 I felt a bit nervous about it.

00:01:20 
 - Okay, thank you for your answers.

00:01:23 
 - Thank you.