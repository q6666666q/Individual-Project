https://uq.sharepoint.com/:u:/t/Section_7560_62502/EebkaOZqxDBOhCwUXxUZbZABpwzDDXgSaTX6UJSvpeGfrQ?e=H7sp8d

00:00:00 
 Hi, I'm recording now. This is only for class projects and you can refuse to answer any questions or stop at any time. Is that okay?

00:00:13 
 Yeah, that's totally fine. Go ahead. is a regular activity at UQ.

00:00:27 
 Could you give some example?

00:00:30 
 Yeah, I have heard a lot.

00:00:34 
 There are the UQ Union clubs, sports teams like soccer or tennis,

00:00:40 
 and some volunteering staff.

00:00:43 
 Also some events like Market Day, I think.

00:00:48 
 And you joined the activity?

00:00:54 
 Yeah.

00:00:57 
 Sorry, I didn't join any activity.

00:01:01 
 Although I have a lot, not a lot,

00:01:09 
 but I was super busy with classes and assignments. And I'm a little nervous about my English.

00:01:15 
 Okay. If you want to join activity in the future, where would you like to get the information?

00:01:27 
 I think maybe some either way like social media, like Inns or other way, I can know directly and easily. And also I want to know if it's free or not, and if it's

00:01:51 
 too good for meeting new people.

00:01:54 
 Okay, could you tell me why I didn't… If you want to attend in the future, what kind of information would be important to you?

00:02:13 
 I like something fun and relaxed, maybe with friendly people and not too much commitment. Like a club where I can just show up and have

00:02:29 
 a good time.

00:02:32 
 And if you attend the activity in the future, what characteristics or features might satisfy you?

00:02:47 
 I think it must be some easy and relaxed time.

00:03:00 
 to have fun and do not need to say too much words, I think. And if there are free

00:03:11 
 food, it's much better.

00:03:16 
 Okay, thank you for your answer. No worries.