https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JUNHAO%20interview/JUNHAO_20_August_3.mp3?csf=1&web=1&e=BUN00E


00:00:00 
 Hi, I'm recording now. This is only for class purchase and you can refuse to answer any question or stop at any time. Is that okay?

00:00:14 
 Yes. Let's begin.

00:00:19 
 Okay. Have you heard about any structure or regular activities at UQ?

00:00:26 
 Could you give some example?

00:00:28 
 Yes, I have heard about several extracurricular activities at UQ.

00:00:36 
 For example, there are student clubs like chess clubs, that kind of thing.

00:00:41 
 Did you join any activity in past semester?

00:00:49 
 Actually I didn't join that kind of activity.

00:01:02 
 Okay, could you tell me why I didn't join any activity?

00:01:08 
 I didn't join because I was too busy with my coursework.

00:01:14 
 Okay, if you want to attend in the future, what kind of information would be important

00:01:24 
 to you?

00:01:25 
 Things like the schedule, location and whether beginners are welcome would be the most important information for me.

00:01:54 
 If you attend an activity in the future, what characteristics or features might satisfy you? I would be satisfied if the activity is affordable, easy to join, and provide opportunities to meet new friends.

00:02:07 
 Okay, thank you for your answer.

00:02:11 
 Yeah.