https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JUNHAO%20interview/JUNHAO_20_August_4.mp3?csf=1&web=1&e=hNxLmY


00:00:00 
 Hi, I'm recording now. It's only for class process and you can refuse to answer any questions or stop at any time. Is that okay?

00:00:13 
 Yes.

00:00:16 
 Okay. Have you heard about any structure and regular activity at UQ. Could you give me some samples?

00:00:26 
 No, I didn't hear about anything.

00:00:32 
 Okay.

00:00:35 
 So you didn't join any activity. Could you tell me why didn't join any activity?

00:00:46 
 tell me why I didn't join any activity? Yes, I didn't join because I was busy with my studies. Also, I wasn't sure what

00:00:55 
 activities were available, so I never try to join.

00:01:17 
 If you want to attend in the future, what kind of information would be important to you?

00:01:28 
 I think the time and place of the activity would be important. Also, I didn't like to know what the activity is about. Like, is it a game, a talk or something else? And maybe

00:01:39 
 how many people will be there. If you attended any activity, the features

00:01:48 
 was characteristic or features might satisfy you.

00:01:55 
 It would be good if the people there are friendly and if the activity is fun, not too boring.

00:02:06 
 Also, it shouldn't take too much time so I can still study.

00:02:13 
 Okay, thank you for your answer.