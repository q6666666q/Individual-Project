https://uq.sharepoint.com/:u:/t/Section_7560_62502/EaszjRkOi8dAi18RtOMCv0IB4E0pvcugOFC2acgxTGBLAw?e=UzpAOF

00:00:00 
 Hi, I will start recording now. This is the forecast project. You can fill any questions or stop at any time. Is that okay?

00:00:11 
 Okay.

00:00:12 
 This is a closed-end question. First answer yes or no. Have you participated in any instructor regular activities at UQ in the past semester?

00:00:27 
 No.

00:00:29 
 Could you tell me why I didn't join?

00:00:34 
 I didn't join mainly because of my study schedule.

00:00:39 
 This system was very busy with assignments and projects.

00:00:45 
 Okay. Thank you for your answer.