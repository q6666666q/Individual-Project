https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JUNHAO%20interview/JUNHAO_20_August_5.mp3?csf=1&web=1&e=FjQ32i


00:00:00 
 Hi, I'm recording now. This is only for class projects and you can refuse to answer any questions or stop at any time. Is that okay?

00:00:14 
 Okay.

00:00:16 
 Okay. Have you heard any about instructional activities at UQ, could you give some examples?

00:00:27 
 Yeah, for sure. I know about the international club,

00:00:31 
 the country with basketball, the debating society, and also volunteer programming.

00:00:42 
 Okay, where did you usually get the information about this activity?

00:00:49 
 Most of all, you could study photos and? If yes, could you tell me some details?

00:01:15 
 Yeah, I joined the photographic club that I met every Friday.

00:01:21 
 Do some photo walk and event event, small exhibition and camp.

00:01:30 
 When you decided to join that activity, what information was important to you?

00:01:46 
 Many of the time is needed to defeat my scope. Also, I was glad that let me be in tomorrow on my pro camera.

00:01:56 
 Okay. How satisfied were you with participating in that activity. Why?

00:02:07 
 Actually, I'm really satisfied. I learned a new skill, met many, many friends, and I gave me a break for the study.

00:02:20 
 Okay, thank you for your answer.

00:02:24 
 Yeah.