[https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FThur%5F21%5FAug%5F11%5F00am%2Emd%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E33ca3df3%2D1616%2D415d%2Db805%2D84c7bb8d3721](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FSun%5F12%5FOct%5F14%5F30am%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2Ea79c7ece%2Dec99%2D4885%2D83b7%2D64fa6775d600)

Interviewer: Okay, let’s start. Do you usually check out UQ activities?

Participant: Sorry, what was the question?

Interviewer: Do you usually check out UQ activities?

Participant: Oh, right. Sometimes — not often, but occasionally, yes.

Interviewer: That’s fine. Could you give me some examples? For instance, do you check them on the UQ website or just see posters?

Participant: Oh, how I find out about them? Yes — when I get off the bus, I often see posters about UQ Sport and other events. There are quite a few different flyers around. I also see updates on the UQ Union Instagram page.

Interviewer: Which activities have you tried before?

Participant: I’ve attended various sports activities at UQ — that’s what I usually join.

Interviewer: What made you decide to go? Was it because friends invited you, or just out of curiosity?

Participant: Mostly because of friends. Some people I knew were going, so I joined them.

Interviewer: I see. Do you think an app showing all activities would help you participate more?

Participant: Potentially, yes. It would show everything available — all the things happening — so yes, I think it would be helpful.

Interviewer: Great, thank you for sharing. I hope you’ll explore even more activities next semester!

Participant: Thanks!
