[https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FTue%5F19%5FAug%5F1%5F00pm%2Emd%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E00c092ca%2D0e66%2D4393%2D981f%2D9e4bb1bab93d](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FSun%5F12%5FOct%5F1%5F30am%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E7ac43415%2D359f%2D4a2e%2D8157%2Daf5d925ca197)

Interview 2:

Interviewer: Well, do you usually check out UQ activities?

Participant: Oh yeah, I do sometimes check them out, especially if something catches my interest. But I’m not always very consistent about it.

Interviewer: Which activities have you tried before?

Participant: I’ve tried the table tennis sessions, and I think I once joined a photography club myself. I also attended a couple of small workshops they organized, and I found them pretty fun, actually.

Interviewer: What made you decide to go — friends inviting you, or curiosity?

Participant: I guess it was a bit of both. I was curious about the photography activities, and I also thought it would be a good way to meet people and have some fun. So yes, a mix of both curiosity and social reasons.

Interviewer: Do you think an app showing all activities would help you join more?

Participant: Yeah, I think it could help. Having everything in one place would make it easier to see what’s available and might encourage me to try new things. So yes, I think it’s a good idea.

Interviewer: Great, thanks for sharing. Hope you explore more activities next semester.

Participant: Thank you!
