https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FTu%5F12%5FAug%5F11%5F00am%2Emd%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E19cc438c%2Daceb%2D477b%2Db594%2D15eff569c74f

EN:“Okay, to start with, have you come across or heard any student activities happening at UQ?”

ST:Oh, um, actually, I haven't really come across any student activities at UQ, uh, so, yeah, I don't really know much about them.

EN:“And what do you think are the main reasons you choose not to join those activities?”

ST:Uh, well, I think, um, one reason is maybe I am a bit busy with my studies, and also, uh, I'm not very familiar with the activities, so, yeah, that's why I haven't joined.

EN:“OK, what types of activities are you generally interested in?”

ST:Oh, um, I think I like activities that are more, uh, related to, like, culture, or maybe, um, sports, a little bit, and, uh, also things that help me meet new people, yeah.

EN:“OK, thank you very much.”
