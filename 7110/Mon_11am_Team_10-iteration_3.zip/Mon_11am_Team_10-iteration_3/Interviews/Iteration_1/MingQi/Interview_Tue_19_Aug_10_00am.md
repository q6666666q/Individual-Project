[https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FTue%5F19%5FAug%5F10%5F00am%2Emd%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E1b1c5203%2Dd34b%2D4711%2Dbb0e%2D3e2d33048672
](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FSun%5F12%5FOct%5F13%5F15am%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2Ed6bb57bc%2Dfc7a%2D4b00%2D9733%2D0e03bc00f206)

Interview 1:

Interviewer: Do you usually check out UQ activities?

Participant: Well, actually I’m not very familiar with them, so I don’t usually check them out.

Interviewer: If you had the chance, which kind of activity would you like to try?

Participant: If I had the chance, I’d probably choose one that provides free food or drinks. I’d be more likely to try something like that.

Interviewer: What usually makes you decide to go — friends inviting you, or curiosity?

Participant: I’m more likely to go out of curiosity. If my friends invited me, I might join, but often I’m not very interested in the activities themselves, and sometimes I haven’t had great experiences in the past.

Interviewer: Do you think an app that shows all activities would help you join more?

Participant: Yes, I think it could help. Having everything in one place would make it easier to see what’s available and might encourage me to try new things. So yes, I think it’s a good idea.

Interviewer: Great, thanks for sharing. Hope you’ll explore more next semester.

Participant: Thank you.
