[https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FThur%5F21%5FAug%5F3%5F00pm%2Emd%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E4868c650%2Df020%2D48d2%2D94dd%2Df01b3113fc6c](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FSun%5F12%5FOct%5F13%5F30am%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E04dfd955%2D290c%2D45dc%2D9638%2D7d07e296adf6)

Interview 5:
Interviewer: Well, do you usually check out UQ activities?

Participant: Actually, I don’t really pay much attention to UQ activities, so I don’t know much about them. Of course, I don’t usually check them out.

Interviewer: I see. If you had the chance, which kind of activity would you prefer to join?

Participant: Personally, I would prefer activities that provide free food or drinks. If I had the chance, I’d like to give those a try.

Interviewer: What usually makes you decide to go — friends inviting you, or just curiosity?

Participant: For me, it’s mostly curiosity. If my friends invite me, that could be a reason too, but I’m not particularly interested in most of the activities. I also haven’t had many good experiences before.

Interviewer: Do you think an app that shows all activities would help you join more events?

Participant: Maybe. If there were an app that shows all kinds of activities clearly, I might be more likely to try some of them.

Interviewer: Great, thanks for sharing. Hope you’ll explore more interesting experiences next time.

Participant: Thank you.
