[https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FThur%5F21%5FAug%5F10%5F00am%2Emd%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2Ea6ad322c%2Def26%2D4bd2%2Da1b1%2De3a31628cd73](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FSun%5F12%5FOct%5F14%5F00am%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E123dfcbe%2D6b57%2D455e%2Dae50%2De17b3746d7a1)

Interview 3:
EN: Do you usually check out UQ activities?

Student: Um, yeah, I mean, I do sometimes check them out, uh, especially if there's something that catches my interest, but, um, I’m not always, like, super consistent with it.

EN: Which ones did you try?

Student: Uh, well, I think I tried, um, the photography club once, and, um, I also went to a couple of, like, small, uh, workshops they had. It was pretty fun, actually.

EN: What made you decide to go? Friend dragged you or curiosity?

Student: Um, I guess it was a bit of both, you know? I was curious about, uh, what they offered and, um, yeah, I thought it would be a good way to meet people and, uh, have some fun. So, a mix of both, I suppose.

EN: Think an app showing all activities would help you join more?

Student: Um, yeah, I think it could help, actually, because, um, having everything in one place would make it easier to see what's available and, um, maybe encourage me to try new things. So, yeah, I think it could be a good idea.

EN: Great, thanks for sharing. Hope you explore more next semester!

Student:Thanks! I appreciate that. I'll definitely keep an eye out for more stuff. Thanks for the encouragement!
