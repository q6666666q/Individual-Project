https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FTu%5F12%5FAug%5F13%5F00am%2Emd%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2E8e58e386%2D473f%2D4f88%2Db634%2Dc15397428f13
EN: Okay, to start with, have you come across or heard any student activities happening at UQ?
St: Um, yes, I have heard a little bit about some activities, but I haven't really joined any. I just heard some information from, uh, friends and, um, online, I guess.

EN: And what do you think are the main reasons you choose not to join those activities?
St: Uh, I think the main reasons are maybe, uh, time constraints and also, I am not very sure about the activities. I feel a bit hesitant to join them. So, yeah, that's probably the main reasons.

EN: Okay, what types of activities are you generally interested in?
St: Um, I think I am more interested in activities that are related to, uh, culture or, um, maybe some hobbies like painting or, uh, reading or things like that. So, yeah, that's the kind of stuff I like.

EN: Okay, thank you very much.
St: Thank you.
