Interviewee7
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/Interview_Tue_26_August_21.56pm.m4a?csf=1&web=1&e=I9JzPY

Jeric: Hi, I'm Jeric. We are currently conducting a small survey on UQ extracurricular activities. Could we take a few minutes of your time?
Interviewee: Sure
Jeric: Okay. Our conversation may need to be recorded, but you can interrupt at any time. Uh, would that be convenient for you?
Interviewee: Okay.
Jeric: Let's start. The first question: Uh, have you ever heard about any extracurricular activities at UQ?
Interviewee: Well, yes. I did hear lots of um, activities at UQ, such as the um, student societies, sports, and cultural groups. And I first heard about them during Orientation Week when they had stores set up, and later through friends and social media posts. Oh.
Jeric: So, uh, where do you usually get information about these activities?
Interviewee: Mostly from YouTube, websites, and social medias like Instagram and Facebook. Sometimes from friends too.
Jeric: Okay. Uh, in the past semesters, uh, did you actually join any activities? If yes, could you tell me some details?
Interviewee: Yes, I joined some orientation activities like welcome events and student society stores. They helped me meet new people and get familiar with the campus.
Jeric: OK. Uh, what kind of information is important to you when you attend these activities?
Interviewee: Well, for me, the main things are the location and time—definitely. And maybe the activity contents, and whether it’s open to beginners or new members.
Jeric: Okay. Also, overall, uh, how satisfied are you with the activities you attended?
Interviewee: I've been pretty satisfied overall. The orientation events and student socials were fun, and I liked that they were welcoming and easy to join.
Jeric: Okay, thank you!