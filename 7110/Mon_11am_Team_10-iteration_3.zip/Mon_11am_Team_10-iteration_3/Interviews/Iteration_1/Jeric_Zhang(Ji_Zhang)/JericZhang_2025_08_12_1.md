Interviewee1
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/Interview_Tue_12_August_12.35pm.m4a?csf=1&web=1&e=KbOyFI

Jeric: Hey, hello I’m Jeric. At the moment we’re doing a small survey about extracurricular activities at UQ, and I’d like to ask you a few questions, is that okay?
Interviewee: Ah, sure.
Jeric: Okay, uh, our survey will be recorded, but you can stop at any time, ah. Is that alright?
Interviewee: Yeah, that’s fine.
Jeric: Ah, okay, then let’s officially begin. First of all, have you heard about any extracurricular activities at UQ?
Interviewee: Oh, yes.
Interviewee: Uh, through the website or, like, classmates might introduce some. And some organizations also, uh, host extracurricular activities.
Jeric: Uh, uh, where do you usually get this kind of information? Could you be a bit more specific?
Interviewee: Mm, for example, the teaching buildings might have some posters of the monthly events. And oh, also some student groups, like APS, they post their activities on Instagram. So I usually get information from these channels. And also through classmates.
Jeric: Mm, you go to some extracurricular activities, ah. Okay, okay. Uh, in your previous semesters, which activities did you join? Could you tell us some details?
Interviewee: Oh, I joined some activities organized by APS. For example, they had some tea parties for master’s students, uh, mainly for science students. And then they also had, like, oh, touching koalas and taking photos with koalas, and also, uh, with other animals.
Jeric: Mm, have you joined activities like Market Day, ah, or some other types?
Interviewee: Oh, yes, I joined a Market Day—it was during Orientation Week, ah, Market Day.
Jeric: Okay. Mm, when you usually decide to join these activities, is it that you, uh, mainly care about some particular information?
Interviewee: Ah, oh, I mainly care about, uh, the timing. Because my schedule is quite tight, I need to see if I have the right time to participate. And I also look at, uh, which organization is hosting, their promotion, ah, and also what I can learn from the activity.
Jeric: Oh, okay, okay. Thanks for your answer. And then one last question, uh, overall, how satisfied are you with these activities?
Interviewee: Oh, I think the extracurricular activities here are very diverse. You can find almost any type you like. I feel they’re, ah, really student-friendly and can greatly help students’ physical and mental development. Mm.
Jeric: Do you feel there are any dissatisfying points, ah?
Interviewee: Mm, dissatisfying… I think maybe they could make one website to gather all the different types of activities, so students can, ah, more easily check what kind of activities are happening on which day.
Jeric: Mm, okay, okay. Thanks a lot for your answers.
