Interviewee4
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/Interview_Wed_20_August_17.22pm.m4a?csf=1&web=1&e=nihoT3

Jeric: Hi there, I’m Jeric. We are currently doing a small survey about UQ extracurricular activities. Can I ask you a few questions? Is now a good time?
Interviewee: Hmm, no problem.
Jeric: Okay, the survey will be recorded, but you can stop at any time. Is that alright?
Interviewee: Yep, that’s fine.
Jeric: Great! Let’s get started. First question: Have you heard about any UQ extracurricular activities?
Interviewee: Um… sometimes I see them on WeChat public accounts, Instagram, and RedNote, but not too many.
Jeric: Oh, okay. Which activities do you remember hearing about? For example…
Interviewee: Well, I’ve heard of Ginkgo Porridge, and also some winter festivals, amusement activities, and celebrations of festivals from different countries. I’ve seen them on the lawn sometimes.
Jeric: I see. Have you actually participated in any of these activities before?
Interviewee: Hmm, besides Orientation Week, I haven’t really participated in much. One reason is that I didn’t have time, and another is sometimes I found out about events too late, so I couldn’t register anymore.
Jeric: So you mean if you happened to walk by, you might check it out but haven’t specifically plan to attend one, right?
Interviewee: Oh, yeah. Usually when I see it, the activity has already started, so I can only be an observer.
Jeric: Got it. I understand. If you were to attend these activities, what kind of information would you pay attention to?
Interviewee: What kind of information do you mean exactly?
Jeric: I mean, what features of an activity would attract you to participate? Or what details do you particularly care about, like time, location, and other aspects?
Interviewee: Hmm, it’s best if it’s on campus because it’s convenient. As for time, any time works as long as I don’t have classes. And regarding content, as long as it’s something that can broaden my horizons, that’s good.
Jeric: Okay, understood. Last question: Based on the activities you have attended, how satisfied are you overall? If you were to give a score?
Interviewee: Hmm… let me think. Out of ten?
Jeric: Yes, anything is fine. Just give your opinion.
Interviewee: Alright, out of ten… maybe 6 or 7. I haven’t participated in many activities; the biggest ones are Orientation Week and the Food Festival. The experience is nice, but the timing of the information affects me. I usually only find out when I happen to walk by, so I feel like I just stumbled upon it rather than it being officially offered to us. That kind of lowers the score a bit.
Jeric: Okay, got it. That’s all for our survey. Thank you for your participation.
Interviewee: Okay, thanks, goodbye.
