Interviewee3
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/Interview_Wed_20_August_17.17pm.m4a?csf=1&web=1&e=Z2eP1J

Jeric: Hello, I’m Jeric. At the moment we’re doing a small survey about extracurricular activities at UQ, and I’d like to ask you a few questions. Is this okay with you?
Interviewee: Okay, okay, ah.
Jeric: Okay, our survey will be recorded, but you can stop at any time during the process. Is that okay?
Interviewee: Mm, that’s fine, ah.
Jeric: Ah, okay, then let’s officially begin.
Interviewee: Okay.
Jeric: You… uh, have you learned about some extracurricular activities at UQ? Just hearing about them also counts.
Interviewee: Where?
Jeric: Hello? It seems the call just dropped. Now it’s fine, right?
Interviewee: The internet cut off. From the very beginning, the first question.
Jeric: It cut off, ah. The first question was: have you heard of any extracurricular activities at UQ?
Interviewee: Uh, I’ve heard of some, for example Orientation Week, and also some food festivals. Yeah, those kinds.
Jeric: Yeah, ah, that counts. Uh, from what sources, ah, did you hear about these activities?
Interviewee: Uh, mostly from friends. And sometimes also from, like, this this this… yeah, some offline promotions too. But mainly from friends, right, and also from some social media platforms.
Jeric: Oh, okay. Eh, in your previous semesters, did you actually join any?
Interviewee: Mm, not really, I only joined Orientation Week. Oh, right, just Orientation Week, because at that time my schedule was relatively free.
Jeric: Right, oh. Eh, then why didn’t you join the other ones you heard of? Was it because you weren’t interested, or some other reason, ah?
Interviewee: Uh, not exactly. Mainly because sometimes assignments were, like, overwhelming, giving me a headache. And then, sometimes I had other plans, like going out to play, so I didn’t have time to, to, to, to join these activities, or there were time conflicts.
Jeric: Right, so you didn’t go much. Oh, okay. Eh, so if in the future you were to join activities like these, what kind of information would you care about, ah—what would make you want to participate?
Interviewee: Uh, first, I think the most important thing is the type of activity—whether it’s something I’m interested in. If I’m not interested in the type, I probably won’t even consider it. That’s the first point, ah. Then besides that, mm, the time. If the activity lasts longer, then I have more flexibility to arrange my schedule, so there won’t be too many conflicts, and it’ll be easier to fit in. Yeah, mainly these two points. The rest depends—if I’m interested and have time, then I’d probably give it a try.
Jeric: Oh, okay, okay. Then the last question. Uh, uh, you said you joined Orientation Week, right? How satisfied were you with that activity?
Interviewee: Uh, I felt it was pretty good, ah. If out of five points, uh, I’d say… Well, it was right when I just arrived, so it felt very fresh, very new. And Orientation Week also lasted quite a while, with lots of activities, so overall it felt quite nice.
Jeric: Oh, alright. Eh, just now it cut off for a bit—out of five, how many points did you give?
Interviewee: Uh, four to five points.
Jeric: Oh, that’s good, ah. That’s quite a high score.
Interviewee: Yeah, yeah, I was quite interested at the time.
Jeric: Right. Oh, okay. Then that’s all for our survey, thank you for your participation.
Interviewee: Mm, okay, ah.
