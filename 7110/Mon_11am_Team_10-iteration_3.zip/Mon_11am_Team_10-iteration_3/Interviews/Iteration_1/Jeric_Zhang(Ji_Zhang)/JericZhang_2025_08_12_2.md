Interviewee2
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/Interview_Tue_12_August_13.39pm.m4a?csf=1&web=1&e=TZ4WiI

Jeric: Hey, hello. I’m Zhang Ji. At the moment we’re doing a small survey about extracurricular activities, and I’d like to ask you a few questions. Is this okay with you?
Interviewee: Mm, sure.
Jeric: Ah, okay. Our survey will be recorded, but if you want to stop at any time during the process, you can just let me know, is that okay?
Interviewee: Mm, okay. Alright, then let’s officially begin. Uh, first I’d like to ask if you’ve heard about any, uh, extracurricular activities at UQ?
Interviewee: Oh, yes, I’ve heard of some. For example, koala activities at the beginning, and also some food festivals. And also, some activities like dancing.
Jeric: Ah, okay. Normally, through what, uh, channels or ways do you learn about these activities?
Interviewee: Oh, in most cases it’s through friends. And sometimes, I also receive emails telling me what activities there are.
Jeric: Okay, so usually your information channels are, uh, notifications, right? Have you ever actively looked for activities yourself?
Interviewee: Uh, not much. Mostly I hear from others, and if I’m interested, I might join. But I don’t really search for them on my own.
Jeric: What kind of activities? Okay, okay, thanks. And in the past, have you specifically joined any activities? If yes, could you tell me some details?
Interviewee: Mm.
Interviewee: One specific one was the Winter Carnival, I guess. But I didn’t really try the activities. I just went with a friend, we walked around, and bought some food. Then experienced the atmosphere. Took a few photos together.
Jeric: OK.
Jeric: Ah, so those ones you mentioned before, like the food festival and the koala event, did you actually attend them, or just hear about them?
Interviewee: Mm, I did actually attend the koala event. I lined up and touched it. But the food festival, I only heard about it.
Jeric: Oh, okay, okay. Eh, so in general, when you decide to join an activity, what kind of information do you look at, ah, what makes you want to go?
Interviewee: Uh, first is the time—whether it conflicts with my classes. And then, also the location. Sometimes if it’s right after a class and nearby, I might go take a look. Because sometimes, even if it’s not very interesting, if it’s close, I might go. But if it’s far, I won’t spend extra time to go.
Jeric: Oh, okay. Okay, got it, ah. Then the last question—overall, how satisfied are you with the activities you’ve attended?
Interviewee: Uh, if out of ten, I’d say six or seven. Because I think the activities match their descriptions, but sometimes the waiting time is long. For example, with the koala, I had to queue for a long time. And for the Winter Carnival, even though I didn’t try the rides, I saw that every activity had a very long line—maybe twenty or thirty minutes for one.
Jeric: Oh, okay, okay. Got it, ah. That’s all for this interview, thank you for participating.
Interviewee: Okay.
