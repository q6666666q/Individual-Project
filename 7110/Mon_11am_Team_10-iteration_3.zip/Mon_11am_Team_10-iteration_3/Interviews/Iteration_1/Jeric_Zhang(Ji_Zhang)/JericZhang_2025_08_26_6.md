Interviewee6
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/Interview_Tue_26_August_21.30pm.m4a?csf=1&web=1&e=pOsyxp

Jeric: Hi, I'm Jeric. We are currently conducting a small survey on UQ extracurricular assignments. Uh, could we take a few minutes of your time?
Interviewee: That's okay.
Jeric: Our conversation may need to be recorded, but you can interrupt at any time. Would that be convenient for you?
Interviewee: Okay.
Jeric: okay, let's start. The first question is, have you ever heard about any extracurricular activities at UQ?
Interviewee: Uh, yes, I had heard some of them from my friends. Ah, I seldom attended, so this questionnaire is about activities, right? Yes.
Jeric: Okay, okay. And where do you usually get information about these activities? Maybe just from your friends?
Interviewee: I usually get this activities information from my friends, and usually from some social media such as Red Notes. And like, some maybe some from email. Uh, since I'm taking a research program this semester, I just... I rarely attend them, oh.
Jeric: Okay, and uh, so you rarely attended, but you maybe joined some of them? Yeah, could you tell me some details?
Interviewee: Um, for after-class activities, I joined the food market. And one of the associations—I think it's from our major. I'm sorry, it's related to environmental science, and the association's name is shorter, name is GEM. But it's a... uh, for Geography of Environmental Management, and the food activities. Yeah, I think that should be an activity, right. Mm. So that's good, and I just attended and enjoyed the food there. Yeah, I think that's enough for the details?
Jeric: Yeah, yeah, yeah, of course. And uh, when you attend these activities, what kind of information is important to you?
Interviewee: Yeah, okay. So I think the most important information is the time and the location. I only know whether to attend the activity based on that. But I think some content like an explanation of the activities—like what is this activity for, and ah, what is it like. For example, my GEM association, they will have... uh, not formal lectures, it's like just a discussion. And they will just inform us about the lecture—yeah, the discussion. And yeah, we will know where to attend and what it's about. So I think that's important for me because you can decide whether I should go or not.
Jeric: Okay. So overall, how satisfied are you with these activities?
Interviewee: I think it's probably satisfying. Because, um, um, the activities I attended are mostly related to entertainment. And for my personal opinion, I don't have a high evaluation standard—like I'm not strict about it, because I think having fun is okay. And for my GEM activities, they just provide the information I need. Like, ah, they provide some people contacts related to my work and my study—it's good for my career. So I think if the satisfaction scale is from one to five, I wish to grade it like 4.5 or four. Yeah. Is that okay?
Jeric: Okay. Thank you.