Interviewee5
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/Interview_Wed_20_August_18.04pm.m4a?csf=1&web=1&e=surBMr

Jeric: Hi, I’m Jeric. I’m doing an interview about extracurricular activities at UQ. Can I ask you a few questions?
Interviewee: Yeah, go ahead.
Jeric: Okay, our conversation will be recorded, but you can ask me to stop at any time. Is that okay?
Interviewee: Yeah, sure.
Jeric: Okay, let’s start. First question: Have you ever heard about any extracurricular activities at UQ?
Interviewee: Yeah, but I forgot the exact names. For example, the Food Festival that happened at Greek Court, or the temporary amusement park outside the Frost Building… I’m not really sure.
Jeric: Okay, thank you. Could you tell me where you usually get information about these activities?
Interviewee: Um, I usually find posters around campus and also hear about them from my friends.
Jeric: So usually offline. How about online? Have you ever heard about activities online?
Interviewee: No, I don’t use social media much, so I really haven’t seen information online.
Jeric: Okay, got it. In past semesters, have you actually joined any activities?
Interviewee: Uh, no, I’ve never really participated in any activities.
Jeric: Could you tell me why you haven’t joined any?
Interviewee: Well, it’s just my preference. I don’t like noisy or crowded environments, so I usually avoid them.
Jeric: Okay, so you never really participated. Do you mean you partially participated or fully never participated?
Interviewee: Yeah, it’s like I partially participated. I didn’t really know about the activity; I just happened to come across it and joined.
Jeric: Oh, I see. And if you wanted to join an activity in the future, what kind of information would be important to you?
Interviewee: Well, first of all, it’s important to know the location and time so I won’t miss it. Then the main content is important too. Since I’m not very social, I pay more attention to the activity itself rather than the other participants.
Jeric: Okay, got it. Last question: If you attend an activity, what kind of characteristics would make you satisfied?
Interviewee: Well, as I mentioned, I hope the environment won’t be too loud or crowded. Also, I hope the content isn’t boring.
Jeric: Okay, thank you. That’s all for our conversation.
Interviewee: Yeah, sure.
Jeric: Okay, have a good day. Thanks.
Interviewee: Okay.
