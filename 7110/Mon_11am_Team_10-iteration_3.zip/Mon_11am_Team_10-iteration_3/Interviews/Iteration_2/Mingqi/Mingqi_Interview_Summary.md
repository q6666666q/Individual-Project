## Activity Information Access & Lack of Awareness

Main sources: friends, on-campus posters, social media; occasionally university emails.

Pain point: information is scattered and easy to miss (emails get overlooked; social feeds are noisy).

Strong preference for a centralized platform to browse all activities in one place.

## Reasons for Low Participation

Time conflicts with courses, assignments, and exams.

Last-minute discovery: students often see events too late to plan.

Social barriers: worry about awkwardness, going alone, or not being the “right fit.”

Unclear expectations: sparse details make it hard to judge suitability.

Forgetting: interest fades without a nudge.

Current level: about 2–3 activities per semester on average.

## Key Information Students Want (Decision-Critical)

Basics: date/time, location (on/off campus), cost.

Fit & expectations: short description, “beginner-friendly” or audience level, any requirements.

Social proof & context: photos and typical attendance/scale to set expectations.

## Desired Platform Features

Bookmark/Favorites to save interesting activities and revisit later.

Reminders via phone notification or calendar sync (email alone is often missed).

Student reviews/ratings (short comments or a score) to build confidence and reduce anxiety.

Unified listings & rich detail pages so decisions can be made quickly without app-hopping.

## Overall Attitude Toward a Unified Platform

Broad agreement that a platform with activity list + detail pages + favorites + reminders + peer reviews would markedly improve:

Awareness (higher visibility, fewer missed posts),

Decision-making (clear info plus peer signals), and

Participation (saved items and timely nudges reduce drop-off).

Expected outcome: fewer missed opportunities and greater, more confident engagement.

## Supplementary Insights

Push or calendar notifications are the “last-mile” to attendance; emails are a secondary channel.

Explicit tags like “newcomer-friendly” or “okay to come alone” lower social friction.

Showing typical attendance and a few photos helps students anticipate the vibe and commit.

## Design Implications (Priorities)

Must-have: centralized catalog, rock-solid core fields (time/place/cost), bookmarks, phone/calendar reminders, simple ratings/reviews.

Should-have: labels for audience level/newcomers, attendance range, lightweight media (photos).

Nice-to-have: quick actions (add to calendar, register, share), gentle pre-event reminder timing.

Bottom Line
Consolidate scattered info into a one-stop activity hub, pair clear details with peer cues, and use light-touch reminders to carry students from interest to attendance.
