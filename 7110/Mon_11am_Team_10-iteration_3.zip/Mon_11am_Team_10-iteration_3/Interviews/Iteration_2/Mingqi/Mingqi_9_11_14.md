[https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/Mingqi%20Zhang%20Interview/Interview_Thur_11_Sep_11_1am.md.m4a?csf=1&web=1&e=NDatGb&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D](https://uq.sharepoint.com/teams/Section_7560_62502/_layouts/15/stream.aspx?id=%2Fteams%2FSection%5F7560%5F62502%2FShared%20Documents%2FMon%5F11am%5FTeam%5F10%2FInterview%20Audio%2FMingqi%20Zhang%20Interview%2FInterview%5FSun%5F12%5FOct%5F1%5F30am%2Emp3&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview%2Ed31e6ba6%2Dcc32%2D48a1%2Dbe15%2D989435425add)

Interviewer: Now let’s begin our first question. How do you usually engage with student activities at UQ?

Participant: I usually play table tennis at UQ on Wednesdays and weekends. I think it’s a good way to relax.

Interviewer: Why do you think students sometimes miss activities?

Participant: Maybe there are too many options for them to choose from, and they don’t always know which one is the most suitable.

Interviewer: Would you prefer one platform with a clear list of activities instead of scattered social media posts or flyers? Why?

Participant: A clear list of activities is more suitable, I think. It makes it easier for students to choose and keeps things more interesting.

Interviewer: What information would you like to see on the activity detail page before deciding to join or decline?

Participant: I would pay more attention to the time and location of the event, as well as what to expect and what to bring. Those details are important when deciding whether to participate.

Interviewer: If there were a “Favorite” feature to bookmark activities for later, would you use it? Why or why not?

Participant: Yes, I might use this function. Sometimes I’m interested in an activity but not ready to commit immediately. Bookmarking would let me come back and check again later. It’s a very convenient way to keep track of options.

Interviewer: What kind of reminder would be most helpful for you?

Participant: Maybe a general notification the day before the event, and another reminder one or two hours before it starts. Or perhaps an email confirmation — something that reminds me to attend without being intrusive.

Interviewer: Would you trust short reviews or ratings from other students when deciding whether to join?

Participant: Yes, definitely. Quick comments of just a few sentences from other students set clear expectations and reduce uncertainty — especially for first-timers.

Interviewer: That’s all for our survey—thank you for participating.
Participant: You’re welcome!
