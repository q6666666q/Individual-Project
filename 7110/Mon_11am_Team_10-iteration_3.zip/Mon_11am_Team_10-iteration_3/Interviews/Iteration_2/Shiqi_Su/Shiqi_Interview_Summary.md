1. Activity Information Access and Lack of Awareness
	•	Most students learn about activities through emails, friends, social media, or posters.
	•	Information sources are too scattered, often buried in emails or mistaken for ads, causing activities to be missed.
	•	Students strongly prefer a centralized platform to see all activities in one place.

2. Reasons for Low Participation
	•	Time conflicts: Course schedules, assignments, and exams make it difficult to join.
	•	Lack of planning: Students often find activities at the last minute, making attendance inconvenient.
	•	Social barriers: Some students fear awkwardness, not knowing anyone, or being unsure of the atmosphere.
	•	Poor experiences: Certain events are poorly organized (e.g., long waiting times, unclear details), lowering satisfaction.

3. Key Information Students Want
	•	Basic info: Location (on-campus or off-campus), time, cost, organizer.
	•	Activity details: Expected number of participants, event content, whether there’s a certificate or skill outcome.
	•	Transparency: Clear descriptions, and signals like “newcomer-friendly” or “welcome to come alone.”

4. Desired Platform Features
	•	Bookmark/favorites: Save interesting activities to check later.
	•	Reminders: Calendar sync or light push notifications are preferred over emails.
	•	Student reviews/ratings: Most students said they would trust peer feedback to reduce anxiety and make better decisions.

5. Overall Attitude Toward a Unified Platform
	•	Almost all interviewees agreed that a platform with an activity list, detail pages, favorites, and reviews would significantly improve:
	•	Awareness (visibility of activities)
	•	Decision-making (confidence and clarity in choosing)
	•	Participation (actually joining activities)
	•	Students believe this solution would reduce missed opportunities and encourage more engagement.

