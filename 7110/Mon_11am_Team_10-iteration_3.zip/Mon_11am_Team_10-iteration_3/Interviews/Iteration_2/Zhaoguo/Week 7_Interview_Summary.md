Week 7 Interview Summary

1. Awareness
Most students obtain event information through friends, UQ emails and social media. However, many feel these channels are too fragmented: social media content updates rapidly, making it easy to miss events, while emails are frequently overlooked.

2. Missed Activities
The primary reason is excessive academic or part-time work commitments. Secondary factors include scattered and untimely promotion; some students abandon events even when aware of them due to forgetfulness or lack of energy.

3. Centralisation
All respondents agreed a centralised platform would be more efficient and reliable than flyers or scattered social media posts, reducing oversights and saving time.

4. Event Details Page
There was widespread desire for clear information on timing, location, cost, and registration requirements. Some also sought details about organisers and the event atmosphere.

5. Collection & Reminders
Most would use a favourites or bookmark feature provided it is simple and convenient. For reminders, push notifications and calendar syncing are most favoured, while email alerts are less popular.

6. Feedback & Trust
Authentic student reviews command broad trust, particularly concise and specific feedback.

7. Engagement
Most students attend only 1–3 events per term, citing limited time and unclear event information as primary barriers.

8. Validation
Respondents unanimously agree that a platform featuring event listings, detailed pages, favourites functionality, and a review system effectively addresses awareness, decision-making, and participation challenges.