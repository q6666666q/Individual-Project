Re-record Iteration1 Interview 2
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/(Re-record)%20Iteration1_Interview_2.m4a?csf=1&web=1&e=JRy34a


Interviewer: Hi, I'm Jeric. And right now, our team—we are doing a small survey about extracurricular activities at UQ. Can you help me, Could you help me to answer some questions for us?

Interviewee: Yes, no problem.

Interviewer: Oh, great! First, just let you know we will record this interview, but you can ask for a stop at any time and we can also delete the recording too. Is it convenient for you?

Interviewee: Yeah.

Interviewer: OK, that's fine. Let's begin. The first question is, have you heard about any extracurricular activities at UQ?

Interviewee: Oh, yeah, I heard about them on some platforms like the school's official accounts or student accounts like on Instagram or TikTok. But I don't see them very often. And it feels like there are not many activities I can find. Just like, you know, the orientation week for the freshmen. Lots of my fresh classmates around me they participated and they said that's pretty good. Besides that, the school, I think they held a winter festival. I heard it was at the central lawn and they set up a small stage there and you know, there were many things to play. You could play on it. Also, sometimes when I walk past the street, I will see some celebrations for festivals from different countries. Yeah, uh, they set up special stores. I've seen other people share about this on social media too, yeah.

Interviewer: Oh, OK, I got it. So have you actually taken part in any of these activities? And if you have, could you share a little bit about your experience?

Interviewee: Okay, actually, I have only participated in the orientation week. The others, I haven't really joined. On one hand, I have a lot of coursework and assessments for me to do, so I don't have that much free time to go out of my way to attend them. On the other hand, sometimes I found out about the activities too late, like uh when I see the information, the activity is ending the same day, or the sign up channels have already closed. I don't even get a chance to sign up, so you know, I cannot go.

Interviewer: Oh, I see. And so what do you usually do if you are walking around campus and see an activity that's going on?

Interviewee: I usually don't really join in because when I walk past, the activity has already been going for a while. Everyone's already grouped up and joined in. If I go over alone, I don't know how to fit in. I can only stand on the side and watch the fun. I can't really join the play.

Interviewer: Oh, okay, all right. Are there any other things that may stop you from joining activities?

Interviewee: Yeah, sometimes I think even if I found out about an activity early, I'm not sure if it's actually worth going. Like, sometimes they only say a little bit about what it's about, not, no details. It makes me hesitate, you know. I don't want to waste time going if it's not my type.

Interviewer: Oh, I know. And so, if there was an activity that made you want to join, what kind of information do you want to know first?

Interviewee: First, I think it's the location. I hope it's on campus, like near the teaching building or the student center. It's easy for me to get there from my class. Um, I don't, in this way, I don't have to spend extra time taking the bus or walking off campus. It's more convenient. And for the time, I don't have any special requirements, any time is fine as long as it's not when I have classes or need to hand in an assignment. And then the content of the activity, I think. If the activity lets me experience something I haven't tried before, like a handcraft shop, uh, cultural sharing session or some stuff like that, uh, that would be pretty good for me.

Interviewer: Oh, OK, great. And the last question: for the activities you participated in before, like you mentioned orientation week, how satisfied are you overall? If you had to give them a score, what it would be?

Interviewee: I would probably give it a six or seven out of ten. Not only because I haven't participated in that many activities, the ones I remember most are orientation week and a food festival I happened to walk past and join in for a while a little bit. Both of those were actually pretty good experiences. Like at the orientation week, I met a few classmates, and at the food festival, I got to try a lot of special snacks. But the reason I didn't give a higher score is that I usually find out about activities by myself. It's not like the school tells us clearly in advance through emails or some other ways so I can plan my time to go. This feeling makes me feel less involved, so I didn't give a super high score.

Interviewer: OK, that's alright and that's all of our survey thank you all for joining.

