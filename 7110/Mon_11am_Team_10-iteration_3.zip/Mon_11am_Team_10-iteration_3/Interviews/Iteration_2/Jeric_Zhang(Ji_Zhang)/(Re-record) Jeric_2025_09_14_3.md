Re-record Iteration1 Interview 3
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/(Re-record)%20Iteration1_Interview_3.m4a?csf=1&web=1&e=YdIKHZ


Interviewer: Hi, I'm Jeric, now we are doing a small survey about extracurricular activities at UQ and we hope we are hoping to gain some insights from students. So uh, could you help us to answer some questions?

Interviewee: Yeah, sure.

Interviewer: Okay, uh, just let you know we plan to record this survey to make sure we don't miss any of our thoughts. So uh, but you, but you can feel free to pause or stop the interview record at any point if you like, is that convenient for you?

Interviewee: Yeah.

Interviewer: Okay, let's begin. Ah, the first question is have you ever heard any... uh, have you heard about any extracurricular activities at UQ?

Interviewee: I think my, uh, study life, I heard so many different activities in my, um, school life.

Interviewer: Could you give us some examples?

Interviewee: Yes, for some examples I know that there have a uh activities support by APS and I always join the activities, uh, they have some activities for a tea party and for some science learning and I really like to join them. And also the school have some volunteer activities, sometimes I will join them too.

Interviewer: Oh okay, sounds great. And where do you usually get information about these activities?

Interviewee: Ah, well, for some example, uh, I will know some, some news from my classmates and I will, I can find in the website just like ins or, or Rednotes and we also have the a wechat group and they will told told me uh when and where the activities will have.

Interviewer: Ah, okay, okay, I got it, ah, so in the past semesters, uh, did you join any activities...uh we've heard about you that you joined a lot and could you tell me some details? Uh Details.

Interviewee: Oh well, for some details, just like, uh, last Friday I joined the APS activity activities and they just, uh, in the, uh, UQ lake station and they will have tea party and talk about some science. uh uh and technology uh, I joined that activity I, um, just a eat some delicious, delicious foods is very good.

Interviewer: Okay, so the food attract you, attract you or the some other things which you think is work for you?

Interviewee: Well, uh, for actually the food is also uh attract me because the food is from the uh different countries and I can eat the different delicious food in this world, and at the same time I can, uh.Uh, talk with different people and I think it's a very good activity.

Interviewer: Ah, okay, sounds great. And the way you search for activities to participate in, what information do you pay attention to?

Interviewee: Well, I think the first information I pay attention to is whether... uh when the activity is hold and where the activities, and at some time I will also to uh attention whether these activities need to pay money to join it. Just like some activities I need to pay for some money. Ah, maybe it's too expensive? I will think about it whether I want to join that.

Interviewer: Okay I got it and the last question, uh, over overall, how satisfied are you with activities you attend.

Interviewee: Oh, well, I think these activities, uh, uh have so many, so many different activities and uh.I, we, we can, uh, find almost, uh, all different types, uh different type of the activities and I think it's very friendly and a great help to us students.

Interviewer: Oh, okay, so overall you feel good about them or...

Interviewee: Yeah, I I it's very, very good for students and I also help, uh, they can have a website to together all the different activities so we can find them more easily.

Interviewer: Okay, okay, thank you for your answers.