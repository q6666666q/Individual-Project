Value Proposition

1. Activity Information Sources 
Right now, UQ students get info about activities from different places: friends, posters, and social media like Instagram, Tiktok or Facebook. But this often leads to missing activities. Many students said they missed events because they “heard about them too late” or “forgot after first finding out.” A centralized platform would solve this by putting all activities in one place. It would mean students don’t have to switch between 2 or 3 different channels.

2. Key Information about Activities
When students decide whether to join an activity, they always focus on 3 important information: time, location, and cost. Also, most students trust reviews from other students. Giving these details upfront would reduce problems when making decisions. However, one student (Interviewee 1) said he regretted missing an activity because of one friend’s unfair feedback.

3. Activity Participation Frequency
Most students (4 out of 5) join only 1–2 extracurricular activities per semester, while 1 student joins 2–4. The frequency is lower than our expected and here is the reason:
Busy schedules: Coursework, assessments, and part-time jobs (mentioned by most students) leave little free time, especially in the latter half of the semester. One student mentioned “it’s easier to attend events at the start of the semester, but things get too busy later.”
Information gaps: When students find interesting activities, they often miss them because they “forget after saving” or “hear about them too late”.
Personal preferences: A few students prefer resting at home, or avoid crowded environments.

4. Overall Attitude Toward Our Platform
All 5 students hold a positive attitude toward a centralized platform and are willing to use it. They said this platform could save their time and would help them to make decisions.



MVP

1. Activity List with Sorting Function
Many students wanted an activity list with sorting options: date (e.g., “coming soon,” “newest”), popularity, and tag (by activity type).

2. Activity Detail Pages
Many students need this key information to decide whether to join an activity: time, location, cost, and participation information.

3. Bookmark Function
All five students stated they would use this feature. It addresses the “save first, decide later” habit due to students' busy coursework, and helps prevent them from missing activities.

4. Reminder Function
Most students thought a reminder function is useful. Many students choose calendar as the primary reminder tool. Emails can be added as a secondary option, but push notifications are not very popular—some students find them noisy.

5. Ratings and Reviews
Most students trust reviews (online or offline), but some of them are unwilling to write reviews without rewards. It is important for us to find a way to motivate users to leave reviews.