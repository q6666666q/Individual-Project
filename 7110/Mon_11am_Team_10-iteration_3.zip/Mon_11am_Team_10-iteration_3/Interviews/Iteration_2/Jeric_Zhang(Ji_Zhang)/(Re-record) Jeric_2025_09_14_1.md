Re-record Iteration1 Interview 1
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/(Re-record)%20Iteration1_Interview_1.m4a?csf=1&web=1&e=usU1sT


Interviewer: Hello, I'm Jeric. At the moment we are doing a small survey about extracurricular activities at UQ and can I ask you some questions?

Interviewee: Yeah, sure.

Interviewer: Okay, and just to tell you, our survey will be recorded, but you can, ah, you can ask for a pause, to stop answering or ask me to delete the record any time during the process, is that okay?

Interviewee: Okay.

Interviewer: That's fine, let's begin. The first question is, uh, have you heard of any extracurricular activities at UQ?

Interviewee: Um, yeah, sure I've heard of some, you know, for example, the orientation week and some food festivals and something, yeah.

Interviewer: Oh, okay, and could you give us some details? Ah, for example, from what sources uh, and, what sources did you hear about these activities?

Interviewee: Yeah, I think mostly from my friends. And you know, sometimes, uh, some offline ways too, but yeah, mainly from my friends. And also from some social medias like Instagram or TikTok, yeah.

Interviewer: Oh, Okay, after you heard of them, did you actually join some, uh join any? Could you describe the experiences?

Interviewee: Yeah. I only joined the orientation week. Uh, and you know, during the orientation week, I met some classmates, and got some food, and yeah, and got some gifts.

Interviewer: Ah, okay, all right, and what stopped you from joining more activities?

Interviewee: Uh, I think mainly because I have too much assignments to do, you know, and I need to spend a lot of time on programming and debugging. Yeah, and sometimes I have, also have other plans like going to the gym or traveling with my friends. Yeah, and I also have lots of courses to attend, yeah, and sometimes the time will conflict.

Interviewer: Oh, I see, I got it. And before you decide to join these activities, what kind of information would you care about, uh the most?

Interviewee: uh, I think the most important thing is the content, the the type of the activity, um,it depends on whether I'm interested in, and I think if I'm not interested in this type, I probably won't to consider it, yeah. And, um. Besides that, I think maybe the time, if the activity, uh, last longer than I have more, uh, I mean flexibility to arrange my schedule and so it can. There won't be too many conflicts and it will be easier to fit in and yes, I think mainly uh, these two points and about if I'm really interested in, um, but I mean , sorry, uh, if I'm really interested and have some free time, I think I would probably give it to a ,to a try.

Interviewer: Okay, Okay, and then the last question. Uh, you said you joined the orientation week. How satisfied were you at that time?

Interviewee: Uh, yeah, I think pretty good and will give a full mark, uh, because it was right, uh, it was when I just arrived and uh, all things makes me feel new and fresh and it impressed me a lot so I will give, give a it a full mark.

Interviewer: Oh, that's good, it's a really high score. So, uh, that's all of our survey and thank you for your participation.

Interviewee: Okay, thank you.