Re-record Iteration1 Interview 4
https://uq.sharepoint.com/:u:/r/teams/Section_7560_62502/Shared%20Documents/Mon_11am_Team_10/Interview%20Audio/JericZhang(JiZhang)%20Interview/(Re-record)%20Iteration1_Interview_4.m4a?csf=1&web=1&e=Iuw336


Interviewer: Hi, hello, I'm Jeric. Uh, for now we are doing a small survey about extracurricular activities and could you help us to answer some small questions?

Interviewee: Yeah, of course.

Interviewer: Ah, okay and uh, to tell, just to tell you our survey will be recorded, but if you feel uncomfortable you want to, you can stop, pause or or ask me to delete the record at any time during the process, and is that okay for you？

Interviewee: Okay.

Interviewer: All right, and let's begin a first. Uh, I'd like to ask if you have heard of, heard about any, uh, extracurricular activities at UQ?

Interviewee: Oh yes, I've heard of some, for example, the koala touching activities at the beginning of last semester. I also know about some food festivals and sometimes that activities as well.

Interviewer: oh, okay. And uh, so how do you heard about this activities.

Interviewee: Well, in most cases it's through friends. Additionally, I also get emails with announcements about upcoming events.

Interviewer: Oh, okay, and uh, have you ever actively look for the active activities for your by, by yourself?

Interviewee: Um, not much. Mostly I hear from others and if something catches my interest, I'll join. I don't often search for them on my own.

Interviewer: Oh okay, okay, I got it and after hearing about them, uh, have you, have you specifically joined any activities and could you share some experiences?

Interviewee: Yeah, one specific one was a winter carnival, but I didn't really try the activities. There I went with a friend and we mostly just walk around, tried some food and enjoyed the atmosphere. We also took some photos together.

Interviewer: Oh, okay, and so for those activities you have mentioned before, like the food festival and koala touching, did you act actually join, join them or you just hear about them?

Interviewee: I did actually attend the koala event. I lined up and go to touch one. But the food festival, I only heard about it.

Interviewer: Oh, okay, okay, that's fine and uh, in general, when you decided to join the activities, uh, what kind of information do you think is, is the most, uh, is the most things you want to, you want to know.

Interviewee: Well, first I will check the time, whether it clashes with my classes and and then also the location. Sometimes if it's right after class and nearby, I might go take a look because sometimes even if it's not very interesting, if it's close, I might go, but if it's far, I won't spend extra time to go.

Interviewer: oh, okay. I got it and then the the last question, how satisfied are you with the activities you've attended?

Interviewee: If out of 10 at they maybe six or seven because I think the activities match their descriptions but sometimes the waiting time is really long. For instance, the koala events had a long queue and at the winter carnival I noticed that most rights had about 20 to 30 minutes wait, which put me off.

Interviewer: Okay, okay and that's all for this interview. Thanks for your participating.

Interviewee: OK.

Interviewer: Ok, goodbye.
