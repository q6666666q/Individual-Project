https://uq.sharepoint.com/:u:/t/Section_7560_62502/EaakRMpl03BNk1V13zbmFKkBuaRfV62t_euf6kZ5Uh4QLA?e=Zqo3qP


00:00:00 
 Hello, thank you for taking the time to talk with me today.

00:00:06 
 Before we start, I would like to let you know that I would like to record this interview

00:00:13 
 so I can transcribe it later for my customers.

00:00:17 
 The recording will only be used for this customer.

00:00:21 
 You can be free to review, stop answering at at any time or ask me to delete recordings.

00:00:29 
 Do I have your concerns to record these interviews?

00:00:33 
 Sure, that's fine.

00:00:36 
 Okay.

00:00:38 
 How do you hear about the instructor, regular activities at UQ?

00:00:48 
 Most of the time I heard about them from UQ's Instagram and also from my friends.

00:00:55 
 Sometimes I see posters, but honestly I don't pay much attention to those. Okay. And do you think a path forward that provide activities,

00:01:10 
 help page, various reviews would solve the problems of awareness,

00:01:17 
 decisions, and participation?

00:01:20 
 Why or why not?

00:01:22 
 Yes, because right now the information is scattered.

00:01:27 
 A centralized platform will save me a lot of time.

00:01:32 
 Reviews are important too.

00:01:35 
 I usually ask friends if one is worth going.

00:01:39 
 So having reviews in the app would be even better. Okay.

00:01:48 
 What do you hope to gain from participating in structural

00:01:53 
 activities?

00:01:57 
 Mainly networking. I want to make more connections, especially with friends in different majors.

00:02:04 
 Also, I like to build my resume. Clubs and volunteers work a lot good on applications.

00:02:11 
 Okay. On average, how many activities did you do during each semester?

00:02:22 
 What do you do really stop you from joining more?

00:02:27 
 Maybe one or two, I think. Not much. The biggest reason is I don't know about many events until it's too late.

00:02:37 
 Sometimes it's also because I'm not sure if the event fits me.

00:02:44 
 because I'm not sure if the event fits me. Okay. And here there be a situation where you want to go but not to.

00:03:00 
 Can you give me examples?

00:03:03 
 Yes, I plan to go to a coding workshop, but the registration link was headed deep on the

00:03:10 
 website.

00:03:11 
 By the time I found it, it was already full.

00:03:14 
 That's the kind of thing that made me give up. Okay. And if we provide a platform that automatically creates a cloud and

00:03:31 
 display all ongoing activities, do you think this would be more convenient

00:03:38 
 how do you can to respond the activities? and why or why not?

00:03:47 
 Yes, much more convenient. It would be like a fun stop shop, so I didn't need to check Instagram,

00:03:55 
 Facebook, and email separately.

00:04:01 
 Okay.

00:04:17 
 If you want to find the structure, what kind of way or platform would help you find them quickly? I think filters by category would be helpful, like sports, academic, social.

00:04:25 
 Also a search bar to quickly find something specific.

00:04:30 
 Okay.

00:04:33 
 And if you found the favorite activities and added to your calendar with one class, receiving minus two hours before it starts, would this

00:04:53 
 be useful for you?

00:04:58 
 And can you give me examples?

00:05:00 
 Yes, it's definitely useful because I always forget times.

00:05:06 
 Last semester I missed the career fair because I forget the date.

00:05:11 
 So if I had a reminder, I wouldn't have missed it. When searching for activities, would you more often use time-shorting or popularity-shorting?

00:05:31 
 If there was search options, which one would you use more often.

00:05:46 
 - Time sorting? Yes, definitely.

00:05:47 
 My schedule is tight,

00:05:49 
 so I need to know what fees,

00:05:52 
 but I also check popularity sometimes

00:05:56 
 when I just want something fun and social.

00:06:00 
 Okay. If the platform around you to read and comment on activities would be willing to participate?

00:06:16 
 Yes, definitely. But I prefer it to be quick, like start reading with optional comments.

00:06:27 
 I wouldn't want to write a long review.

00:06:31 
 Okay.

00:06:32 
 And do you think such reviews would help you decide whether to join an activity?

00:06:47 
 Yes.

00:06:49 
 If I see many positive reviews, I would trust that events are good.

00:06:54 
 If reviews say it's fully organized, I'll avoid it.

00:06:59 
 It will really help me make faster decisions.

00:07:04 
 Okay.

00:07:07 
 Thank you for your answers.