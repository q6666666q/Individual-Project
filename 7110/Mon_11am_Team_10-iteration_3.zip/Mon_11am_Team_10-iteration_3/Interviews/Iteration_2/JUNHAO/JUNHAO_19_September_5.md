https://uq.sharepoint.com/:u:/t/Section_7560_62502/EVCpU2As2ZhHmGAjb9UBHcIBqY-yxOh9WE_qZmUisYxgaQ?e=Ni7fY3


00:00:00 
 okay thank you thank you for taking the time talk with me today before we start I would like

00:00:09 
 to let you know that I would like to recording this interview so I can transcribe it later for

00:00:15 
 my course words the recording will only be used for this course one you are free to review, stop answering at any time or ask me to delete the recordings.

00:00:27 
 Do I have your concerns to record these interviews?

00:00:32 
 Okay, let's begin.

00:00:35 
 Okay.

00:00:36 
 How do you hear about the instructor curricular activities at UQ. I usually hear about activities through student social media groups and

00:00:52 
 sometimes posters around campus. However, I often miss opportunities

00:00:58 
 because the information is scattered. Okay. Do you think the platform

00:01:06 
 that provides

00:01:12 
 activity leads

00:01:14 
 at least a TTR page

00:01:16 
 and reviews

00:01:18 
 with all the problems

00:01:20 
 of awareness,

00:01:22 
 decision marking, and

00:01:24 
 participation?

00:01:25 
 Why or why not?

00:01:29 
 - Yes, it will help a lot.

00:01:32 
 Having all the information in one place

00:01:35 
 makes it easier to compare activities,

00:01:39 
 check requirements, and decide quickly.

00:01:44 
 Reviews from other students would also give me more confidence to participate.

00:01:54 
 What did you hope to gain from participating in the activities in the instructor-arricular activities.

00:02:12 
 I hope to make new friends improve my communication and leadership skills and

00:02:20 
 gain experiences that are different from my academic studies.

00:02:27 
 Okay, on average, how many activities do you usually join each semester?

00:02:34 
 What usually stops you from joining more is many

00:02:48 
 time conflicts with classes and sometimes not knowing about events earlier enough.

00:03:00 
 been situations where you want to go but decisions not to. Can you give me examples?

00:03:12 
 Yes, I once wanted to attend a cultural festival but decided not to because the registration

00:03:21 
 process was unclear and I wasn't sure if I made the requirements.

00:03:29 
 Okay. If we provide a platform that automatically collect and display all displayed all ongoing activities. Would you think this would be more

00:03:50 
 convenient than how you can find activities right or why not?

00:04:04 
 Definitely, it saves time compared to check multiple websites or groups.

00:04:09 
 And I wouldn't miss events because everything is updated in one place. If you want to find a structure, rigorous activities, what kind of way or a path forward would help you find them quickly?

00:04:37 
 A mobile app with a sample search bar and filters like time, location, and type of activities would be the

00:04:48 
 fastest way. activities and add it to your car readers with one clip, resizing and remind two hours

00:05:16 
 before it starts. Would this be useful for you? And can you give me examples for this?

00:05:27 
 Yes, for example, if I if I've finished a theory workshop and get a reminder a few hours before,

00:05:36 
 I wouldn't forget it even if I'm busy with assignments. Okay. When searching for

00:05:50 
 activities, would you

00:05:52 
 more often

00:05:56 
 use time,

00:05:58 
 shorting, or

00:06:00 
 If there were such options, which one would you use more often?

00:06:11 
 I would use time sorting more often because I need to know which activities fit into my schedule first.

00:06:36 
 Okay. If the path forward allows you to rate and the comments on activity, would you be willing to participate? Yes. If the reviews are short and easy to give, I would rate activities. Feedback would also help organize and improve.

00:06:50 
 OK.

00:06:51 
 Would you think such reviews would help you decide whether to join an activity?

00:07:04 
 Yes. whether to join an activity? - Yes, seeing positive reviews and experiences

00:07:08 
 from our students would encourage me to join,

00:07:12 
 especially if I'm unsure.

00:07:16 
 - Okay, thank you for answering.