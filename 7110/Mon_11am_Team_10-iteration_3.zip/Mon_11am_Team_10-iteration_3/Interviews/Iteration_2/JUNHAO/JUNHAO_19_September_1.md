https://uq.sharepoint.com/:u:/t/Section_7560_62502/EavYKoVrPZtHlBQcQ8FmvfEBCPrPPYLdMUslhkLYIo-oxA?e=ZTN8T5

00:00:00 
 Hello, thank you for taking the time to talk with me today. Before we start, I would like

00:00:12 
 to let you know that I would like to record this interview so that I can transcribe it later for my coursework. The recording will only be used for this coursework. You

00:00:27 
 can free to refuse stop answering at any time or ask me to delete the recording.

00:00:36 
 Do I have your concern to recording these interviews?

00:00:42 
 Yes. Okay, the first question is how do you hear about

00:00:49 
 the instructor a real current activity at UQ? Most of the time I hear about activities from

00:00:58 
 friends or group chats. Sometimes I check on UQ website honestly, I don't use it often. I also follow

00:01:06 
 UKU International's Instagram account and that's where I see many event posters.

00:01:15 
 Okay, the next question is: Do you think a platform that provides

00:01:25 
 provide a bright activity list detail page. Favorites and reviews would solve the problem of awareness,

00:01:33 
 decision, marking, and participation.

00:01:38 
 Why or why not?

00:01:41 
 Yes, I think it will help a lot.

00:01:43 
 Right now, information is scattered and I don't always

00:01:47 
 know which events are happening or which ones are worth my time. If there is a place where

00:01:53 
 the clear details plus review from students, I can decide faster. Favorite schools also

00:01:59 
 help me trick events I interesting. What do you hope to gain from participating in a structured regular activity?

00:02:16 
 I want to meet new friends, especially out of my course.

00:02:20 
 I also want to participate in my English and get more social experience.

00:02:25 
 Sometimes I join activities because they are fun and useful, like workshops, like giving

00:02:30 
 me extra skills.

00:02:32 
 On average, how many activities do you usually join each semester?

00:02:43 
 What usually stops you from

00:02:45 
 joining more?

00:02:48 
 Usually I join two or three

00:02:50 
 activities each semester.

00:02:51 
 I don't join more because I often

00:02:53 
 don't know what's happening or what's

00:02:55 
 meeting classes with my classes.

00:02:58 
 Also, if the events

00:03:00 
 information isn't clean I don't feel confident to go.

00:03:05 
 Have there been a situation where you want to go but But the sister decided not to. Can you give me an example?

00:03:33 
 Yes, last semester I saw cultural festival on Instagram, but I wasn't sure if I needed to register or pay.

00:03:41 
 By the time I asked my friend, it alright too late, I didn't go.

00:03:47 
 Okay, and this is the part. And the next question is part two.

00:03:54 
 And the part two first question is: if we provide a platform,

00:04:30 
 provide a platform that automatically create and dissipate all ongoing activities. this would be more convenient than how you currently find activity. Why or why not?

00:04:37 
 Yes, it would be much better. At the moment, I have to look multiple places like Facebook groups, emails, and posters. If one platform shows all activities clearly in one place, I can quickly

00:04:43 
 compare and decide. It

00:04:46 
 will save me time and reduce the chance of missing activities.

00:04:50 
 And the next question is if you want to find a structure and regular, what kind of the platform will help you find quickly.

00:05:07 
 I like to use flitters like searching my by time type and activities of free via page.

00:05:15 
 For example, if I free on Friday night, I want to say all the activities that I, the keyword

00:05:22 
 search would also be good if I already know the event name.

00:05:28 
 - Okay.

00:05:33 
 If you could, if you could

00:05:34 
 favorite an activity

00:05:38 
 and add it to your career

00:05:49 
 with one query a query

00:06:00 
 receive and risk receiving and reminders two hours before it's done one

00:06:00 
 But would this be useful for you?

00:06:05 
 And can you give me an example?

00:06:10 
 Yes, definitely.

00:06:12 
 Last semester, I registered for a voluntary session,

00:06:16 
 but forgot about it until it was over.

00:06:20 
 If I would delete it to my Google Calendar and get a reminder, I wouldn't miss it.

00:06:25 
 One click for written reminder would make participation easier.

00:06:31 
 Okay.

00:06:34 
 When searching for activities, would you most often use time shoutingshorting or popularity-shorting. If there was a search option, which one would

00:06:55 
 you use the most often? I use time-shorting most often because I use time storing most often because I use fake activities around my study schedules.

00:07:06 
 But I'd also like to check popularity scoring when I just want to find popular events that other students are joining.

00:07:14 
 Benefit talks like networking or fun would also help.

00:07:46 
 If the platform allows you to read a comment on 1 to 10 points, would you willing to participate? Yes, I leave short previews if it helps other students.

00:07:51 
 For example, I would say if an event was well organized or worth the time.

00:07:56 
 I'd also definitely check previews before deciding, especially if I don't know the club or organizer. Okay.

00:08:07 
 Do you think a search review will tell you

00:08:13 
 the awareness to join an activity?

00:08:20 
 Yes, reviews would get me more confident right now.

00:08:23 
 I sometimes hesitate because I don't know what the event will be like.

00:08:28 
 If I can see real feedback from other students, it will feel less risky to join.

00:08:34 
 Okay, thank you for your answer.

00:08:37 
 You're welcome.