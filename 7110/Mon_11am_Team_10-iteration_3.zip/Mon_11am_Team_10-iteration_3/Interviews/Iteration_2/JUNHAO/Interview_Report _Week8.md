# Interview Report (Week8)

### Overview

This week, I conducted another round of interviews with UQ students about extracurricular activities. Compared with iteration 1, our questions were refined to focus on **MVP features** (activity list, activity details, bookmarking, reviews, reminders) and how these address core issues of **awareness, decision-making, and participation**.

### Key Findings

1. **Information Scattering**: Students still rely on posters, social media, and word of mouth, which causes them to miss events. A centralized list was repeatedly seen as “time-saving” and “more convenient.”
2. **Decision-Making**: Students emphasized the importance of **clear details** (time, cost, requirements). Reviews and peer feedback were mentioned as strong motivators, especially when they are short and easy to give.
3. **Participation Barriers**: Time conflicts and late awareness remain the main reasons for low participation. Students suggested reminders as a practical solution.
4. **Value Gained**: Students expect activities to help with **social connections, communication skills, and personal growth**, which confirms our earlier hypotheses.

### Reflection

- **Improvement from Iteration 1**: In iteration 1, our ideas included many advanced features (e.g., recommendation systems, personalization). Feedback showed these were too ambitious. Now, we focused on **basic core features** (list, details, bookmarking, reviews, reminders). Interviews confirmed that these align more directly with students’ real needs.
- **Limitations**: Our current sample size remains small, and some participants may already be more active students. To strengthen validity, more diverse participants (e.g., students who rarely join activities) should be included.
- **Hypotheses Updates**: Hypothesis 1 (awareness) and Hypothesis 3 (decision-making support through reviews) were supported. However, the role of reminders (Hypothesis 2) still requires further validation across a larger group.

### Conclusion

Iteration 2 interviews provided strong evidence that our simplified MVP features better address students’ problems than our initial iteration. Students found the design more **practical, realistic, and motivating**. For iteration 3, we should continue testing **reminder effectiveness** and refine how reviews are displayed.