https://uq.sharepoint.com/:u:/t/Section_7560_62502/EcBeBq9nGyxArCNXV_ouRukBaTeLcmc3FZIlcRfCIFu5cw?e=vZaoBy


00:00:00 
 Hello, thank you for taking the time to talk with me today. Before we start, I would like to let you know that I would like to recording this interview so I can transcribe it later for my crossword. useful this cursor you can free to review stuff stop answering at any times or

00:00:29 
 ask me to delete the recording do I have your concern record these interviews

00:00:36 
 yes yes you do okay the first question is how do you usually hear about

00:00:42 
 the instructor a regular activity at UQ?

00:00:47 
 Usually I would either read about it online or maybe through advertisements or

00:00:53 
 either through word of mouth from people that go to the college. Okay, do you think a platform that provides activity, this detailed page,

00:01:07 
 failures and reviews would involve the problem of the awareness, decision marking

00:01:15 
 and participation? Why or why not? I think a platform would be very helpful for making people aware of what goes on within UQ.

00:01:31 
 And it could definitely help with participation if people found it easy to find activities they like.

00:01:54 
 Okay. What do you hope to gain from a participation in the instructor- instructor-a-recruited activity?

00:01:58 
 Probably to meet new people, make friends, make connections, and depending on the

00:02:06 
 extracurricular activities to either improve health or help with stress or to

00:02:17 
 help build brainpower, anything like that. Okay. On average, how many activities do you usually join each semester?

00:02:33 
 What usually stops from joining more?

00:02:38 
 It would either be because I don't enjoy the things that I put on the list.

00:02:46 
 And it can either also be, clubs can be expensive,

00:02:51 
 or I don't have time because I have other priorities, i.e. school or work.

00:02:58 
 Hmm, okay.

00:03:00 
 Have there been a situation where you want to go but this is not too? Can you give me would probably be the UQ Rugby, the Red Hives.

00:03:29 
 I first started playing, or I looked at joining a while ago,

00:03:35 
 but when I was busy with work and school,

00:03:42 
 I found it hard to make time to join the club, even though I really liked it.

00:03:48 
 Okay, and the next is the part two. if we provide a platform that automatically collect and display

00:04:15 
 all going activities, do you think this would be more convenient than how you currently have

00:04:34 
 the activity? Why or why not?

00:04:40 
 I think having a platform that displays how many people are in the club or what's going on would make it easier and definitely a lot more convenient for people looking to find a structural activity, what kind of way or path forward would help you find it quickly?

00:05:13 
 I would say going through the UQ website or sometimes social media can be beneficial because they promote clubs.

00:05:26 
 Okay, and if you could favorite activities and add it to your current one acrylic. Receiving remind two hours before it starts. Would this be useful for you? Can you give me a sample?

00:06:00 
 I think that would be a good idea for students or me who has a lot going on in their week and is very busy.

00:06:13 
 And if, say, I had a busy day and I forgot that I had whatever extracurriculum activity going on,

00:06:28 
 extracurriculum activity going on. If an alarm went off two hours before, that would make sure to remind me to attend.

00:06:30 
 Okay. When searching for activities, would you more often use time shorting or popularity shorting?

00:06:48 
 If there was such an option, which one would you use time or registration requirements because if a club costs a lot to join or it's very popular and high demand,

00:07:26 
 and high demand. I'd obviously want to look at filtering out a few clubs that are more expensive or has a high popularity so I wouldn't be able to join

00:07:32 
 it. So filtering that out would be really useful, yeah.

00:07:35 
 Okay, and if the platform allow you to read and comment on activities, would you be willing to participate?

00:07:53 
 100%. If the site has or the platform has ratings, reviews, I could have a good idea of what's going on in the club or the

00:08:08 
 extracurricular activity before I join it which would be really useful yeah

00:08:14 
 okay that would that would you be that did you think search reviews such reviews would help you decide whether to join an activity?

00:08:29 
 100%, 100%. If there's reviews then yeah what I said earlier like it make it easier to decide

00:08:38 
 whether the clubs for me or not and make it easier to or be more open for people who are on an edge whether to do

00:08:49 
 it or not do it yeah mmm okay thank you for answer of course