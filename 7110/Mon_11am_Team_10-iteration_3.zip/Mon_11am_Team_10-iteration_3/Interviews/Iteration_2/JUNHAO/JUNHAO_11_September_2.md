[JUNHAO_11_September_2.mp3](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EZrcl4IwvBFFsnI5p9cChW8BhfRGAo02qBLw3_LND_YcNg?e=V04M8I)



00:00:00 
 Thank you for taking the time to talk with me today. Before we start, I would

00:00:06 
 like to let you know that I would like to record this interview so I can

00:00:13 
 transcribe this later for my crossword. The recording will only be used for this crosswalk you can free to refuse stop answering at any time

00:00:29 
 or ask me to delete the recording do I have your concern to recording this

00:00:38 
 interview yes I agree okay how do you usually hear about the structure structure a regular

00:00:49 
 activity at UQ mostly through Instagram especially the UK international student

00:00:56 
 society accounts why do you think students sometimes miss this activity? Because not everyone uses the same social media and the posts can get burned quickly.

00:01:11 
 Okay. Would you prefer having one platform with a clear release of the activity instead of relying offline or scattered social media posts

00:01:30 
 why? yes it would be more professional and reliable. Flyers can update and social media posts

00:01:39 
 sometimes miss details. what kind of the information do you want to see on activity

00:01:47 
 details page before deciding to join? I'd like to see pictures, transcription

00:01:55 
 activity, target audience like international students, undergraduates,

00:02:00 
 postgraduates, and difficult level if it's sports. If there was a feature to say

00:02:10 
 all bookmarked activity for later would you use it? Why or why not? Yes I

00:02:18 
 usually plan my week on Sunday so having saving list of activities would be very convenient okay

00:02:28 
 what kind of reminder reminder would be most helpful you to avoid the

00:02:37 
 forgetting activity I prefer email recommend because i always check my email every morning

00:03:00 
 would you would you trust shot reviews or rating for other students when i did this

00:03:00 
 deciding whether to attend them and activity especially if they are from

00:03:07 
 people who share similar interests with me on average how how many

00:03:16 
 activity do you do with training each semester what stop you from drawing more around one to two per semester the

00:03:31 
 main reason is lack of awareness sometimes I only hear about an event

00:03:37 
 after it's already finished and do you think a platform with we end activity at least detail page previous and

00:03:51 
 we reviewing and reviews would help more with the main issues of the after a

00:03:59 
 awareness decision marking and the Yes, I think it would especially reward and favorit because they make the platform more personal and reliable.

00:04:12 
 Okay, thank you for your answer.