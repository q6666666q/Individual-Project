[JUNHAO_11_September_3.mp3](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EdvlnUj5PmdLl6Io0qNjBT8Bko-XyoEfLWUMMlEJHCZN6Q?e=x7WZeg)



00:00:00 
 Hello, thank you for taking the time to talk with me today. Before we start, I would like to let you know that I would like to recording this crosswalk you can refuse and you can

00:00:28 
 free to refuse stop answering at any time or ask me to delete the recording do I

00:00:38 
 have your concern to recording and record these interviews yes please okay how do you

00:00:50 
 usually share about the structure structure a regular activity at UQ

00:00:57 
 UL is through this university emails that pop up in my inbox every now and then, like news

00:01:08 
 letters from students surveys or the guild. Sometimes I catch one of them on

00:01:15 
 social media, you know, like in Facebook groups for UQ students or on Instagram you could students all Instagram stories from cops I move following

00:01:27 
 occasionally a friend my mention something in Python during our chat either

00:01:34 
 the cafe or in class but there's more heat or miss I don't really rely on

00:01:40 
 posters of flies much anymore because they are easy to overlook when you are rushing around the cappers.

00:01:52 
 Okay, okay. Why do you think students sometimes miss this activity?

00:01:59 
 I think it's mostly because of the information overload. There's just not much going on with emails, notifications, and social feeds

00:02:09 
 bombarding us all the time, and stuff gets buried.

00:02:14 
 Plus, if you are not actively checking special channels

00:02:20 
 like the clubs page or the UQ events app. You might not see it.

00:02:26 
 Some students are super busy with assessments, part-time jobs, or just trying to balance life.

00:02:33 
 So they don't have the bandwidth to hunt for events.

00:02:39 
 And honestly, sometimes the timing is off even when is announced too late or

00:02:48 
 clashes with exams people just escape it without even realizing would you prefer

00:03:00 
 with a clearly list of the activity instead of relying on flying or scattered social media posts. Why?

00:03:12 
 Obviously, yes. I like having one single platform with a clear organized list of all activities,

00:03:21 
 instead of chasing flies around campus or scrolling through

00:03:26 
 scattered social media posts. The reason I think is like a treasure hunt. You might

00:03:36 
 see a poster in the library one day, then a poster on Reddit next and half the time you forget about it by the time you get home.

00:03:50 
 A centralized spot would make it easier to browse everything in one go,

00:03:57 
 filtered by interests like sports or arts and not missing out on cool stuff. It like save time and reduce that frustration of feeling like you are always out of the

00:04:14 
 loops.

00:04:15 
 Imagine logging into apps or websites and bottom everything there are data categories work that's that would be a game changer

00:04:29 
 for someone like me who always melting tasking okay what kind of the

00:04:37 
 information with what kind of the information do you want to see on activity details page before deciding to join

00:04:50 
 Activity details that page I I don't want to talk of information to help me decide if it was my time

00:04:59 
 first of all the

00:05:10 
 First of all, the exact time and location, maybe with a map link if it's off campus, then a solid distraction of what the event is about, like what's the agenda, who it's for, and

00:05:19 
 any fun highlights of guest speakers. Organizer details are key to who is running it, their contact info and maybe a link to their socials or past events. or do I need to pay, any requirements like sign up in advance, when jail or if it's beginner-friendly,

00:05:51 
 or accessibility for like it's wheelchair-friendly or has inter-protectors.

00:06:00 
 enough that so I can picture myself there and not regret Sean.

00:06:08 
 Okay. If there was a feature to save all bookmark activities for later, would you use it?

00:06:19 
 Why or why not? Yes, I totally use a future to save our bookmark activities for later

00:06:27 
 sounds so handy because sometimes I spot something interesting while scrolling

00:06:33 
 during a quick break but I'm not ready to commit right now maybe I need to check

00:06:39 
 my schedule and ask a friend if they are keen. Bookmarking would let me stash it

00:06:47 
 with and come back to it without losing tracks in a sea of notification.

00:06:55 
 It's like having a personal wishlist. I couldn't build a collection of

00:07:02 
 potential events over the semester and reveal than when I have downtime. Without it, I often forget about the stuff and miss out. Don't use it only if the platform was clunky or hard to navigate, but it's smooth I love bill hip okay what kind of the

00:07:33 
 reminder would be most helpful you to avoid forgetting activity for reminders

00:07:41 
 post notification would be the most helpful for me, hands down.

00:07:47 
 They are right there on my phone popping up at the perfect time without me having to open an app.

00:08:26 
 hmm okay would you would you trust short reviews or rating from other students when deciding on activities as long as they seem genuine and not fancy okay and on average how many activity activity to do you rejoin each semester? What stops you from joining more?

00:08:50 
 I joined about two to three activities per semester, things like a club meetup, a workshop, or maybe

00:09:00 
 suppose that if it's for me it fits my schedule what stops me from drawing more

00:09:08 
 mostly time construction between lectures, assignments, building up and trying to

00:09:14 
 squeeze in some exercise or hang out with friends my counselor feels fast

00:09:21 
 schedule conflicts are a bigger one if I want to clash with a class or worksheet

00:09:30 
 it's a no-go sometimes it's just a boring out after a long week and the last thing i want is

00:09:37 
 another commitment cost can be a barrier too if it's not free and if I'm not super passionate about a

00:09:46 
 topic I'm pressure the rest plus if I don't know anyone going out it feel a

00:09:54 
 world shopping if they were better way to connect the appeal every I'd push for

00:10:02 
 more do you think a powerful within we

00:10:07 
 activity is the detail page failures and reviews would be would help more a main

00:10:15 
 issue of the awareness decision marking and participation oh yeah I think our platform is an activity list it our

00:10:27 
 pages favorites and will totally have solved the main issues around the owners

00:10:35 
 decision-making and participation for awareness and centralized and everything

00:10:41 
 means no more missing out because it's all in one spot. Easy to check regularly without the housing.

00:10:51 
 Detail pages would make decision-making a better by giving all the info up front so I can wipe posts and accounts quickly. Feralits keep me organized reminding me of options without over-win my brains.

00:11:11 
 And the real idea that trust factor encourage me to actually show up. up knowing is worthwhile. Overall, it is boosted participation by knowing barriers like reducing

00:11:31 
 formal and making the whole process feel seamless and fun. If it is integrated with my counselor or had social features to invite friends.

00:11:47 
 That'll be icing on the cake and probably get more students involved.

00:11:53 
 Okay, thank you for your answer.

00:11:55 
 No worries.