[JUNHAO_11_September_4.mp3](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EVxgHjf_ALJMvXHeYLzTee4B7UG3EUn3TZJNX0hDnuSIVQ?e=TvQpDT)



00:00:00 
 Hello, thank you for taking the time to talk with me today before we start. I would

00:00:09 
 like that you know that I would like to recording this interview so I can

00:00:18 
 transcribe it later for my coursework. The you will only be used for this crossword

00:00:29 
 and you are free to refuse stop answering at any time or ask me to delete

00:00:38 
 recording do I have your consent to record these interviews?

00:00:46 
 - Yes, that's fine.

00:00:48 
 - Okay.

00:00:53 
 How do you usually hear about the instructor

00:00:58 
 regular activities at UQ? - Mostly from friends and sometimes from posters on campus.

00:01:02 
 I rarely check the student portal.

00:01:05 
 - Why do you think students sometimes miss this activity? Because the information is

00:01:11 
 scattered and not all students follow the same channels. Would you prefer prefer having one perform with a clear list of the activity and instead of

00:01:29 
 relying on fly or scatter social media posts why definitely it will same time

00:01:40 
 right now I often just give up because I can't find enough details

00:01:46 
 okay what kind of information do you want to see it on activity details page

00:01:53 
 before deciding to join the time location cause if any and whether I need to register in advance. If there was a feature to stay or bookmark activity for later, would you use this? Why or why not?

00:02:17 
 Yes, I would. Sometimes I'm interested in an event, but I forget about later, so bookmarking would help.

00:02:29 
 What kind of reminder would be most helpful for you to avoid forgetting activity?

00:02:40 
 A push notification on my phone, maybe one day before and one hour before the event

00:02:47 
 okay would you trust shot the reviews or rating for other students when

00:02:55 
 designing with readers to

00:03:00 
 attended activity? Yes, I think reviews would help me avoid wasting time on

00:03:06 
 activities that are poorly organized. Okay, on average how many activities do you

00:03:16 
 usually join each semester what stop you from join more? Maybe two to three per semester. I

00:03:27 
 draw more if I had better information and if schedule didn't clash with my

00:03:33 
 lectures. And do you think part four with an activity list, detail page, favorites, and reviews

00:03:45 
 would help solve the main issue of the awareness,

00:03:51 
 decision marking, and participation.

00:03:57 
 - Yeah, for sure.

00:03:58 
 That would make it much easier to know what's going on

00:04:02 
 and to plan ahead.

00:04:06 
 - Okay, thank you for your answer.

00:04:08 
 - Don't worry, mate.



