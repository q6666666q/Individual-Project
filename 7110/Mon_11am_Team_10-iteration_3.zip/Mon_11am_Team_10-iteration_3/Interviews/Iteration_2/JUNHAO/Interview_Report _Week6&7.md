# Iteration 1 Interview Report 

### Introduction

During Iteration 1, our team conducted several student interviews to understand their experiences with extracurricular activities at UQ. We also received structured feedback from our legend, which encouraged us to refine our problem focus and simplify our proposed solution.

### Key Insights from Interviews

From the interviews, it became clear that many students struggle with **finding information**. Some mentioned they only heard about events through friends or social media, which often felt unreliable. Others said they sometimes discovered activities too late, after the registration had closed. A few students added that even if they knew about events, the descriptions were often too short, making it difficult to decide whether the activity was right for them.

Motivation also came up. A number of students explained they would be more likely to attend if they knew their friends were going too. This highlighted the social side of participation, not just the informational side.

### Feedback and Adjustments

The feedback from Iteration 1 suggested that our original scope might have been too broad. Instead of trying to design a platform with many advanced features, we decided to concentrate on **four core functions** that directly address student pain points:

1. **Activity List** – A central hub that brings all events together.
2. **Activity Detail Page** – Clear descriptions with time, location, cost, and requirements.
3. **Favorites/Collection** – A way for students to save interesting events.
4. **Reviews** – Simple feedback from peers to build trust in event quality.

This shift was important because it showed us that even simple tools can have a strong impact if they match real student needs.

### Conclusion

Looking back, Iteration 1 gave us both data and direction. The student interviews showed that scattered information, lack of detail, and weak motivation were the biggest barriers. The feedback pushed us to simplify and prioritize, which made our value proposition more practical and believable. In the next iteration, we will test these refined features and continue to validate whether they actually improve awareness and participation.