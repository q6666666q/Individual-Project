[JUNHAO_11_September_5.mp3](https://uq.sharepoint.com/:u:/t/Section_7560_62502/Ec9HRscz3GJGlWXTxdHX72sBkmGbQTMEx5xbsA2qs0YyAQ?e=F8SPwb)





00:00:00 
 Yeah, go ahead.

00:00:04 
 Hello, thank you for taking the time to talk with me.

00:00:09 
 Talk with me today. Before we start, I'd like to let you know that I would like to record this interview too. I can transcribe it later for my coursework. The recording will only be

00:00:31 
 useful this coursework. You are free to refuse to stop answering at any time or ask me to delete the recording.

00:00:47 
 Do I have your concern to record at these interviews?

00:00:53 
 Yes, that's fine. Please go ahead.

00:00:57 
 Okay.

00:00:58 
 The first question is:

00:01:01 
 How do you usually hear about the instructor

00:01:09 
 and regular activity at UQ?

00:01:18 
 I mostly hear about that through friends in my classroom or students in school.

00:01:30 
 Sometimes I see posters on the campus, but I don't really start to read them.

00:01:38 
 The UQ website also has some events, but I really go there unless someone's best to order it and send me the link.

00:01:53 
 Okay, why do you think students sometimes miss this activity?

00:02:02 
 this activity? I think that's the bigger issue is that there's too many channels.

00:02:10 
 Some information is one Instagram, some on Facebook, some on the reading posters.

00:02:17 
 If you don't follow them, write a code or check in, write a code. or the check-in ride, but you will miss out. For me, I feel like lucky whether I see any event or not.

00:02:37 
 - Okay.

00:02:38 
 Would you prefer having one people with key release

00:02:43 
 or key release of the activity instead or relying on price or scattered social media posts? Why?

00:03:00 
 Actually, right now it's too messy if there was one reliable plan for whether I could see

00:03:09 
 all the upcoming events.

00:03:12 
 I will probably join the mall.

00:03:15 
 I often skip activities not because I don't want to go, but because I'm fired out too late, centralized, this will make it more easy to plan ahead.

00:03:39 
 What kind of information do you want to see on an activity detail page before deciding to join

00:03:53 
 the base like data time and the location in the obvious in the obvious but i will also like to know the course, the target growth, like the international students,

00:04:08 
 first years, or the sport fans,

00:04:11 
 and whether I need to adjust it in advance.

00:04:17 
 Post on the video will also help me understand

00:04:22 
 what the activity feel like.

00:04:24 
 Sometimes the name of the event is too vague,

00:04:29 
 so details are more important.

00:04:36 
 Okay, if there was a feature to state or bookmark activity for later, would you use it while or while on?

00:04:49 
 Yes, for sure I would fancy the sometime interesting, but forget about it. After a few days, if

00:04:59 
 I had a favorite list, I could go back on the Sunday. When I will planning my week and check which events

00:05:10 
 I want to join. Without that, I usually just lose track.

00:05:19 
 Okay, what kind of remind would be most helpful for you to avoid forgetting activities?

00:05:32 
 The push notifications would be the best, but I will want them to be customizable. Maybe one reminder a day before

00:05:48 
 and another hour before.

00:05:52 
 Email and okay. But I get too many already.

00:05:58 
 From the notification field

00:06:00 
 shows more immediately.

00:06:07 
 Would you trust short review to ratings from other students when deciding whether to attend an activity?

00:06:28 
 Yes, especially if the reviewers are short and honest.

00:06:36 
 For example, if people say the event was well, organization, the flow was great, I will trust them. Sometimes even like attractive and the poster, but turn

00:06:55 
 out the disappointing. We will help filter our local quality ones.

00:07:21 
 Okay. On average, how many activities I don't join in more schedule,

00:07:32 
 conflict and lack of information.

00:07:35 
 Sometimes, I only find out about an event after it has already happened.

00:07:44 
 Other times, the time cl with MySQL, leisure,

00:07:48 
 or the part-time work.

00:07:53 

Do you think a platform with an activity

00:07:59 
 is a detailed page, a favorites,

00:08:03 
 and reviews would help solve the main issues of awareness, decision

00:08:13 
 marking, and participation.

00:08:16 
 Yes, I think it would be really helpful to have all the information in one's plan with the awareness problem.

00:08:28 
 Very very reason and reminder,

00:08:32 
 we help with the planning and we will build trust.

00:08:37 
 Honestly, I think if in plan for this,

00:08:43 
 I will probably doubt the number of events

00:08:46 
 at 10 each semester. Yeah.

00:08:51 
 Okay. Thank you for your answer.