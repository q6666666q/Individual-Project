[JUNHAO_11_September_1.mp3](https://uq.sharepoint.com/:u:/t/Section_7560_62502/EWDVvo8olOVBtRofIHP_UKkBPmnKe-Zay7I3nSENTDvxMA?e=aUv2WC)





00:00:00 
 Hello, thank you for taking the time to talk with me today. Before we start, I would like to let you know that I would like to recording these interviews so I can transcribe it later for my course was the recording will only be used for this coursework you can

00:00:26 
 free to refuse stop answering at any time or ask me to delete the recording

00:00:33 
 do I have your concern to record these interviews yes I get my concern to record

00:00:42 
 this interview.

00:00:51 
 Okay, how do you usually hear about the instructor, a regular activity and UQ? I usually hear about the extracurricular activities from social media groups, students, society or postural around campus.

00:01:47 
 Would you prefer having one platform with a clear list of the activity times, and it was confusing. Instead of checking multiple sources, I could quickly approach and choose what interests me, making participation more convenient and consistent overall. What kind of information do you want to see times, location, description, requirements, and organizer

00:02:09 
 context.

00:02:10 
 Clear details help me decide if I can attend photos or short videos, which also make it

00:02:20 
 easier to visualize and generate excitement about activities.

00:02:27 
 If there was a feature to say or bookmark activity for later, would you use it?

00:02:35 
 Why or why not? Yes, I would absolutely use a bookmark or

00:02:41 
 favorite feature. I say when I'm interested in but forget the simulator

00:02:49 
 and being able to save activities means I can revisit the simulator, compare schedules

00:02:56 
 and find missing opportunities on the internet.

00:03:00 
 intentionally. What kind of reminder would be most helpful for you to avoid forgetting activity?

00:03:16 
 Push notifications or calendar signing input work best for me because they are immediate and appear at the right moment.

00:03:30 
 Emails are often overlooked or lost in spam.

00:03:36 
 Timely reminder ensure I don't forget after initially showing interest. Would you trust short reviews or rating from other students

00:03:52 
 when deciding whether to attend an activity? Yes, I would trust with your ratings, especially if they come from fellow students with similar interests.

00:04:11 
 I'm sure general feedback helps me avoid wasting time on low quality events and increases my confidence to join your activities without hesitation.

00:04:27 
 On average, how many activities do you usually join each semester?

00:04:37 
 What stops you from join more? trying more you should have I just pay for activities each semester limited free

00:04:50 
 time assignment deadlines and they call the man

00:04:54 
 results from from join more if information were clear and better or better organized, I would probably attend additional events regularly.

00:05:09 
 Do you think a path forward with an activity list, a detailed page,

00:05:15 
 favorites and reviews would help both the main issues of the awareness,

00:05:22 
 decision marking, and participation station?

00:05:27 
 Yes, I believe a platform can be a piece of detailed pages,

00:05:33 
 favorites and reviews would be very valuable. It addresses awareness by centralized information supports decision making with details and feedback and encourage participation by

00:05:50 
 reminders which significantly improves overall student engagement

00:05:58 
 Okay, thank you for your answer

00:06:00 
 Thank you.