https://uq.sharepoint.com/:u:/t/Section_7560_62502/ESWOMamFQMxCnICMERM30f8BsoA0qc7qRHEG6xy4hAv0Aw?e=X1twOM


00:00:00 
 okay thank you hello thank you for taking time probably today before we start I would like to

00:00:12 
 let you know know that I would like to recording this interview so I can subscribe it later for

00:00:18 
 my coursework the recordings the recording will only be used for this coursework.

00:00:27 
 You can be free to review, stop answering at any time or ask me to delete the recording.

00:00:36 
 Do I have your concern to record these interviews?

00:00:41 
 Yes, of course. Okay, the first question is how do you usually hear about the

00:00:48 
 instructor of UQE activity at UQE? Mostly from friends. Sometimes from a Facebook group or post groups or posters around campus but often I found out too late like after the event already happened.

00:01:12 
 Okay and and did you bring the platform that provides activity this detail page, various and the reviews with all the problems of awareness,

00:01:28 
 decision marking and participation, why or why not?

00:01:36 
 Yes, I think it will help. Having everything in one place makes it easier to plan. Right now, I wasted time checking the resources and still miss out.

00:01:51 
 Review will also help me know which activities are worth it. What do you hope to gain from the participation in the activities, in the structural, curricular activities?

00:02:16 
 If you want to meet new people outside my course and also build some skills, like leadership or communication. It's also nice to relax and do something from

00:02:27 
 besides studies.

00:02:30 
 On average, how many activities do you usually join each semester? What do you stop you from

00:02:41 
 joining more? Usually, I think I want to join more, but sometimes I'm too busy or I just don't know what's happening.

00:02:52 
 And other reason is that I'm not sure if the event is good or if many people will go.

00:03:00 
 Here there been a situation where you want to go, but a decision not to. Can you give me a sample?

00:03:15 
 Yes, a few times last semester I wanted to join a sports event, but I didn't know the exact time and

00:03:23 
 but I didn't know the exact time and pace until last minute, so I didn't go. It felt too uncertain.

00:03:28 
 Okay, and the next part is the part 2.

00:03:34 
 The part 2 first question is: we provide a platform that automatically present and display all ongoing activities

00:03:54 
 do you think this would be would be more convenient that how you can survive the activity

00:04:07 
 why or why not?

00:04:16 
 Definitely more convenient. Right now, I use three or four different apps and chats. Having a single platform will save me time.

00:04:34 
 If you want to find the instructor, regular activities, what type of ways or platform would help you find them quickly? I want to fleet by time and type. For example, I might search for music event this weekend. A keyboard search will also help if I already know the event next.

00:04:51 
 Okay, and if you could it to your characters with one clip within receiving

00:05:12 
 and reminders two hours before it starts would this be useful use and can you give me a sample

00:05:22 
 Can you give me a sample?

00:05:33 
 Yes, I often forget events, especially when I'm busy with assignments. For example, I missed a workshop last semester because I just forgot.

00:05:37 
 A calendar reminder will fix them.

00:06:00 
 okay and when searching for activities would you more often use time showing or popularity showing

00:06:00 
 If there were search options, which one would you use more often?

00:06:10 
 I use sorting most often because I need to fit activities into my schedule.

00:06:19 
 The popularity is also helpful when I just want to join something fun with

00:06:26 
 a lot of people.

00:06:28 
 Okay. If the people around you to read and comment on activities, would you be willing

00:06:42 
 to participate?

00:06:52 
 Yes, it's simple like giving a score or short comment. I'd like to read other students' reviews before deciding.

00:07:12 
 research reviews would help you to decide readers to join an activity?

00:07:19 
 Yeah, that's a good question. For sure, reviews make me more confident if many students say events well nice and enjoyable i join without

00:07:29 
 hesitation

00:07:32 
 okay thank you i thank you for answer

00:07:38 
 okay that's all