https://uq.sharepoint.com/:u:/t/Section_7560_62502/ER6xkm6pN81EgGK4WnF81bMBWKi-KsDbh162TAw9hVjVVA?e=dsHSbV


00:00:00 
 Thank you for taking the time to talk with me today.

00:00:05 
 Before we start, I would like to let you know that I would like to record this interview

00:00:10 
 so I can transcribe it later for my coursework.

00:00:16 
 The recordings will only be used for this coursework.

00:00:21 
 You are free to refuse, stop answering at any time or ask me to delete

00:00:26 
 the recordings. Do I help your concerns to record these interviews?

00:00:36 
 Yes.

00:00:38 
 Okay. The first question is how do you usually hear about the structure of VQlet at UQ?

00:00:51 
 Not only through the emails from the UMI, all the posters around the campus.

00:01:02 
 Some friends told me about something, I think.

00:01:07 
 Okay.

00:01:08 
 Do you think a platform that provides activities is detailed pages, of awareness, decision marking, participation, and why or why not?

00:01:32 
 Yeah, I think it would help a lot because it would make everything easier to find

00:01:41 
 and decide on, you know on without sketching info.

00:01:48 
 And I think it has no downsides really.

00:01:52 
 Okay.

00:01:56 
 What do you hope to get from participating in the instructional activities?

00:02:11 
 I hope to make new friends and build skills like leadership.

00:02:18 
 And sometimes just want to have fun outside class, I think.

00:02:24 
 just want to have fun outside class, I think. Okay, on average, how many activities do you usually join semester?

00:02:32 
 And what usually stops you from joining more?

00:02:38 
 An average is maybe two or three per semester. Because I think sometimes time class with studies and sometimes I'm not knowing about them in time.

00:02:57 
 It will stop me, I think.

00:03:00 
 Okay, okay. And have there been situations where you want to go but decide not to? Can you give me a sample?

00:03:13 
 Yeah. Likewise, I wanted to join on a couple of hikes, but I didn't know if I needed a gel, and it seems to last a minute.

00:03:48 
 automatically collect and display all outgoing activities. Do you think this would be more convenient to help you

00:03:54 
 counter and find activities? Why or why not?

00:04:01 
 I think it's totally more convenient because right now I scroll through random sites and

00:04:09 
 different apps or websites.

00:04:12 
 This would be one point.

00:04:15 
 I think it will save lots of time.

00:04:18 
 Okay. If you want to find structure, reference activities, what kind of way or platform would help you find that quickly?

00:05:10 
 for that and type are even integrated with my calendar so I and add in to your calendar with one click

00:05:21 
 with this receiving and remind two hours before it starts, would this be useful for you? And can you give me an example for this?

00:05:26 
 be useful for you and can you give me a sample for this? Yeah, I think it's super useful. For example,

00:05:30 
 favoriting a workshop and getting a reminder. So I will not forget to

00:05:38 
 meet assignments. Coding media app had a file come.

00:06:00 
 Okay, and when searching for activities, would you more often use the

00:06:00 
 time showing or popularity showing, if there was a search option, which one would you use

00:06:16 
 more often?

00:06:18 
 I'd like to use time sorting more often. From those options, benefit tags would be my topic

00:06:30 
 to match my interests.

00:06:38 
 - Okay.

00:06:39 
 And if the platform allow you to rate and comment on activities, would you be willing to participate?

00:06:59 
 Yeah, I'd like to participate if it's very quick and easy. I will do it.

00:07:07 
 Okay.

00:07:08 
 And do you think such reviews would help you decide whether to join an activity?

00:07:20 
 Yeah, for sure.

00:07:22 
 They'll help me see if it's worth my time.

00:07:26 
 Like awarding boring ones based on real feedback.

00:07:35 
 Okay, thank you for answering.