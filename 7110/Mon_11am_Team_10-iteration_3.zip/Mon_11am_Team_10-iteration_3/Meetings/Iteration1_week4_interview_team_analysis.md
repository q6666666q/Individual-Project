Summary of Wednesday Group Meeting


Awareness
1. Many students do not have a clear concept of extracurricular activities, or their impressions are vague.
2. Students generally rely on multiple channels (college emails, social media, friends, posters) to obtain information, but due to the dispersion of channels, awareness is unstable.
3. Some students said that social media posts are often classified as advertisements, causing some information to be ignored.
4. There is insufficient transparency in information, such as overly brief activity promotions, making it difficult for students to determine whether an activity is suitable for them.

Participation
Overall participation is low, with reasons including:
1. Lack of advance planning, resulting in high randomness in activity participation.
2. Limited time, which sometimes conflicts with course schedules.
3. Some majors have high barriers to entry for activities or clubs, making it difficult for freshmen or inexperienced students to integrate, and even creating a sense of exclusionary cliques.
4. Some school-organised activities have poor experiences, such as a student mentioning that the outdoor activity of petting koalas had excessively long waiting times.
5. Students often learn about and participate in activities passively rather than actively seeking them out.
Despite this, some students have joined clubs or volunteer activities and believe these activities enrich their social lives and provide learning opportunities.

Information Needs
Time and location are the most important factors. Students typically participate in activities during their free time after classes, so activity schedules should not conflict with course schedules, and locations are preferred to be on campus.
Secondly, the type and content of activities matter. If an activity aligns with their interests, students are more likely to participate; even if their interest is moderate, they may still attend if the time and location are convenient.
Additionally, factors such as the organising body, promotional messaging, and atmosphere also influence students' choices.

Satisfaction
Students who have participated in activities generally report high satisfaction, finding them enjoyable and helpful for making friends.
Students prefer interactive activities over one-way lectures or presentations.
Dissatisfaction primarily stems from unclear information, insufficient promotion, and fragmented channels, leading to missed opportunities or poor experiences.


General Future Directions
Information display, interactive functions, satisfaction improvement
