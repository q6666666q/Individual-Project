Team Contract 
 
Team Members: 
Ji Zhang, Zhaoguo Huang, Junhao Liang, Siqi Su, Mingqi Zhang 
 
Core Values & Behaviours 
1. On-time: Arrive on time for meetings and meet all deadlines. 
2. Feedback: Provide regular updates on your own progress and task completion to the team. 
3. Communication: Communicate clearly, simply and regularly using the team channel. 
4. Critical Thinking: Approach problems with critical thinking and discuss solutions logically. 
5. Stay Handle: Stay calm under pressure and handle difficulties professionally. 
6. Keep it simple: Keep solutions and communication as simple as possible. 
7. Collaboration: Collaborate and support each other to achieve team goals. 
8. Learning: Embrace learning and share new knowledge with the team. 
9. Responsibility: Take responsibility for your own tasks and commitments. 
10. Result-driven: Focus on delivering results and strive for high-quality outcomes. 
 
 
Conflict Resolution 
 • Raise issues early and discuss respectfully. 
 • Seek consensus; if unresolved, involve the team legend or TA. 
 
 
Agreement 
All team members agree to follow these principles and review this contract if needed. 
 