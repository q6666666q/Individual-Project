Meeting Notes:
 
Project Directions:

	1.	To-C Market:

	•	Researching To-C (consumer-oriented) products is relatively easier, with clear market demand and customer base.

	2.	Environmental Focus:

	•	Consider developing an information collection and display platform, such as a news/information encyclopedia related to environmental protection.
 
Team Roles and Expertise:

	•Junhao:

			Main responsibility: Development

			Strength: Python

	•Zhaoguo:

			Main responsibility: Product design

			Strength: Visual design, capable of supporting interaction design

	•Ji:

			Main responsibility: Interaction design

			Strengths: Interaction design, able to assist with product support and data analysis

	•Mingqi:

			Main responsibility: Development

			Strengths: C++ (main), Java (secondary); has theoretical knowledge in data analysis and front-end development

	•Shiqi:

			Main responsibility: Attempting the role of product manager for this project

			Strengths: Java development; responsible for product analysis and related tasks
 