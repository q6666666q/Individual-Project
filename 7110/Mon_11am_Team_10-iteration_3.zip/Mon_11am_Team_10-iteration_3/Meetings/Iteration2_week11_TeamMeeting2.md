# Team Meeting Notes

## Week 11 — Development Preparation & Task Distribution

### Meeting Information

Date: 2025/10/13
Participants: Kiki, Jeric Zhang, Junhao, Zhaoguo Huang, Mingqi Zhang

### Agenda

Confirm frontend–backend task distribution and API interface design

Decide development language and framework (Python-based backend)

Plan database and framework setup timeline

Assign presentation sections and responsibilities

Finalize Git usage rules (branch structure)

### Discussion Summary
**1. Frontend-Backend Function Distribution & API Design**

Part 1: Shiqi, Zhaoguo

Part 2: Junhao, Jeric

Part 3: Mingqi, Zhaoguo(Bookmark and Personal Center modules), Jeric(Activity Detail Page, Notifications)

API testing: Mingqi will use Postman for validation.


**2. Development Language & Framework Selection**

Team decided to use Python-based framework for backend (shared environment).

Database design: Junhao — complete database schema by Friday, Oct 17.

Framework setup: Shiqi - complete by Sunday, Oct 19.

API integration testing: mingqi(postman).


**3. Pitch Presentation Distribution**

Elevator Pitch (1 min): Shiqi - The target group is investors.

Project Overview (1 min): Jeric - Introduce the platform’s main concept.

Customer Problem (1 min): Junhao - Summarize user pain points and insights.

Solution (2 min, two speakers): Zhaoguo - Differentiation & advantages.

Future Plans: Mingqi - Future vision and development outlook.


**4. Git Usage Guidelines**

Team agreed to use branch-based workflow for code collaboration.

Each member will maintain separate branches and follow the shared merge protocol.