# Interview Questions

# Value Proposition
1. Awareness
- How do you usually hear about extracurricular activities at UQ?

2. Value Proposition Validation
- Do you think a platform that provides activity lists, detail pages, favorites, and reviews would solve the problems of awareness, decision-making, and participation? Why or why not?

3. Expected Gains （New）
- What do you hope to gain from participating in extracurricular activities?

4. Engagement
- On average, how many activities do you usually join each semester? What usually stops you from joining more?

5. Barriers （New）
- Have there been situations where you wanted to go but finally decided not to? Can you tell us your experiences?


# MVP features
- If we provide a platform that automatically collects and displays all ongoing activities (with time, location, requirements, etc.), do you think this would be more convenient than how you currently find activities? Why or why not?


- What do you think of a platform that have a list of activities (with detailed information like time, location, requirements, etc.)?

- What do you think about a feature that lets you ‘favorite’ an activity and add it to your calendar instantly?

- When searching for activities, what kind of sortings would you like to use? (time sorting, popularity sorting...)?

- If the platform allowed you to rate and comment on activities, would you be willing to participate? And could you tell me the reason?

- Okay, and would you trust the short reviews or or ratings from other students were when deciding whether to attend an activity? Could you tell me the reason?