# **Hypotheses**


### **Hypothese1: Awareness**

We believe that after using the platform for **one semester**, at least **70% of users** will be able to correctly list **more than 5 extracurricular activities** at UQ.


### **Hypothese2: Participation**

We believe that after using the platform for **one semester**, at least **60% of active users** will: 

1. Visit more than **5 different activity pages**  

2. Bookmark at least **2 activities**  

3. Click through to the official UQ system at least once.


### **Hypothese3 – Satisfaction**

We believe that after **one semester**, at least **70% of users** will give a score of **7 or above (out of 10)** in the satisfaction survey for the platform.  



 