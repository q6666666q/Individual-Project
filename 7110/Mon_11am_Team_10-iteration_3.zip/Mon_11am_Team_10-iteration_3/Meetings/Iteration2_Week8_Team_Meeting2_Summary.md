# Team Meeting2 Summary

**Week:** 8
**Meeting Focus:** Conduct a review of the low-fidelity prototype, discuss the work for Iteration 2, and confirm the future work plan.

------

### Key Discussion Points

1. **Homepage**
   - **Participants Number**: Delete "Participants Number".
   - **Filters**: Add filters below the "Upcoming Activities".
   - **Labels**: Label type will be confirmed later.

2. **Login/Sign up**
   - **Error Information**: Do not need to be too complicated, just basic type is enough.

3. **Detail Page**
   - **Specific Information**: Will be confirmed in future work.
   - **Bookmark**: Add the number of bookmark.
   - **Organizer**: Add comments (with detal page entrance) below the rating.

4. **Rating**
   - **Give a rating**: Add cooments section.

------

### Task Timeline (Week 9)

- **Monday, Sept 22**
  - Jeric: Update low-fidelity prototype to V1.1
  - Zhaoguo: Start visual design
  - Shiqi: Update MVP document.
  - Junhao/Mingqi: Start database design.
- **Tuesday, Sept 23**
  - Complete all Iteration 2 tasks and tag them in Tuesday evening.