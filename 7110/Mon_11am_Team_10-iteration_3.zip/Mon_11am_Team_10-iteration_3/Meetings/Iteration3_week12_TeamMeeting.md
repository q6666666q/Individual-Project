## **When & Purpose**

- When: Week 12 studio meeting
- Purpose: lock tech stack and MVP scope; confirm ownership and milestones; standardize styles and repo layout; schedule user interviews

## Key Decisions

- **Tech & Scope**: pure **HTML/CSS/JavaScript static pages**; no backend; must run locally for demos.
- **MVP cuts**:
  - List page removes non-essential top sections, keeps search/filter and cards only.
  - List is split into **“Upcoming/Ongoing”** and **“Finished”**.
  - **10 detail pages** using one shared template with different data.
- **Interaction simulation (no backend)**:
  - Keep Login; Registration as optional placeholder link.
  - Bookmarks and “Add to Calendar” use **localStorage + click-to-toggle + toast feedback**.
- **Style system**: **Zhaoguo** provides color/typography/spacing and button/card/toast components and base stylesheet.
- **Milestones**: individual tasks **due 10/31**; **11/1–11/2** reserved for merge, integration, and team QA.
- **User interviews**: **2 per member** on prototype usability & improvements, **due 10/31**.

## Ownership & Deadlines

- **Project skeleton**: Jeric — directory structure and HTML templates (immediate).
- **Base styles + Feedback modal**: Zhaoguo — style baseline by **10/24 AM**; feedback modal by **10/31** (0.5 FTE).
- **List + fuzzy search (2 pages)**: Junhao — by **10/31** (with section split and keyword search).
- **Login/Registration (placeholder) + Bookmarks page**: Mingqi — by **10/31** (bookmark state synced locally).
- **10 detail pages** (bookmark linkage / registration jump / calendar toast): Jeric & Kiki — by **10/31**.
- **Interview kit**: Junhao consolidates the question set; all members complete 2 interviews each by **10/31**.

## Risks & Mitigations

1. **Style inconsistency** → shared tokens/components; pre-merge self-check; style review by Zhaoguo.
2. **Fragile mock interactions** → one protocol: toggle on click + toast + localStorage; add a “reset data” button.
3. **Insufficient data for search demo** → ≥10 details; list covers different time states.
4. **Tight integration window** → reserve 11/1–11/2; maintain a merge checklist (paths, naming, assets, responsive widths).

## Next Actions

- Jeric: push skeleton and `/product/week12-prototype` 2.
- Zhaoguo: publish style guide (palette, type scale, card/button/toast); scaffold feedback modal.
- Junhao: implement list + fuzzy search with “Upcoming/Ongoing vs Finished” sections.
- Mingqi: implement Login; Registration placeholder; Bookmarks page with local state sync.
- Jeric & Kiki: complete 10 detail pages and verify interaction linkage.
- All: finish 2 interviews per member, consolidate findings over the weekend.

## Definition of Done (DoD)

- All pages **run locally**, core interactions work; styles follow team guide.

- List supports **keyword fuzzy search**; bookmark state **syncs** between list and detail.

- Login is functional (Registration can be placeholder); feedback modal opens/submits (local only).

  ​