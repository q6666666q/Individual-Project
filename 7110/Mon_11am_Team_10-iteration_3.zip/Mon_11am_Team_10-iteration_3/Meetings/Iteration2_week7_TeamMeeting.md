# Team Meeting Notes
Week 7 – Project Sync & Interview Insights

## Meeting Information

Date: 2025/09/12

Participants: JUNHAO, Shiqi Su, Jeric Zhang(Ji Zhang), Zhaoguo Huang, Mingqi Zhang

## Agenda

Review interview findings (Iteration 2)

Confirm MVP scope & feature priorities

Align roles, deliverables, and timeline (prototype, DB, review)

Confirm next meeting & action items

## Discussion Summary
# 1. Interview Review (Iteration 2)

Discovery channels: Posters, classmates and friends, social media, Tiktok/UQU site/WeChat, occasional emails → information is fragmented.

Participation barriers: Heavy coursework/time conflicts, incomplete information (hard to plan), social anxiety, dislike of crowded events(has some bad experiences).

Decision factors: Time, location, free or not, description of the content, organizer, type, suitability (newcomers/friends), expected takeaways.

Reminders: Prefer mobile push & calendar sync; email not preferred (too noisy).

Trust signals: A lot of students strongly rely Peer/student reviews to make decisions.

Behavior: Most attend ≤2 activities/semester; some prefer serendipitous discovery via social media—platform must balance discovery + search.

# 2. MVP Scope (Prioritized)

Activity List with Filters/Search (central hub)

Activity Details (time, location, fees, organizer, suitability, brief content)

Favorites/Bookmarks (keep even if some users screenshot)

Reminders (push & calendar; email optional/non-priority)

Reviews & Ratings (campus peer reviews)

Note: Include reminders in docs; implement if feasible. If not, record trade-offs to avoid “do-everything” claims.

# 3. Roles & Collaboration

Prototype & Interaction: Jeric (Ji Zhang) (interaction first; visuals ~+2 days after)

Visual Design: Zhaoguo (based on interaction output)

Product Docs: Completed by team lead

Database Design: JUNHAO drafts v1 (ER/schema/key fields: favorites, reminders, reviews minimal model)

Front/Back Integration Support: JUNHAO + Shiqi (mentor newcomers; define API & data contracts)

Process: Collaborate in Figma; in the project board each member creates own tasks with clear, testable acceptance notes.

# 4. Timeline & Meetings

By Fri (this week): Target interaction prototype completion (visuals follow ~2 days).

Next Tue (evening): Review meeting (present a dev-ready first draft; fine details can iterate).

Deliverable check: Verify whether there’s a Sept 25 milestone and its scope.

## Outcomes

Agreed on the MVP feature set and priorities.

Confirmed DB-first to support integration; prototypes delivered at a developer-readable depth.

The project board is the single source of truth, emphasizing task clarity and visible contributions.

Action Items

## All members:

Work within the MVP scope; create and refine your own board tasks (with acceptance criteria).

JUNHAO:

Submit DB v1 (ER diagram + schemas + key fields + brief data dictionary) and start the review thread.

Zhaoguo & Jeric:

Jeric finish interaction prototype by Fri; Zhaoguo to deliver first visual pass within ~2 days after.

Shiqi & JUNHAO:

Run DB review; publish change log and next steps; draft initial API contract.

Team:

Attend next Tue review; pre-submit 1–2 key risks/questions and needed support.
