# **Meeting Summary **

**Topic**: Check Iteration 2 submission and confirm if anything is missing
**Time**: 24/09/2025,8:00pm
**Participants**: All team members

### Discussion Points

1. **Files and Structure Check**
   - Business Model Canvas (BMC), Value Proposition Canvas (VPC), Test Cards, and Learning Cards have been completed.
   - Decision to consolidate Test Cards and Learning Cards into dedicated folders for clarity.
   - Confirmed MVP document should be placed in both `Documents` and `Prototype` folders to avoid missing items.
2. **Submission and Git Operations**
   - One member will tag the repository with `iteration_2` in GitHub.
   - Reminder: submission must include the `.git` folder, so the repository should be packaged locally instead of downloading GitHub zip.
3. **Task Allocation and Completion**
   - Junhao: Updated BMC and reviewed hypotheses (accepted/refuted).
   - Shiqi: MVP document and hypotheses.
   - Mingqi: Test Cards and Learning Cards, also responsible for integration.
   - Ji Zhang: Competitor analysis.
   - Zhaoguo: Validation questions and prototype-related tasks.
4. **Notes**
   - No Chinese text should appear in the submitted materials; all files must be checked and cleaned before submission.

### Conclusion

Most Iteration 2 work has been completed, with only integration and checking left. Before submission, the team must confirm:

- Test Cards and Learning Cards are fully organized;
- `iteration_2` tag is correctly added;
- All Chinese text is removed;
- Submission zip file includes the `.git` folder.