# Team Meeting Notes  
**Week 6 – Interview Review and Optimization**  

## Meeting Information  
- **Date:** 2025/09/02 
- **Participants:** JUNHAO, Shiqi Su, JI Zhang, Zhaoguo Huang, Mingqi Zhang    

---

## Agenda  
1. Review of previous interview results  
2. Identify gaps and redundancies in questions  
3. Optimize interview script for clarity and logical flow  
4. Confirm next steps  

---

## Discussion Summary  

### 1. Review of Previous Interviews  
- Team reviewed the transcripts collected in iteration 1.  
- Main issues identified:  
  - Some questions were repetitive (e.g., participation barriers and social motivation).  
  - Some questions overlapped in meaning, which caused confusion during interviews.  
  - Value proposition validation question needed refinement to align with the latest assumptions.  

### 2. Optimization of Interview Script  
- Removed the following questions:  
  - **Participation Barriers:** "What were the main reasons you didn’t join any activities?"  
  - **Social Motivation:** "Would knowing friends also joined make you more likely to join?"  

- Adjusted the **Value Proposition Validation** question:  
  - Previous: "Would a platform with activity hub, detail pages, and reminders solve the issues?"  
  - Updated: "Would a platform with an **activity list, detail pages, favorites, and reviews** help solve the main issues of awareness, decision-making, and participation?"  

- Finalized **8-question script** in logical flow:  
  1. Awareness (how students hear about activities)  
  2. Centralization (preference for an activity list)  
  3. Detail page information needs  
  4. Activity collection (favorites)  
  5. Reminder preferences  
  6. Feedback & trust in reviews  
  7. Engagement level (number of activities per semester)  
  8. Value proposition validation (updated version)  

### 3. Outcomes  
- Agreed that the updated script is clearer, avoids overlap, and better supports hypothesis testing.  
- The optimized flow makes interviews smoother and ensures all questions directly connect to the research goals.  

---

## Action Items  
- **All members:** Use the new 8-question script for future interviews.  
- **JUNHAO:** Upload the updated script to GitHub repository under `/Interviews/`.  
- **Shiqi:** Cross-check consistency with test cards and learning cards.  
- **Team:** Collect at least 2–3 more interviews each using the updated script before next meeting.  

---

##  Next Meeting  
- Review new interviews conducted with the optimized script.  
- Begin mapping answers to test cards and learning cards.  
- Brainstorm potential prototype features based on collected insights.  
