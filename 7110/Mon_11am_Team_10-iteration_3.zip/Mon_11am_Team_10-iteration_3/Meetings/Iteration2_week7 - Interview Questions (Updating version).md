**Introduction**
Hello, thank you for taking the time to talk with me today. We are currently doing a survey about extracurricular activities at UQ, can I ask you some small questions?
Before we start, I’d like to let you know that I would like to record this interview so I can transcribe it later for my coursework. The recording will only be used for this purpose. You are free to refuse, stop answering at any time, or ask me to delete the recording.
Do I have your consent to record this interview?

------

### Interview Questions

1. **Awareness**
   - How do you usually hear about extracurricular activities at UQ?
   If interviewees mentioned that they do not hear about extracurricular activities very often, then ask:
   - Could you tell me the reason why you sometimes miss these activities?
2. **Centralization (Activity List)**
   - Would you prefer having one platform with a list of activities, or some posts, or news in social media? And Why?
3. **Detail Page**
   - What kind of information do you want to see on an activity detail page before deciding to join?
4. **Collection (Bookmark/Favorite)**
   - If there was a feature to save or bookmark activities for later, would you use it? Why or why not?
5. **Reminders**
   - What kind of reminder would be most helpful for you (push notification, email, calendar sync) to avoid forgetting activities?
6. **Feedback & Trust**
   - Would you trust short reviews or ratings from other students when deciding whether to attend an activity?
7. **Engagement**
   - On average, how many activities do you usually join each semester? What stops you from joining more?
8. **Value Proposition Validation**
   - Do you think a platform with an **activity list, detail pages, favorites, and reviews** would help solve the main issues of awareness, decision-making, and participation?