# Meeting Minutes

**Meeting Topic**: Assignment submission time, format, and task allocation

**Participants**:

- JUNHAO
- Shiqi Su
- JI Zhang
- Zhaoguo Huang
- Mingqi Zhang



## 1. Meeting Time and Attendance

- Attendance: Everyone has participated.



## 2. Assignment Progress and Deadline

- Progress:
  - JUNHAO reported the progress of the Week 5 team tasks.
- Deadline Confirmation:
  - SHIQI mentioned the assignment deadline is September 4.
  - JUNHAO reconfirmed the specific tasks and deadlines.
- Submission Content and Method:
  - SHIQI and Zhaoguo Huang discussed the submission content, confirming that a compressed file is required.



## 3. Assignment Content and Specific Requirements

- Content:
  - SHIQI mentioned the assignment includes recordings and interviews.
  - Zhaoguo Huang added details about specific files.
- Format and Naming:
  - JI Zhang and SHIQI discussed naming conventions.
  - JUNHAO suggested modifying according to assessment requirements.
- Submission and Review Process:
  - The group confirmed assignments must be submitted completely.
  - JUNHAO will be responsible for the final submission and review.



## 4. Follow-up Arrangements and Task Allocation

- Time Arrangement:
  - SHIQI suggested finishing tasks earlier to avoid delays, with an internal deadline set for Friday noon.
  - JUNHAO suggested finishing final tasks on Thursday and Friday to ensure correctness.
- Task Allocation:
  - JI Zhang and Zhaoguo Huang confirmed their responsibilities, including recording and file uploads.
- Problem Handling:
  - JUNHAO suggested solving issues promptly to ensure on-time submission.



## 5. Grading Standards and Notes

- Grading:
  - JUNHAO shared the grading standards, emphasizing they must meet “investor requirements.”
  - He reminded the team to avoid being too casual and to ensure the quality meets assessment expectations.