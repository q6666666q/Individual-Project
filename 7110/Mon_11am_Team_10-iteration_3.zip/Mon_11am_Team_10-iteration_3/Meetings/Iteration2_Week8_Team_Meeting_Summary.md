# Team Meeting Summary

**Week:** 8
**Meeting Focus:** Task distribution for Iteration 2 and scheduling for next week’s in-person development planning.

------

### Key Discussion Points

1. **Task Assignments**
   - **MVP Document & Hypotheses**: Completed by **Shiqi**.
   - **Test Cards & Learning Cards**: To be created by **Mingqi**, based on 12 hypotheses from Week 8 (Deadline: **Friday, Sept 19**).
   - **Business Model Canvas**: To be completed by **Junhao**, covering customer segments, value propositions, channels, and customer relationships. Must include accepted and refuted hypotheses (Hypotheses 1 and 7 are refuted). Should be supported by interview data. (Deadline: **Wednesday, Sept 17**).
   - **Validation Questions**: To be prepared by **Zhaoguo**, linking MVP and value proposition hypotheses to interview questions. (Deadline: **Wednesday, Sept 17**).
   - **Competitor Analysis**: To be done by **Ji Zhang**, in table form (4–6 competitors, including target market, value propositions, weaknesses, and notes). (Deadline: **Friday, Sept 19**).
2. **Agreements**
   - Interview questions must avoid yes/no or biased phrasing.
   - Hypotheses and canvases must link back to interviews and feedback.
   - All tasks should be documented and tracked in the **Github Project board**.
3. **Next Step**
   - **Sunday, Sept 21**: On-campus meeting to divide software development tasks and plan feature implementation.

------

### Task Timeline (Week 8)

- **Wednesday, Sept 17**
  - Junhao: Business Model Canvas update.
  - Zhaoguo: Validation questions for MVP and Value Proposition.
- **Friday, Sept 19**
  - Mingqi: Test Cards and Learning Cards (12 hypotheses).
  - Ji Zhang: Competitor analysis (4–6 competitors).
- **Sunday, Sept 21**
  - All members: In-person meeting at UQ to plan development roles and responsibilities.