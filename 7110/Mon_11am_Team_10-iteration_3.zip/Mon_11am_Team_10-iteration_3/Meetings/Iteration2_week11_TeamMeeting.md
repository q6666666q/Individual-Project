# Team Meeting Notes

## Week 11 – Iteration 3 Task Distribution and Revision Planning

### Meeting Information

Date: 2025/10/06
Participants: Kiki, Jeric, Junhao, Zhaoguo Huang, Mingqi Zhang

### Agenda

Review professor feedback on test cards and learning cards

Assign revision tasks for iteration 3 deliverables

Confirm update schedule and submission timeline

Plan integration and next in-person meeting

### Discussion Summary
**1. Feedback Review**

The team discussed the professor’s feedback, which emphasized:

Tests must be short-cycle and executable (3–5 minute prototype sessions).

Each hypothesis should address one clear behavior and have quantifiable results (N, %).

Learning cards should state Accepted / Rejected / Needs Revision conclusions.

Competitor analysis and business documents must show clear data linkage to user insights and prototype validation.

**2. Task Distribution for Iteration 3**

Each member received targeted revisions based on their prior work and strengths.

shiqi

Update the Requirement Document to align with current MVP focus and validated hypotheses.

Refine the Hypothesis Section to ensure measurable and single-behavior statements.

Expand the Competitor Analysis Report with evidence-based findings.

Create the H9 Test & Learning Cards focusing on user satisfaction and continued engagement.

Jeric

Update Prototype Interaction Diagrams to reflect refined features (bookmarking, reminders, clearer tags).

Revise Competitor Analysis Report focusing on interaction design and user experience benchmarking.

Develop H8 Test & Learning Cards for usability testing and engagement feedback.

Junhao

Update the Business Model Canvas reflecting the latest MVP iteration and validated user data.

Revise Competitor Analysis Report focusing on cost structure and partnership opportunities.

Prepare H4–H5 Test & Learning Cards for participation and satisfaction-related hypotheses.

Zhaoguo

Refine the Value Proposition Canvas, linking user pains/gains directly to hypothesis insights.

Update Competitor Analysis Report with value differentiation mapping.

Prepare H6–H7 Test & Learning Cards focusing on motivation and value alignment.

Mingqi

Document this meeting as official Meeting Minutes.

Ensure Competitor Analysis Report format consistency across contributors.

Finalize H1–H3 Test & Learning Cards (awareness and participation hypotheses).

**3. Agreements**

All test and learning cards must include:

Sample size (N) and percentage (%) data

Decision outcome: Accepted / Rejected / Revision Needed

Competitor analysis sections must integrate both qualitative and quantitative comparisons.

Each deliverable must be uploaded to GitHub Project Board under the label Iteration_3.

All sections will be reviewed collectively before integration into the final submission package.

**4. Outcomes**

Clear distribution of tasks ensures balanced workload and accountability.

The team agreed on strict submission deadlines to keep the iteration on track.

Members will prepare supporting visuals (e.g., updated canvases and prototype flows) for next presentation.

### Action Items

shiqi: Requirement Document, Hypothesis Update, Competitor Report, H9 Cards

Jeric: Prototype Diagrams, Competitor Report, H8 Cards

Junhao: Business Model Canvas, Competitor Report, H4–H5 Cards

Zhaoguo: Value Proposition Canvas, Competitor Report, H6–H7 Cards

Mingqi: Meeting Minutes, Competitor Report, H1–H3 Cards

Deadline: Friday, October 9, 2025
