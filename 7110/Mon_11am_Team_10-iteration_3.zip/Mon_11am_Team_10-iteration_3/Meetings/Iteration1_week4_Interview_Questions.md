# **Interview Questions**


### **Question Part1**

Have you heard about any extracurricular activities at UQ?


### **Question Part2**

Depending on the previous answers, choose 1-2 questions to ask: 

1. Where do you usually get information about these activities?

2. If you want to join any activities in the future, where would you like to get information?


### **Question Part3**

Depending on the previous answers, choose 1-2 questions to ask: 

1. In the past semesters, did you join any activities? If yes, could you tell me some details?

2. Could you tell me why you didn’t join any activities? 


### **Question Part4**

Depending on the previous answers, choose 1-2 questions to ask: 

1. When you search for activities to participate in, what information do you pay attention to?

2. If you want to search for activities to participate in, what information do you pay attention to?


### **Question Part5**

Depending on the previous answers, choose 1-2 questions to ask: 

1. Overall, how satisfied are you with activities you attend?

2. If you attend an activity, what kind of characteristics may satisfy you?