# Mon_11am_Team_10



JUNHAO LIANG   49034004 TEAM 10   q66666666q   junhao.liang@student.uq.edu.au


JERIC ZHANG(JI ZHANG)   49554799  TEAM10  Jericcccc  ji.zhang4@student.uq.edu.au


Zhaoguo Huang   49122518   TEAM10   ffa8a   zhaoguo.huang@student.uq.edu.au

Shiqi Su    48771058    TEAM 10    qinghuai999    shiqi.su@student.uq.edu.au

MingQi Zhang 48983235  TEAM 10
Mingqi-lab
mingqi.zhang2@student.uq.edu.au
