# BestTech Student Activity Aggregation Platform — Functional Specification Document



Part 1
## 1. User Registration & Login

### 1.1 Registration done
**Fields:** Nickname, Student ID, Password, Email  

**Validation Rules:**
1. **Nickname:** Cannot contain special characters  
2. **Student ID:** Must be unique, cannot be duplicated  
3. **Password:** Minimum 8 characters, must contain both letters and numbers  
4. **Email:** Must follow proper email format and be restricted to the `@student.uq.edu.au` domain  

### 1.2 Login done
- **Login Method:** Student ID + Password  
- **Forgot Password:** Password recovery through verified email  

---

## 2. Feedback & Rating

### 2.1 Trigger Mechanism
- When an activity receives **more than 3 bookmarks**, a feedback pop-up is triggered  
- Each user will only see this pop-up **once**, and it will **not appear repeatedly**  

### 2.2 Feedback Content
- **Platform satisfaction rating:** Scale from 1 to 10  
- **Optional:** Written feedback or suggestions  

---


Part 2
## 3. Activity List

### 3.1 Activity Data
- **15–20 sample activities** will be manually added to the database for testing the filtering and browsing functions  

### 3.2 Display Layout
- The page is divided into:  
  - **Upcoming Activities** (ongoing or not yet started)  
  - **Past Activities** (already ended)  

**Sorting Options:**
- **Default:** Sort by event date (descending)  
- **Popularity:** Sort by bookmark count (descending)  

---

## 4. Search & Filter Function

Users can search and filter activities based on:
1. **Activity Time**  
2. **Benefit Tags** (e.g., Social, Career Development, Life Skills) — predefined by the backend  
3. **Eligibility** (Member, Student, Staff, Public) — defined by the backend  
4. **Keyword Search:** Title or organizer (supports fuzzy matching)  

---
Part 3
## 5. Activity Detail Page

### 5.1 Information Displayed
- **Title**  
- **Join Now** button: Redirects to the official activity webpage  
  - If the event hasn’t started, display **Register Now** and provide **Add to Calendar** function (with 24-hour reminder)  
- **Event Time**  
- **Location:** Physical address or online link  
- **Benefit Tags:** Social, Skill, Career, Wellbeing  
- **Eligibility:** Member, Student, Staff, Public  
- **Level:** Beginner Friendly / Advanced  
- **Fee:** Free / Specified amount  
- **Description:** Detailed introduction of the activity  

### 5.2 Bookmark
- Users can **bookmark** activities, limited to **one bookmark per user per activity**  
- Clicking again **removes** the bookmark  

### 5.3 Notifications
- **Add to Calendar Reminder:**  
  - When users click the button, a confirmation pop-up appears  
  - After confirmation, the event is saved to the user’s calendar with title, start time, and location  
  - A **reminder notification is sent 24 hours before the event**  

