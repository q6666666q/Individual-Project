// js/login.js
// Fake account list: you can add more
const fakeAccounts = [
  { email: "test1@student.uq.edu.au", password: "12345678" },
  { email: "jeric@student.uq.edu.au", password: "password123" },
  { email: "junhao@student.uq.edu.au", password: "abc12345" }
];

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const emailInput = document.getElementById("login-email");
  const passwordInput = document.getElementById("login-password");
  const errorBox = document.getElementById("loginError");

  if (!form) return; // Defensive: exit if no form on page

  form.addEventListener("submit", (e) => {
    e.preventDefault(); // Prevent default form submission to refresh page

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    const matched = fakeAccounts.find(
      (acc) => acc.email === email && acc.password === password
    );

    if (matched) {
      // ✅ Login successful: set login status
      localStorage.setItem("isLoggedIn", "1");
      
      // Check if there's a return URL (caused by clicking favorite when not logged in)
      const returnUrl = localStorage.getItem("returnUrl");
      const shouldAutoFavorite = localStorage.getItem("shouldAutoFavorite") === "true";
      
      if (returnUrl) {
        // If there's a return URL, redirect back to original page
        localStorage.removeItem("returnUrl");
        localStorage.removeItem("shouldAutoFavorite");
        // If auto-favorite is needed, add parameter
        const separator = returnUrl.includes('?') ? '&' : '?';
        const targetUrl = shouldAutoFavorite 
          ? `${returnUrl}${separator}autoFavorite=true` 
          : returnUrl;
        window.location.href = targetUrl;
      } else {
        // Otherwise redirect to logged-in page
        window.location.href = "index_loggedin.html";
      }
    } else {
      // ❌ Login failed: show red error bar
      errorBox.textContent = "Invalid email or password";
      errorBox.classList.add("-show");
    }
  });
});
