// Handle back button: Set return link based on URL parameters
const backButton = document.getElementById('backButton');
if (backButton) {
    const urlParams = new URLSearchParams(window.location.search);
    let from = urlParams.get('from');
    
    // Check if there's an autoFavorite parameter (indicates redirect from login page)
    const autoFavorite = urlParams.get('autoFavorite') === 'true';
    
    // If there's no from parameter, try to determine source from referrer (fallback)
    if (!from && document.referrer) {
        try {
            const referrer = new URL(document.referrer);
            const referrerPath = referrer.pathname;
            if (referrerPath.includes('index_loggedin.html')) {
                from = 'index_loggedin';
            } else if (referrerPath.includes('search.html')) {
                from = 'search';
            } else if (referrerPath.includes('favorites.html')) {
                from = 'favorites';
            } else if (referrerPath.includes('index.html')) {
                from = 'index';
            }
        } catch (e) {
            // If referrer is not a valid URL, ignore error
        }
    }
    
    // Only force to index_loggedin when redirecting from login page (has autoFavorite parameter)
    // This ensures that after login, the back button points to the logged-in list page
    if (autoFavorite) {
        const isLoggedIn = localStorage.getItem('isLoggedIn') === '1';
        if (isLoggedIn) {
            // If redirecting from login page and user is logged in, force return to logged-in list page
            from = 'index_loggedin';
        }
    }
    
    // Set return link based on source
    // from=index -> return to list page (index.html)
    // from=search -> return to search page (search.html)
    // from=favorites -> return to favorites page (favorites.html, to be implemented)
    // from=index_loggedin -> return to logged-in list page (index_loggedin.html)
    // Default: return to list page (index.html)
    if (from === 'favorites') {
        backButton.href = 'favorites.html'; // Favorites page, to be implemented
    } else if (from === 'search') {
        backButton.href = 'search.html'; // Return to search page
    } else if (from === 'index_loggedin') {
        backButton.href = 'index_loggedin.html'; // Return to logged-in list page
    } else {
        backButton.href = 'index.html'; // Default: return to list page
    }
}

// Favorites feature: Extract activity data from detail page and save to localStorage
const favoriteBtn = document.getElementById('favoriteBtn');
const starIcon = favoriteBtn ? favoriteBtn.querySelector('.icon-img') : null;
const favoriteCount = document.getElementById('favoriteCount');


// Get current detail page filename as activity ID (e.g., activity_detail_6.html)
function getCurrentActivityId() {
    const path = window.location.pathname;
    const filename = path.split('/').pop() || 'activity_detail_1.html';
    return filename;
}

// Extract activity data from detail page
function extractActivityData() {
    const title = document.querySelector('.detail-header h1')?.textContent?.trim() || '';
    const heroImg = document.querySelector('.hero-img');
    // Get image relative path (extract from src)
    let imgSrc = heroImg?.getAttribute('src') || '';
    // If src is an absolute path (contains http:// or https:// or file://), extract relative path part
    if (imgSrc.startsWith('http://') || imgSrc.startsWith('https://') || imgSrc.startsWith('file://')) {
        // Extract pathname part
        try {
            const url = new URL(imgSrc);
            const pathname = url.pathname;
            // Find assets position in path
            const assetsIndex = pathname.indexOf('/assets');
            if (assetsIndex !== -1) {
                imgSrc = pathname.substring(assetsIndex + 1); // Remove leading '/'
            }
        } catch (e) {
            // If not a valid URL, try manual extraction
            const assetsIndex = imgSrc.indexOf('/assets');
            if (assetsIndex !== -1) {
                imgSrc = imgSrc.substring(assetsIndex + 1);
            }
        }
    }
    // If already a relative path, ensure it starts with assets
    if (!imgSrc.startsWith('assets/') && imgSrc.startsWith('assets')) {
        imgSrc = imgSrc;
    }
    const imgAlt = heroImg?.alt || '';
    
    // Extract type and charge tags
    const tags = document.querySelectorAll('.detail-tags .tag');
    let typeTag = '';
    let chargeTag = '';
    tags.forEach(tag => {
        if (tag.classList.contains('purple')) {
            typeTag = tag.textContent.trim();
        } else if (tag.classList.contains('yellow')) {
            chargeTag = tag.textContent.trim();
        }
    });
    
    // Extract time information (first info-item usually contains time)
    const timeInfoItem = document.querySelector('.info-item');
    let time = '';
    if (timeInfoItem) {
        const timeText = timeInfoItem.querySelector('.info-text')?.textContent || '';
        // Remove "Add to calendar" link text, keep only time
        time = timeText.replace(/Add to calendar/gi, '').trim();
        // Remove extra whitespace
        time = time.replace(/\s+/g, ' ').trim();
    }
    
    // Extract location information
    const locationItems = document.querySelectorAll('.info-item');
    let location = '';
    locationItems.forEach(item => {
        const icon = item.querySelector('.location-icon');
        if (icon) {
            const locationTexts = item.querySelectorAll('.info-text div');
            const locationParts = Array.from(locationTexts).map(div => div.textContent.trim()).filter(Boolean);
            location = locationParts.join(', ');
        }
    });
    
    // Build description (for list page display, format: time · time range — location)
    // Format time for list page (e.g., Tue 28 Oct 2025 · 1:00–2:30 pm)
    // Detail page format: Tue 28 Oct 2025, 1:00 pm - 2:30 pm
    // List page format: Tue 28 Oct 2025 · 1:00–2:30 pm
    let formattedTime = time;
    if (time.includes(',') && time.includes(' - ')) {
        // Convert "Tue 28 Oct 2025, 1:00 pm - 2:30 pm" to "Tue 28 Oct 2025 · 1:00–2:30 pm"
        formattedTime = time
            .replace(/,/g, ' ·')  // Replace comma with middle dot
            .replace(/\s+-\s+/g, '–')  // Replace " - " with en dash
            .replace(/\s+/g, ' ')  // Normalize whitespace
            .trim();
    }
    // Build description string
    const desc = location ? `${formattedTime} — ${location}` : formattedTime;
    
    // Build detail page link (preserve from parameter)
    const urlParams = new URLSearchParams(window.location.search);
    const from = urlParams.get('from') || 'index';
    const detailLink = `${getCurrentActivityId()}?from=favorites`;
    
    // Extract type for filtering (simplified handling, take first word or full string)
    let type = typeTag;
    if (typeTag.includes(' and ')) {
        type = typeTag.split(' and ')[0];
    }
    
    // Extract campus information (infer from location)
    let campus = 'St Lucia';
    if (location.toLowerCase().includes('online')) {
        campus = 'Online';
    } else if (location.toLowerCase().includes('st lucia')) {
        campus = 'St Lucia';
    }
    
    return {
        id: getCurrentActivityId(),
        title: title,
        imgSrc: imgSrc,
        imgAlt: imgAlt,
        type: type,
        typeTag: typeTag,
        charge: chargeTag,
        desc: desc,
        time: time,
        location: location,
        detailLink: detailLink,
        campus: campus
    };
}

// Get favorites list
function getFavorites() {
    const favoritesStr = localStorage.getItem('favoriteActivities');
    return favoritesStr ? JSON.parse(favoritesStr) : [];
}

// Save favorites list
function saveFavorites(favorites) {
    localStorage.setItem('favoriteActivities', JSON.stringify(favorites));
}

// Check if current activity is favorited
function isActivityFavorited(activityId) {
    const favorites = getFavorites();
    return favorites.some(activity => activity.id === activityId);
}

// Add to favorites
function addToFavorites(activityData) {
    const favorites = getFavorites();
    // Check if already exists
    if (!favorites.some(activity => activity.id === activityData.id)) {
        favorites.push(activityData);
        saveFavorites(favorites);
    }
}

// Remove from favorites
function removeFromFavorites(activityId) {
    const favorites = getFavorites();
    const filtered = favorites.filter(activity => activity.id !== activityId);
    saveFavorites(filtered);
}

// Initialize favorite button state
const activityId = getCurrentActivityId();
let isFavorited = isActivityFavorited(activityId);

// Update button UI
function updateFavoriteButtonUI() {
    if (!starIcon || !favoriteCount) return;

    if (isFavorited) {
        starIcon.src = "assets/icons/activity_detail/bookmark_full.png";
        favoriteCount.textContent = '27';
        favoriteCount.style.color = '#ff6060';
    } else {
        starIcon.src = "assets/icons/activity_detail/bookmark_empty.png";
        favoriteCount.textContent = '26';
        favoriteCount.style.color = '';
    }
}

// Listen for localStorage changes (sync update star icon when adding/removing from favorites page)
window.addEventListener('storage', (event) => {
    if (event.key === 'favoriteActivities') {
        isFavorited = isActivityFavorited(activityId);
        updateFavoriteButtonUI();
    }
});


// Initialize UI
updateFavoriteButtonUI();

// Check if auto-favorite is needed (redirect after successful login)
const urlParams = new URLSearchParams(window.location.search);
const autoFavorite = urlParams.get('autoFavorite') === 'true';
if (autoFavorite && !isFavorited) {
    // Auto-favorite
    const activityData = extractActivityData();
    addToFavorites(activityData);
    isFavorited = true;
    updateFavoriteButtonUI();
    // Remove autoFavorite parameter from URL, but keep from parameter
    const currentParams = new URLSearchParams(window.location.search);
    currentParams.delete('autoFavorite');
    const newSearch = currentParams.toString();
    const newUrl = window.location.pathname + (newSearch ? '?' + newSearch : '');
    window.history.replaceState({}, '', newUrl);
}

// Click favorite button
favoriteBtn.addEventListener('click', () => {
    // Check login status
    const isLoggedIn = localStorage.getItem('isLoggedIn') === '1';
    
    if (!isLoggedIn) {
        // Not logged in: save current page URL, redirect to login page
        const currentUrl = window.location.href;
        localStorage.setItem('returnUrl', currentUrl);
        localStorage.setItem('shouldAutoFavorite', 'true');
        window.location.href = 'login.html';
        return;
    }
    
    const activityData = extractActivityData();
    
    if (isFavorited) {
        // Unfavorite
        removeFromFavorites(activityId);
        isFavorited = false;
    } else {
        // Add to favorites
        addToFavorites(activityData);
        isFavorited = true;
    }
    
    updateFavoriteButtonUI();
});

const btn = document.getElementById('addCalBtn');
const toast = document.getElementById('toast');
let toastTimer = null;

btn.addEventListener('click', (e) => {
    e.preventDefault(); // Only show prompt, no redirect
    showToast('✓ Added to calendar');
});

function showToast(text){
    toast.textContent = text;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, 2000); // Auto-hide after 2 seconds
}

document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('addCalBtn');
    if (!btn) return;

    btn.addEventListener('click', (e) => {
        e.preventDefault();

        // Read activity title (from h1 tag)
        const title = document.querySelector('.detail-header h1').textContent.trim();

        // Read and parse time
        const timeEl = document.querySelector('.clock-icon + .info-text');
        const [dateStr, times] = timeEl.textContent.trim().split(', ');
        const [startT, endT] = times.split(' - ');
        const date = new Date(dateStr);
        const [y, m, d] = [date.getFullYear(), String(date.getMonth()+1).padStart(2,0), String(date.getDate()).padStart(2,0)];

        // Convert start time
        const [sH, sM] = startT.split(' ')[0].split(':').map(Number);
        const startHour = startT.includes('pm') && sH!==12 ? sH+12 : sH;
        const start = `${y}${m}${d}T${String(startHour).padStart(2,0)}${String(sM).padStart(2,0)}00`;

        // Convert end time
        const [eH, eM] = endT.split(' ')[0].split(':').map(Number);
        const endHour = endT.includes('pm') && eH!==12 ? eH+12 : eH;
        const end = `${y}${m}${d}T${String(endHour).padStart(2,0)}${String(eM).padStart(2,0)}00`;

        // Read location
        const location = Array.from(document.querySelectorAll('.location-icon + .info-text div'))
            .map(el => el.textContent).join(', ');

        // Generate ICS
        const uid = `event-${Date.now()}@domain.com`;
        const dtstamp = new Date().toISOString().replace(/[-:\.]/g,'').slice(0,14);
        const ics = `BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
UID:${uid}
DTSTAMP:${dtstamp}
SUMMARY:${title}
DTSTART:${start}
DTEND:${end}
LOCATION:${location}
END:VEVENT
END:VCALENDAR`;

        // Download and show prompt
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([ics], {type: 'text/calendar'}));
        a.download = 'event.ics';
        a.click();
        URL.revokeObjectURL(a.href);
        
        // Show prompt
        const toast = document.getElementById('toast');
        if (toast) {
            toast.style.display = 'block';
            setTimeout(() => toast.style.display = 'none', 3000);
        }
    });
});