document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("regForm");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("reg-name").value.trim();
    const emailPrefix = document.getElementById("reg-email").value.trim();
    const studentNumber = document.getElementById("reg-number").value.trim();
    const password = document.getElementById("reg-password").value;
    const confirmPassword = document.getElementById("reg-password-confirm").value;

    if (!name) return alert("Please enter your name.");
    if (!emailPrefix) return alert("Please enter your email.");
    if (!studentNumber) return alert("Please enter your student number.");
    if (!password || password.length < 8)
      return alert("Password must be at least 8 characters.");
    if (password !== confirmPassword)
      return alert("Passwords do not match.");

    // Simulate successful registration
    const user = {
      name,
      email: `${emailPrefix}@student.uq.edu.au`,
      studentNumber,
    };
    localStorage.setItem("userInfo", JSON.stringify(user));
    // Set login status
    localStorage.setItem("isLoggedIn", "1");

    alert("Registration successful! Redirecting to logged-in activity list...");

    // After successful registration, redirect to logged-in list page
    window.location.href = "index_loggedin.html";
  });
});
