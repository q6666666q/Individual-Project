/* Minimal fuzzy search for static cards
   Simple fuzzy search (static card version, no JSON/backend needed)
   - Match: title + desc + data-keywords
   - Aliases: ai -> artificial intelligence; ml -> machine learning; hack -> hackathon
   - Highlight: wrap matches with <mark class="hl">...</mark>
*/

(function () {
  // Helpers
  const $  = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  const input  = $('#searchInput');          // Search input
  const list   = $('#list');                 // Card container
  const cards  = $$('.activity-card', list); // All cards
  const summary = $('#resultSummary');       // Result summary
  const emptyState = $('#emptyState');       // Empty state (optional)

  // Preset quick buttons
  $$('.quick-links button').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.getAttribute('data-q') || '';
      input.value = q;
      input.dispatchEvent(new Event('input'));
      input.focus();
    });
  });

  // Clear actions
  $('#btnClear')?.addEventListener('click', () => {
    input.value = '';
    input.dispatchEvent(new Event('input'));
    input.focus();
  });
  $('#clearLink')?.addEventListener('click', (e) => {
    e.preventDefault();
    input.value = '';
    input.dispatchEvent(new Event('input'));
    input.focus();
  });

  // Read initial ?q= from URL
  const params = new URLSearchParams(location.search);
  if (params.get('q')) input.value = params.get('q');

  // ---- Normalization ----
  const alias = (t) => t
    .replace(/\b(hacks?)\b/gi, 'hackathon')                 // hack -> hackathon
    .replace(/\b(ai|a\.i\.)\b/gi, 'artificial intelligence')// ai -> artificial intelligence
    .replace(/\b(ml)\b/gi, 'machine learning');             // ml -> machine learning

  const norm = (s) => alias(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^\w\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const tokens = (q) => norm(q).split(' ').filter(Boolean);

  // ---- Highlighting ----
  function highlight(el, queryTokens) {
    if (!el) return;
    // Save original plain text once
    if (!el.dataset.original) el.dataset.original = el.textContent;
    const original = el.dataset.original;
    if (!queryTokens.length) { el.innerHTML = original; return; }

    // Build regex /(t1|t2|...)/gi with escaping
    const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(`(${queryTokens.map(esc).join('|')})`, 'gi');
    el.innerHTML = original.replace(re, '<mark class="hl">$1</mark>');
  }

  // ---- Apply search ----
  function applySearch() {
    const q = input.value || '';
    const toks = tokens(q);

    let visible = 0;

    cards.forEach(card => {
      const titleEl = $('.title', card);
      const descEl  = $('.desc', card);
      // Search text sources: title + desc + data-keywords
      const hay = norm(
        `${titleEl?.textContent || ''} ${descEl?.textContent || ''} ${card.getAttribute('data-keywords') || ''}`
      );

      // Every token must appear
      const ok = toks.every(t => hay.includes(t));

      // Show/Hide
      card.style.display = ok || !toks.length ? '' : 'none';
      if (ok || !toks.length) visible++;

      // Highlight title & desc
      highlight(titleEl, toks);
      highlight(descEl, toks);
    });

    // Summary + empty state
    if (!toks.length) {
      summary && (summary.textContent = 'Showing all activities');
    } else {
      summary && (summary.textContent = `Found ${visible} activities for "${q}"`);
    }
    if (emptyState) emptyState.style.display = (visible === 0 ? 'block' : 'none');
  }

  // Bind events
  input?.addEventListener('input', applySearch);

  // Initial run
  applySearch();
})();
