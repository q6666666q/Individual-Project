/* ========= index.js =========
 * Render activity list with filters; responsive cards; split Upcoming/Past by 2025-10-29.
 */

// ---------- Static sample data (images 1..10 & detail 1..10) ----------
const IMG = (n) => `assets/activity_images/activity${n}.png`;  // One-to-one correspondence with folder
const DETAIL = (n) => `activity_detail_${n}.html`;

const activities = [
  { id:1,  title:"Thrill, Chill, Fill St Lucia", type:"Food", charge:"Free",
    date:"2025-11-05", time:"11:00–14:00", campus:"St Lucia",
    location:"Forgan Smith Upper Lawn · St Lucia", image:IMG(1), link:DETAIL(1) },

  { id:2,  title:"SAS Webinar – Submitting Appeals and Grievances", type:"Education", charge:"Free",
    date:"2025-11-10", time:"15:00–16:00", campus:"Online",
    location:"Online", image:IMG(2), link:DETAIL(2) },

  { id:3,  title:"Special Interest PowerPoint Night", type:"Presentation", charge:"Free",
    date:"2025-11-25", time:"17:00–21:00", campus:"St Lucia",
    location:"Michie Building (9) Room 740 · St Lucia", image:IMG(3), link:DETAIL(3) },

  { id:4,  title:"Lawes Club Membership 2025", type:"Club", charge:"Free",
    date:"2025-11-29", time:"19:00–22:00", campus:"Gatton",
    location:"UQU Lawes Club · Gatton", image:IMG(4), link:DETAIL(4) },

  { id:5,  title:"Education Webinar – Remark", type:"Education", charge:"Free",
    date:"2025-12-08", time:"15:00–16:00", campus:"Online",
    location:"Online", image:IMG(5), link:DETAIL(5) },

  { id:6,  title:"Mindfulness Inside and Out", type:"Wellness", charge:"Free",
    date:"2025-10-28", time:"13:00–14:30", campus:"St Lucia",
    location:"Advanced Engineering Building · St Lucia", image:IMG(6), link:DETAIL(6) },

  { id:7,  title:"Practice Art & Psyche", type:"Wellness", charge:"Free",
    date:"2025-10-29", time:"13:00–14:00", campus:"St Lucia",
    location:"UQ Lake · St Lucia", image:IMG(7), link:DETAIL(7) },

  { id:8,  title:"Art for Wellbeing", type:"Wellness and Lifestyle", charge:"Free",
    date:"2025-10-30", time:"11:00–13:00", campus:"St Lucia",
    location:"Physics Annexe (6) · St Lucia", image:IMG(8), link:DETAIL(8) },

  { id:9,  title:"SSP Projects – How to submit a project idea", type:"Career and Professional Development", charge:"Free",
    date:"2025-10-30", time:"10:00–10:30", campus:"Online",
    location:"Online", image:IMG(9), link:DETAIL(9) },

  { id:10, title:"Practice Art Studio", type:"Presentation", charge:"Free",
    date:"2025-11-15", time:"14:00–16:00", campus:"St Lucia",
    location:"Art Studio · St Lucia", image:IMG(10), link:DETAIL(10) },
];

// ---------- Baseline date: 2025-10-29 ----------
const BASELINE = new Date("2025-10-29T23:59:59");

// ---------- DOM ----------
const upView = document.getElementById("view-upcoming");
const pastView = document.getElementById("view-past");
const tabs = document.querySelectorAll(".tab");
const q = document.getElementById("q");
document.getElementById("goSearch").addEventListener("click", () => {
  // Only redirect to search.html, no search on this page
  window.location.href = "search.html";
});

// ---------- Filter sets ----------
const typeOptions = ["All", ...Array.from(new Set(activities.map(a => a.type)))];
const chargeOptions = ["All", "Free", "Paid"];
const campusOptions = ["All", ...Array.from(new Set(activities.map(a => a.campus)))];

let filter = { type:"All", charge:"All", campus:"All" };

// Render option chips in panel
function renderPanel(panelId, options, key){
  const panel = document.getElementById(panelId);
  panel.innerHTML = options.map(v => {
    const active = (filter[key] === v) ? "is-active" : "";
    return `<button class="opt ${active}" data-k="${key}" data-v="${v}">${v}</button>`;
  }).join("");
}
// Bind panel interactions
["type","charge","campus"].forEach(k=>{
  document.getElementById(`chip-${k}`).addEventListener("click", ()=>{
    // Expand current panel, collapse others
    ["type","charge","campus"].forEach(x=>{
      const p = document.getElementById(`panel-${x}`);
      p.style.display = (x===k && p.style.display!=="block") ? "block" : "none";
    });
  });
});
document.getElementById("panel-type").addEventListener("click", onPick);
document.getElementById("panel-charge").addEventListener("click", onPick);
document.getElementById("panel-campus").addEventListener("click", onPick);

function onPick(e){
  const t = e.target.closest(".opt"); if(!t) return;
  const k = t.dataset.k, v = t.dataset.v;
  filter[k] = v;
  document.getElementById(`chip-${k}`).textContent = `${capitalize(k)} ${v}`;
  renderAll();
}

// ---------- Render cards ----------
function fits(a){
  return (filter.type==="All" || a.type===filter.type)
      && (filter.charge==="All" || a.charge===filter.charge)
      && (filter.campus==="All" || a.campus===filter.campus);
}

function card(a, isDesktop){
  // Tag colors: type=purple, free=yellow
  return `
  <article class="card" onclick="window.location.href='${a.link}'" role="link" tabindex="0" aria-label="${a.title}">
    <img class="card-img" src="${a.image}" alt="${a.title}" />
    <div class="card-body">
      <h3 class="card-title ${isDesktop?'desktop':''}">${a.title}</h3>
      <div class="meta-row">
        <span class="tag type">${a.type}</span>
        ${a.charge==="Free" ? `<span class="tag free">Free</span>` : ``}
      </div>
      <div class="info">
        <img src="assets/icons/activity_detail/time.png" alt="">
        <div class="text">${formatDate(a.date)} · ${a.time}</div>
      </div>
      <div class="info">
        <img src="assets/icons/activity_detail/location.png" alt="">
        <div class="text">${a.location}</div>
      </div>
    </div>
  </article>`;
}

function renderAll(){
  // Re-render panel chips (maintain selected state)
  renderPanel("panel-type", typeOptions, "type");
  renderPanel("panel-charge", chargeOptions, "charge");
  renderPanel("panel-campus", campusOptions, "campus");

  const up = [], past = [];
  for(const a of activities){
    if(!fits(a)) continue;
    (new Date(a.date) > BASELINE ? up : past).push(a);
  }
  up.sort((a,b)=> new Date(a.date)-new Date(b.date));
  past.sort((a,b)=> new Date(b.date)-new Date(a.date));

  const desktop = window.matchMedia("(min-width: 900px)").matches;
  upView.innerHTML = up.map(a=>card(a, desktop)).join("") || emptyHint("No upcoming activities match.");
  pastView.innerHTML = past.map(a=>card(a, desktop)).join("") || emptyHint("No past activities match.");
}

function emptyHint(t){ return `<p style="color:#6b7280;padding:8px 2px;">${t}</p>`; }
function capitalize(s){ return s.charAt(0).toUpperCase()+s.slice(1); }
function formatDate(iso){
  // Format: Wed 5 Nov 2025
  const d = new Date(iso+"T00:00:00");
  const wk = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][d.getDay()];
  const mo = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][d.getMonth()];
  return `${wk} ${d.getDate()} ${mo} ${d.getFullYear()}`;
}

// ---------- Tab switching ----------
tabs.forEach(btn=>{
  btn.addEventListener("click", ()=>{
    tabs.forEach(b=>b.classList.remove("is-active"));
    btn.classList.add("is-active");
    const tab = btn.dataset.tab;
    document.getElementById("view-upcoming").classList.toggle("is-hidden", tab!=="upcoming");
    document.getElementById("view-past").classList.toggle("is-hidden", tab!=="past");
    // Collapse all panels
    ["type","charge","campus"].forEach(x=>document.getElementById(`panel-${x}`).style.display="none");
  });
});

// ---------- Initial render ----------
document.getElementById("chip-type").textContent = "Type All";
document.getElementById("chip-charge").textContent = "Charge All";
document.getElementById("chip-campus").textContent = "Campus All";
renderAll();

// Re-render on window resize to switch card title font size (desktop/mobile)
window.addEventListener("resize", ()=>renderAll());
