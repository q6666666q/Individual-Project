// ===== Favorites page: Read from localStorage and render list =====

// Access functions consistent with activity_detail.js
function getFavorites() {
    const favoritesStr = localStorage.getItem('favoriteActivities');
    return favoritesStr ? JSON.parse(favoritesStr) : [];
}

function saveFavorites(favorites) {
    localStorage.setItem('favoriteActivities', JSON.stringify(favorites));
}

function removeFromFavorites(activityId) {
    const favorites = getFavorites();
    const filtered = favorites.filter((activity) => activity.id !== activityId);
    saveFavorites(filtered);
}

// Render favorites list
function renderFavorites() {
    const listEl = document.querySelector('.grid');
    if (!listEl) return;

    const favorites = getFavorites();
    listEl.innerHTML = '';

    if (favorites.length === 0) {
        const empty = document.createElement('p');
        empty.textContent = "You haven't bookmarked any activities yet.";
        empty.style.marginTop = '1rem';
        listEl.appendChild(empty);
        return;
    }

    favorites.forEach((activity) => {
        const card = document.createElement('div');
        card.className = 'card';
        card.dataset.activityId = activity.id;
        
        // Build navigation link
        let href = '';
        if (activity.detailLink) {
            href = activity.detailLink;
        } else if (activity.id) {
            href = `activity_detail_${activity.id}.html`;
        } else {
            href = 'activity_detail_1.html';
        }
        card.dataset.href = href;
        card.setAttribute('role', 'link');
        card.setAttribute('tabindex', '0');
        card.setAttribute('aria-label', `Open ${activity.title} details`);

        // Build tags - use the same structure as list page
        const chipType = activity.typeTag ? `<span class="badge badge--type">${activity.typeTag}</span>` : '';
        const chipCharge = activity.charge === 'Free'
            ? `<span class="badge badge--free">Free</span>`
            : activity.charge ? `<span class="badge badge--paid">Paid</span>` : '';

        card.innerHTML = `
            <div class="card__media"><img src="${activity.imgSrc}" alt="${activity.title || activity.imgAlt || ''}"></div>
            <div class="card__body">
                <h3 class="card__title">${activity.title}</h3>
                <div class="badges">${chipType} ${chipCharge}</div>
                <div class="meta">
                    ${activity.time ? `<div class="meta__row"><img src="assets/icons/activity_detail/time.png" alt=""><div>${activity.time}</div></div>` : ''}
                    ${activity.location ? `<div class="meta__row"><img src="assets/icons/activity_detail/location.png" alt=""><div>${activity.location}</div></div>` : ''}
                </div>
            </div>
        `;

        // Make favorite card clickable to navigate to detail page
        card.addEventListener("click", () => {
            window.location.href = href;
        });
        
        // Keyboard support
        card.addEventListener("keydown", (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                window.location.href = href;
            }
        });

        listEl.appendChild(card);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const listEl = document.querySelector('.grid');
    if (!listEl) return;

    // Initial render
    renderFavorites();

});

// ===== Logout logic =====
document.addEventListener('DOMContentLoaded', () => {
  const logoutBtn = document.querySelector('.logout-btn');
  if (!logoutBtn) return;

  logoutBtn.addEventListener('click', () => {
    const confirmLogout = confirm("Are you sure you want to log out?");
    if (!confirmLogout) return;

    // Clear login status
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('loggedInUser');
    localStorage.removeItem('userInfo');
    // Note: Do not clear favorites list, keep user's favorite data

    // Simulate logout
    alert("You have successfully logged out!");
    window.location.href = "index.html"; // Redirect to logged-out list page
  });
});
