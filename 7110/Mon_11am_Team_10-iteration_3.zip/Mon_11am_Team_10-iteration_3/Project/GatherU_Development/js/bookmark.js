// ===== Bookmark System using localStorage =====

// Read existing bookmarks
function getBookmarks() {
  return JSON.parse(localStorage.getItem("bookmarks")) || [];
}

// Save bookmarks
function saveBookmarks(data) {
  localStorage.setItem("bookmarks", JSON.stringify(data));
}

// Add or remove bookmark
function toggleBookmark(activity) {
  let list = getBookmarks();
  const index = list.findIndex((item) => item.title === activity.title);

  if (index >= 0) {
    // Already exists → remove
    list.splice(index, 1);
  } else {
    // New bookmark → add
    list.push(activity);
  }

  saveBookmarks(list);
}

// Check if already bookmarked
function isBookmarked(title) {
  return getBookmarks().some((item) => item.title === title);
}
card.addEventListener("click", () => {
  toggleBookmark(item);
  card.remove();
});
